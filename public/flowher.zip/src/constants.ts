export const AFFIRMATIONS = [
  "Your brain isn't broken. It's built differently — and that is your silent capability.",
  "You walked into that boardroom today. That choice already took profound courage.",
  "An overlooked task or delayed email does not erase your exceptional intelligence.",
  "You are not your to-do list. You are the woman who keeps showing up despite the noise.",
  "Dysregulated days don't disqualify you. They're simply parts of your non-linear resume.",
  "You belong in every single room you walk into. No justifications required.",
  "Your ideas have immense value. Capture them before they slip away.",
  "Rest is not a failure of discipline. It is the essential recovery that fuels your mind.",
  "You are not behind. You are working on your own neuro-developmental timeline.",
  "Other people's uniform pacing is not the gold standard for your organic brain.",
  "You have successfully navigated 100% of your hardest days so far. Today is no different.",
  "Asking clearly for what you need isn't weakness. It is elite self-advocacy.",
  "The brain fog is temporary weather. Your underlying capability is an anchor.",
  "One tiny action at a time. That is always, unconditionally, enough.",
  "You bring a unique perspective to this workspace that no conventional thinker could replicate."
];

export const MOODS = [
  { emoji: "⚡", name: "Focused", tips: "Ride the hyperfocus safely: drop an anchor. Start a 30-minute visual timer right now so you don't over-expand or skip meals, and put a single track on loop to protect your cognitive alignment." },
  { emoji: "😶", name: "Foggy", tips: "Executive dysfunction is here. Drop all grand plans and list expectations. Try the 'micro-start': just open a single browser tab, write exactly one line, or read one item. Keep it tiny and demand-free." },
  { emoji: "😤", name: "Frustrated", tips: "Nervous system friction. Do not try to reason or push through. Step away from your desk for 3 minutes, splash cool water on your hands, or do a somatic shake of your arms to discharge sensory tension." },
  { emoji: "😰", name: "Overwhelmed", tips: "Red alert: too much signal, not enough filter. Shut your eyes, drop your shoulders 2 inches, and write a 'Brain Dump' list of maximum 3 items. Focus strictly on the single smallest step." },
  { emoji: "💪", name: "Confident", tips: "Dopamine levels are optimal. Capture this receipt into your Win Journal immediately as raw evidence for your Imposter Shield, and use this high-energy wave to draft that boundary-setting email." },
  { emoji: "😴", name: "Drained", tips: "Low-battery protocol. Dim your screen, put on comfy noise-canceling headphones, and mask strictly off. Move to asynchronous updates only and do only what is absolutely vital to survive." }
];

export const ADA_RIGHTS = [
  {
    title: "Neurodiversity is Protected",
    body: "ADHD, Autism/ASD, General Anxiety, and clinical burnout fall squarely under ADA protections. Your employer is legally required to explore and provide reasonable modifications."
  },
  {
    title: "Zero Obligation to Disclose Diagnosis",
    body: "You do not need to share clinical names or diagnoses. You can request changes by explaining 'I have an executive function / focus condition' and outlining which adjustments help you work best."
  },
  {
    title: "What Constitutes 'Reasonable' Accommodations?",
    body: "Extended timelines for heavy tasks, written summaries after verbal briefings, quiet work corners, visual noise dividers, flexible core hours, or utilizing noise-cancelling tools."
  },
  {
    title: "How to File a Formal Request",
    body: "Draft a clear, low-emotions note to HR or your manager: 'I have a medical condition affecting focus/executive function. I am respectfully requesting [specific accommodation] to ensure optimal contributions.'"
  },
  {
    title: "Retaliation Is Strictly Illegal",
    body: "Your corporate employer cannot demote, penalize, or isolate you for self-advocating or requesting accommodations. Doing so constitutes direct retaliation, giving you strong leverage and legal recourse."
  }
];

export const DOPAMINE_ITEMS = [
  { emoji: "💧", label: "Hydration Hit", detail: "Drinking water is literally nervous system fuel. You just did something deeply kind for your brain." },
  { emoji: "🚶", label: "2-Min Move", detail: "Two minutes of physical walking triggers immediate brain resetting. Stand up, walk to the window, come back." },
  { emoji: "🎵", label: "One Good Song", detail: "Play one favorite song that reminds you of exactly who you are. Let the sound wave do its work." },
  { emoji: "🌬️", label: "4-4-6 Breath", detail: "Inhale for 4, hold for 4, exhale slowly for 6. Your nervous system just received the quiet receipt." },
  { emoji: "☀️", label: "Look Outside", detail: "Shift your focal range. Look at the farthest natural point outside. Your screen-strained eyes need this." },
  { emoji: "🧊", label: "Cold Wrist Splash", detail: "Splashing cold water on your wrists or face directly stimulates your vagus nerve. Direct physiological transition." },
  { emoji: "📝", label: "Log a Tiny Win", detail: "Record anything — even opening this app or starting this hour. Recalling simple wins creates neurological dopamine." },
  { emoji: "✅", label: "View Done List", detail: "Write down three things you completed earlier, including getting out of bed or taking a shower. Build visual receipts." },
  { emoji: "🤸", label: "Somatic Shake", detail: "Stand up and shake your hands, shoulders, and arms vigorously for 30 seconds. Discharges accumulated survival tension." }
];

export const BREATH_STAGES = [
  { title: "Somatic Presence", instruction: "Shut your eyes if possible. Feel the solid weight of your feet pressing onto the floor. Feel gravity holding you securely." },
  { title: "Muscle Release", instruction: "Roll your shoulders gently back. Drop them. Unclench your jaw. Part your teeth. Relax your hands in your lap." },
  { title: "Lungs Anchor", instruction: "Take a slow, deep breath in for 4 counts... hold for 2... and exhale slowly, empty of tension, for 6 counts." },
  { title: "Demand Release", instruction: "You do not have to solve, figure out, or fix anything in this immediate 2-minute block. You just exist. You are completely off-call." },
  { title: "Compassion Acknowledgement", instruction: "Repeat silently: I am doing the absolute best I can with the wiring and energy capacity I have today. That is fully sufficient." },
  { title: "Organic Transition", instruction: "Slowly reopen your eyes. Wiggle your toes. You just honored your nervous system. You are ready to step back in safely." }
];
