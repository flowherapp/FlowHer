import React, { useState, useEffect, useRef } from "react";
import { 
  Sparkles, 
  Brain, 
  Zap, 
  ShieldCheck, 
  FileText, 
  Bookmark, 
  CheckCircle, 
  Compass, 
  ShieldAlert, 
  Dribbble, 
  Clock, 
  ArrowRight, 
  Heart, 
  Volume2, 
  Download, 
  AlertTriangle, 
  X, 
  Smile, 
  Calendar, 
  Menu, 
  ChevronRight, 
  ChevronLeft,
  Award,
  BookOpen,
  Lock,
  Moon,
  LogOut,
  ChevronDown,
  User,
  Camera,
  Upload
} from "lucide-react";

import { 
  AFFIRMATIONS, 
  MOODS, 
  ADA_RIGHTS, 
  DOPAMINE_ITEMS, 
  BREATH_STAGES 
} from "./constants";

import { Win, MaskMoment } from "./types";

const MINIMIZERS = [
  { regex: /\bjust\b/gi, word: "just", replacement: "(remove entirely)", reason: "Softens recommendations and signals hesitancy." },
  { regex: /\b(sorry|apologize|apologies)\b/gi, word: "sorry", replacement: "Thank you for bringing this to my attention / Thank you for your patience", reason: "Over-apologizing for standard work processes or capacity bounds weakens professional stature." },
  { regex: /\bactually\b/gi, word: "actually", replacement: "(remove entirely)", reason: "Highlights defensiveness or surprise instead of calm authority." },
  { regex: /\bdoes that make sense\??/gi, word: "does that make sense?", replacement: "I look forward to your feedback / Let me know your thoughts.", reason: "Asks the reader to question your clarity or logic." },
  { regex: /\bhope (this|that) is okay\b/gi, word: "hope this is okay", replacement: "I am moving forward with this approach / Let me know your thoughts.", reason: "Requests permission for normal administrative decisions." },
  { regex: /\bI (think|feel|believe)\b/gi, word: "I think / feel", replacement: "I recommend / I plan / I propose", reason: "Substitutes confidence and professional conviction for subjective feeling." },
  { regex: /\bno worries\b/gi, word: "no worries", replacement: "Certainly / My pleasure / Safe to proceed", reason: "Under-values your effort and can sound overly conversational." },
  { regex: /\b(bother|sorry to bother)\b/gi, word: "bother", replacement: "(omit / replace with statement)", reason: "Implies your outreach is an annoyance or inconvenience." }
];

const EMAIL_PRESETS = [
  { 
    label: "Timeline Pushback ⏳", 
    template: "Polite workload pushback",
    situation: "The team is demanding final graphic assets tomorrow morning, but I am already at maximum capacity this week. I will deliver them on Friday afternoon instead of rushing."
  },
  { 
    label: "Saying No to Overtime 🚫", 
    template: "Setting structural capacity boundaries",
    situation: "My manager requested a last-minute sync at 8 PM tonight or working over the upcoming weekend. I want to decline because it impacts my sensory recovery downtime."
  },
  { 
    label: "Written Context Demand 📝", 
    template: "Following up on timelines",
    situation: "A colleague sent a vague 'let's jump on a quick call to plan things'. I experience severe executive friction with unstructured meetings. I want to request a brief email list or agenda first."
  },
  { 
    label: "Overshare-Free Sick Leave 🤒", 
    template: "Setting structural capacity boundaries",
    situation: "I need to take a sensory sick day or mental health day today. I want to state clearly that I am offline without oversharing personal physical symptoms or saying 'sorry'."
  },
  { 
    label: "Scope Creep Restraint 💼", 
    template: "Accommodations request templates",
    situation: "The client asked for three extra features that were not part of the initial signed scope of work. I want to tell them we must scope this as Phase 2 or adjust the fee structure."
  }
];

const EMAIL_TONES = [
  { key: "neutral", label: "Friendly & Firm", tag: "Warm but immovable limits" },
  { key: "bold", label: "Completely Unapologetic", tag: "Zero filler, max speed" },
  { key: "formal", label: "Formal Corporate", tag: "Polished client elegance" },
  { key: "accommodating", label: "Protected Request", tag: "Confident structure requests" }
];

const EMAIL_SIGNATURE_PRESETS = [
  {
    id: "batch",
    label: "Focus Protection ⏳",
    tag: "Minimize email urgency & interruptions",
    benefit: "Shields hyperfocus states by training recipients to expect rhythmic response intervals instead of immediate availability.",
    text: "\n\nWarm regards,\n[Your Name]\n\n---\n*Note: In alignment with deep-work habits, I batch-process my inbox twice daily to protect active technical/creative focus blocks. Thank you for your patience.*"
  },
  {
    id: "sensory",
    label: "Sensory Recovery 🔋",
    tag: "Establish after-hours digital limits",
    benefit: "Protects high-cognitive evening downtime, preventing visual and mental sensory burnout before it depletes executive capacity.",
    text: "\n\nBest,\n[Your Name]\n\n---\n*Note: To prevent digital fatigue and ensure executive recovery, I protect my evening visual downtime starting after 5:30 PM. I will attend to your query when next online.*"
  },
  {
    id: "bullet",
    label: "Cognitive Clarity 📝",
    tag: "Encourage concise bulleted replies",
    benefit: "Reduces working memory load and prevents dyslexia or ADHD fatigue by normalizing dense, list-oriented information exchange.",
    text: "\n\nCheers,\n[Your Name]\n\n---\n*Note: To optimize executive processing, I favor crisp bullet points and written agendas over verbal overloads. Feel free to respond in notes!*"
  },
  {
    id: "boundary",
    label: "Accommodating Directness 💼",
    tag: "Firm but professional request format",
    benefit: "Mitigates rejection-sensitive loops by converting emotional status updates into structured, documented timeline logs.",
    text: "\n\nKind regards,\n[Your Name]\n\n---\n*Note: This update represents a professional capacity status log. All timeline updates or change-requests must be logged in writing to maintain trackable workspace progress.*"
  }
];

interface ResonanceReport {
  toneType: string;
  toneColor: string;
  toneEmoji: string;
  description: string;
  resonanceRating: string;
  scores: {
    assertiveness: number;
    clarity: number;
    emotionalLoad: number;
  };
  insights: { title: string; body: string; type: "alert" | "info" | "success" }[];
}

const analyzeEmailResonance = (text: string): ResonanceReport => {
  const lowercase = text.toLowerCase();
  
  // 1. Analyze minimizing words matching MINIMIZERS count
  const minimizerCount = MINIMIZERS.filter(m => m.regex.test(lowercase)).length;

  // 2. Identify over-explaining / justification
  const overExplainWords = ["because", "due to", "since i", "as i am", "reason is", "unfortunate", "actually", "just wanted to", "so sorry", "my apologies"];
  let overExplainCount = 0;
  overExplainWords.forEach(w => {
    const regex = new RegExp("\\b" + w, "gi");
    const matches = lowercase.match(regex);
    if (matches) overExplainCount += matches.length;
  });

  // 3. Identify stress & executive overloads
  const stressWords = ["overwhelmed", "struggling", "impossible", "stressed", "exhausted", "burnout", "stressful", "anxious", "panic", "hard to", "difficult"];
  let stressCount = 0;
  const matchedStressTerm: string[] = [];
  stressWords.forEach(w => {
    const regex = new RegExp("\\b" + w, "gi");
    const matches = lowercase.match(regex);
    if (matches) {
      stressCount += matches.length;
      if (!matchedStressTerm.includes(w)) {
        matchedStressTerm.push(w);
      }
    }
  });

  // 4. Identify command tension
  const commandWords = ["must", "need", "immediately", "required", "strictly", "demand", "essential", "crucial", "urgent"];
  let commandCount = 0;
  commandWords.forEach(w => {
    const regex = new RegExp("\\b" + w, "gi");
    const matches = lowercase.match(regex);
    if (matches) commandCount += matches.length;
  });

  // 5. Positive assertions
  const assertionWords = ["will", "plan", "propose", "recommend", "delivering", "on track", "structured", "prefer", "moving forward"];
  let assertionCount = 0;
  assertionWords.forEach(w => {
    const regex = new RegExp("\\b" + w, "gi");
    const matches = lowercase.match(regex);
    if (matches) {
      assertionCount += matches.length;
    }
  });

  // Calculate scores
  const assertivenessScore = Math.max(10, Math.min(100, 100 - (minimizerCount * 12) - (overExplainCount * 6) + (assertionCount * 8)));
  
  const wordCount = text.split(/\s+/).filter(Boolean).length;
  const sentenceCount = text.split(/[.!?]+/).filter(Boolean).length;
  const avgSentenceLength = sentenceCount > 0 ? wordCount / sentenceCount : 0;
  
  let clarityScore = 100;
  if (avgSentenceLength > 18) clarityScore -= 15;
  if (overExplainCount > 2) clarityScore -= 15;
  if (minimizerCount > 2) clarityScore -= 10;
  clarityScore = Math.max(20, clarityScore);

  const emotionalLoadScore = Math.max(0, Math.min(100, (stressCount * 25) + (overExplainCount * 10) + (minimizerCount * 5)));

  // Determine Overall Tone
  let toneType = "Balanced & Firm";
  let toneColor = "text-emerald-400 bg-emerald-950/40 border-emerald-500/20";
  let toneEmoji = "🛡️";
  let description = "This writing is well-grounded, straightforward, and clearly defines constraints without defensive clutter.";
  let resonanceRating = "Grounded Assertiveness";

  if (emotionalLoadScore > 50 && assertivenessScore < 50) {
    toneType = "High Cognitive Burden / Defensive Shield";
    toneColor = "text-[#FF9E7D] bg-[#E8845C]/10 border-[#E8845C]/35";
    toneEmoji = "🤕";
    description = "The text contains multiple stress markers and over-explanations. This suggests significant under-the-hood fatigue or communication anxiety.";
    resonanceRating = "Frictional Burnout Signature";
  } else if (overExplainCount > 3 && assertivenessScore < 70) {
    toneType = "Over-Explaining Loop";
    toneColor = "text-amber-300 bg-amber-950/40 border-amber-500/20";
    toneEmoji = "🔁";
    description = "You are over-detailing your reasons to justify standard technical boundaries, which might dilute your authority.";
    resonanceRating = "Oversharing Defense";
  } else if (minimizerCount > 1 && assertionCount === 0) {
    toneType = "Apologetic & Hesitant";
    toneColor = "text-amber-400 bg-amber-950/30 border-amber-500/15";
    toneEmoji = "🥺";
    description = "Wording signals submissive patterns and high rejection sensitivity. The text over-cushions standard professional requests.";
    resonanceRating = "Submissive Cushioning";
  } else if (commandCount > 1 && minimizerCount > 1) {
    toneType = "Mixed Signals / Friction Loop";
    toneColor = "text-fuchsia-300 bg-fuchsia-955/40 border-fuchsia-500/20";
    toneEmoji = "⚡";
    description = "We notice overlapping signals: very direct/forceful words alongside apologetic/softening phrases. This can confuse the audience's perception.";
    resonanceRating = "Mixed Assertiveness Pattern";
  } else if (assertivenessScore > 85) {
    toneType = "High-Confidence Prism State";
    toneColor = "text-[#E085C9] bg-[#C45BAA]/10 border-[#C45BAA]/20";
    toneEmoji = "👑";
    description = "Impeccable executive presence. Highly refined, clean boundary-setting with zero unnecessary qualifiers.";
    resonanceRating = "Supreme Professional Presence";
  }

  // Create Insights
  const insights: { title: string; body: string; type: "alert" | "info" | "success" }[] = [];

  // Over-explaining check
  if (overExplainCount > 1) {
    insights.push({
      title: "Reasoning & Explanation Check",
      body: "You've shared extensive 'why' context (using words like 'because' or 'due to'). For neurodivergent professionals, over-explaining shields against expected rejection, but in practice, simple capacity limits (e.g., 'I cannot deliver this model by tomorrow') need no justification. Try shrinking the context details by half.",
      type: "alert"
    });
  } else {
    insights.push({
      title: "Capacity Insulation",
      body: "Excellent work keeping explanations private. You didn't leak details of personal downtime or overload to qualify your boundary. Keep this standard!",
      type: "success"
    });
  }

  // Stress keyword check
  if (stressCount > 0) {
    const terms = matchedStressTerm.join(", ");
    insights.push({
      title: "Emotional Load Triggers Detected",
      body: `You used distress markers: "${terms}". While validating, disclosing emotional struggles in a corporate environment can open the door for micro-management. Try converting 'I am struggling with sensory overload' into 'To maintain structural focus and deliver high quality, I require 2 undisturbed days.'`,
      type: "alert"
    });
  }

  // mixed messages check
  if (commandCount > 0 && minimizerCount > 0) {
    insights.push({
      title: "Mixed Message Cushioning",
      body: "You blended direct demands with safety cushions (like 'sorry to ask but we strictly must...'). This creates cognitive dissonance. Declare your request calmly, but do not apologize for the requirement itself.",
      type: "info"
    });
  }

  // long sentences / run-ons
  if (avgSentenceLength > 18) {
    insights.push({
      title: "High Structural Run-ons",
      body: `Your average sentence is ${Math.round(avgSentenceLength)} words long. Highly verbose blocks suggest high cognitive anxiety. Try splitting long thoughts with bullet points. It saves reading stress for them, and spelling anxiety for you.`,
      type: "info"
    });
  }

  return {
    toneType,
    toneColor,
    toneEmoji,
    description,
    resonanceRating,
    scores: {
      assertiveness: assertivenessScore,
      clarity: clarityScore,
      emotionalLoad: emotionalLoadScore
    },
    insights
  };
};

const renderHighlightedText = (text: string) => {
  if (!text) {
    return <span className="text-gray-500 italic">No text written yet. Type or paste your draft above to start the real-time boundary scan!</span>;
  }
  
  let tokens: { text: string; isMatch: boolean; matchedWord?: string }[] = [{ text, isMatch: false }];
  
  MINIMIZERS.forEach(({ regex, word }) => {
    let newTokens: { text: string; isMatch: boolean; matchedWord?: string }[] = [];
    tokens.forEach(token => {
      if (token.isMatch) {
        newTokens.push(token);
        return;
      }
      
      const parts = token.text.split(regex);
      const matches = token.text.match(regex) || [];
      
      parts.forEach((part, i) => {
        newTokens.push({ text: part, isMatch: false });
        if (i < parts.length - 1 && matches[i]) {
          newTokens.push({ text: matches[i], isMatch: true, matchedWord: word });
        }
      });
    });
    tokens = newTokens;
  });

  return (
    <div className="whitespace-pre-wrap leading-relaxed select-text">
      {tokens.map((token, i) => {
        if (token.isMatch) {
          return (
            <span 
              key={i} 
              className="bg-[#E8845C]/20 text-[#FF9E7D] border-b border-[#E8845C]/50 px-1 py-0.5 rounded font-bold transition-all relative group inline-block"
              title={`Minimizer matching: "${token.text}". View alternatives below.`}
            >
              {token.text}
            </span>
          );
        }
        return <span key={i}>{token.text}</span>;
      })}
    </div>
  );
};

const TOUR_STEPS = [
  {
    title: "Welcome to FlowHer 🌸",
    text: "FlowHer is an elegant, supportive workspace crafted to reduce corporate cognitive overload. Our core modules translate common workspace hurdles — sensory fatigue, communication anxiety, rejection-sensitivity, and executive paralysis — into highly structured, protective professional routines.",
    targetTab: "home",
    tool: null,
    highlightIndicator: "Main Navigation Space",
    iconName: "Sparkles"
  },
  {
    title: "Neuro-Chemistry Check-in 🧠",
    text: "Ditch standard corporate masking behavior. Register how your cognitive batteries and emotional energy are feeling today. Submitting daily check-ins establishes active work boundaries and unlocks instant emotional preservation tips.",
    targetTab: "home",
    tool: null,
    highlightIndicator: "How is your neuro-chemistry walking in?",
    iconName: "Smile"
  },
  {
    title: "Smallest Step AI Engine ⚙️",
    text: "Struggling with executive block or task paralysis? This tool uses your private, secure client AI pipeline to slice daunting objectives into the single, smallest possible physical action under 2 minutes. Start instantly with zero fear.",
    targetTab: "focus",
    tool: null,
    highlightIndicator: "Smallest Step AI Breakdown Engine",
    iconName: "Brain"
  },
  {
    title: "Confident Email Drafting ✉️",
    text: "Shield your energy with unapologetic professional communication templates. Our AI Coach translates raw frustration or stress into customized neutral, executive, or direct protective tones, then strips out unneeded self-minimizing apologies.",
    targetTab: "work",
    tool: "email",
    subTab: "ai",
    highlightIndicator: "Confident Email Drafting & Boundary Scan",
    iconName: "ShieldCheck"
  },
  {
    title: "Multiple Custom Signatures ✍️",
    text: "Declare clear communication bounds without awkward over-explaining. Save distinct contextual signature sign-offs — like quiet-recovery afternoon locks or batch-processing blocks — and stamp them to the bottom of drafts with a single tap.",
    targetTab: "work",
    tool: "email",
    subTab: "signatures",
    highlightIndicator: "Personalized Signatures Library",
    iconName: "Sparkles"
  },
  {
    title: "Evidentiary Wins Journal 🏆",
    text: "When rejection-sensitive dysphoria (RSD) or imposter syndrome kicks in, factual evidence is your ultimate shield. Record small wins daily, creating a secure logs sheet that you can copy or export when performance review time arrives.",
    targetTab: "wins",
    tool: null,
    highlightIndicator: "Evidence receipts journal",
    iconName: "Award"
  },
  {
    title: "You're Fully Configured! 🚀",
    text: "You are ready to command your workspace safely and confidently. Everything in FlowHer is persisted locally on your device to ensure complete privacy. Re-trigger this onboarding tour anytime with the '✨ Tour' button in your workspace header.",
    targetTab: "home",
    tool: null,
    highlightIndicator: "Enjoy FlowHer!",
    iconName: "CheckCircle"
  }
];

const renderTourIcon = (name: string) => {
  switch (name) {
    case "Sparkles": return <Sparkles className="h-6 w-6 text-[#C45BAA]" />;
    case "Smile": return <Smile className="h-6 w-6 text-[#E085C9]" />;
    case "Brain": return <Brain className="h-6 w-6 text-teal" />;
    case "ShieldCheck": return <ShieldCheck className="h-6 w-6 text-[#E8845C]" />;
    case "Award": return <Award className="h-6 w-6 text-[#D4A843]" />;
    case "CheckCircle": return <CheckCircle className="h-6 w-6 text-emerald-400" />;
    default: return <Sparkles className="h-6 w-6 text-mag" />;
  }
};

export default function App() {
  // Navigation & Screen Control
  const [currentView, setCurrentView] = useState<"landing" | "founding" | "app">("landing");
  const [appTab, setAppTab] = useState<"home" | "focus" | "work" | "wins" | "unmask" | "mask">("home");
  const [selectedWorkTool, setSelectedWorkTool] = useState<string | null>(null);

  // Guided Interactive Tour States
  const [showGuidedTour, setShowGuidedTour] = useState<boolean>(() => {
    return !localStorage.getItem("fh_guided_tour_completed");
  });
  const [tourStep, setTourStep] = useState<number>(0);

  // Dynamic Founding Spots Urgency States
  const [spotsRemaining, setSpotsRemaining] = useState<number>(() => {
    const saved = localStorage.getItem("fh_founding_spots_remaining");
    if (saved) return Number(saved);
    const initial = Math.floor(Math.random() * 5) + 9; // between 9 and 13 spots left
    localStorage.setItem("fh_founding_spots_remaining", String(initial));
    return initial;
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setSpotsRemaining(prev => {
        if (prev <= 3) {
          return 3; // Keep a buffer minimum of 3 spots
        }
        const decrease = Math.random() > 0.65 ? 1 : 0;
        if (decrease > 0) {
          const nextVal = prev - decrease;
          localStorage.setItem("fh_founding_spots_remaining", String(nextVal));
          return nextVal;
        }
        return prev;
      });
    }, 45000); // Scrutinize every 45 secs for real-time engagement decay
    return () => clearInterval(interval);
  }, []);

  // User Authentication & Plan State
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [userPlan, setUserPlan] = useState<"free" | "core">("free");
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signup");
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authForm, setAuthForm] = useState({ name: "", email: "", password: "", promo: "" });
  const [authError, setAuthError] = useState("");

  // User Profile States
  const [profilePic, setProfilePic] = useState<string>(() => {
    return localStorage.getItem("fh_profile_pic") || "";
  });
  const [profileBio, setProfileBio] = useState<string>(() => {
    return localStorage.getItem("fh_profile_bio") || "A professional navigating executive functioning with smart aesthetic micro-structures.";
  });
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState("");
  const [editBio, setEditBio] = useState("");
  const [appHelpOpenIdx, setAppHelpOpenIdx] = useState<number | null>(null);

  // Plan Gate Overlay Modal
  const [showGateModal, setShowGateModal] = useState<string | null>(null);

  // Daily Check-In & Streak States
  const [streakCount, setStreakCount] = useState<number>(() => {
    return Number(localStorage.getItem("fh_streak_count") || "3");
  });
  const [lastCheckInDate, setLastCheckInDate] = useState<string>(() => {
    return localStorage.getItem("fh_last_checkin") || "";
  });
  const [bestStreak, setBestStreak] = useState<number>(() => {
    return Number(localStorage.getItem("fh_best_streak") || "4");
  });
  const [isFogDayToday, setIsFogDayToday] = useState(false);
  const [isNotTodayActive, setIsNotTodayActive] = useState(false);
  const [selectedMoodIndex, setSelectedMoodIndex] = useState<number | null>(() => {
    const saved = localStorage.getItem("fh_selected_mood");
    return saved !== null ? Number(saved) : null;
  });
  const [moodNote, setMoodNote] = useState<string>(() => {
    return localStorage.getItem("fh_mood_note") || "";
  });

  // Affirmation Carousel
  const [affirmationIdx, setAffirmationIdx] = useState(0);

  // Focus Timer
  const [timerSeconds, setTimerSeconds] = useState(25 * 60);
  const [timerActive, setTimerActive] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Action Priorities State
  const [priorities, setPriorities] = useState<string[]>(() => {
    const saved = localStorage.getItem("fh_priorities");
    return saved ? JSON.parse(saved) : ["", "", ""];
  });

  // Smallest Step Engine
  const [smallestStepInput, setSmallestStepInput] = useState("");
  const [smallestStepResult, setSmallestStepResult] = useState("");
  const [smallestStepLoading, setSmallestStepLoading] = useState(false);

  // Email Drafting Assistant
  const [emailSelectedTemplate, setEmailSelectedTemplate] = useState("Following up on a proposal");
  const [emailSituation, setEmailSituation] = useState("");
  const [emailResult, setEmailResult] = useState("");
  const [emailLoading, setEmailLoading] = useState(false);
  const [emailSelectedTone, setEmailSelectedTone] = useState("neutral");
  const [emailSubTab, setEmailSubTab] = useState<"ai" | "scan" | "signatures">("ai");
  const [scannerInput, setScannerInput] = useState("");

  // Custom Email Signatures Manager
  const [customSignatures, setCustomSignatures] = useState<{ id: string; label: string; tag: string; text: string }[]>(() => {
    const saved = localStorage.getItem("fh_custom_signatures");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to parse custom signatures", e);
      }
    }
    return [
      {
        id: "sig-batch",
        label: "Deep Focus Batching ⏳",
        tag: "Protect energetic focus channels",
        text: "\n\nWarm regards,\n[Your Name]\n\n---\n*Note: To protect technical and deep-work lanes, I review and batch-process my emails twice daily. Thank you for your support of focused development!*"
      },
      {
        id: "sig-sensory",
        label: "Downtime Boundary 🔋",
        tag: "Set evening digital limit parameters",
        text: "\n\nBest,\n[Your Name]\n\n---\n*Note: To limit digital sensory fatigue and maintain cognitive efficacy, I protect my quiet focus boundaries starting at 5:00 PM. I will attend to your request first thing in the morning.*"
      }
    ];
  });
  const [sigFormLabel, setSigFormLabel] = useState("");
  const [sigFormTag, setSigFormTag] = useState("");
  const [sigFormText, setSigFormText] = useState("");
  const [sigEditId, setSigEditId] = useState<string | null>(null);

  // Dynamic Stateful Presets for email signatures with strategic ND benefits
  const [signaturePresets, setSignaturePresets] = useState<{ id: string; label: string; tag: string; benefit: string; text: string }[]>(() => {
    const saved = localStorage.getItem("fh_signature_presets");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to parse signature presets", e);
      }
    }
    return EMAIL_SIGNATURE_PRESETS;
  });

  const [editingPresetId, setEditingPresetId] = useState<string | null>(null);
  const [presetEditLabel, setPresetEditLabel] = useState("");
  const [presetEditTag, setPresetEditTag] = useState("");
  const [presetEditBenefit, setPresetEditBenefit] = useState("");
  const [presetEditText, setPresetEditText] = useState("");

  // Conversation Script Generator
  const [scriptSelectedTemplate, setScriptSelectedTemplate] = useState("Ask for accommodation");
  const [scriptSituation, setScriptSituation] = useState("");
  const [scriptResult, setScriptResult] = useState("");
  const [scriptLoading, setScriptLoading] = useState(false);

  // RSD Toolkit
  const [rsdSpiral, setRsdSpiral] = useState("");
  const [rsdResult, setRsdResult] = useState("");
  const [rsdLoading, setRsdLoading] = useState(false);

  // Meeting Mode
  const [meetingTopic, setMeetingTopic] = useState("");
  const [meetingPeople, setMeetingPeople] = useState("");
  const [meetingGoal, setMeetingGoal] = useState("");
  const [meetingAnxiety, setMeetingAnxiety] = useState<number>(2); // 1 = Calm, 2 = Nervous, 3 = Dreading
  const [meetingResult, setMeetingResult] = useState("");
  const [meetingLoading, setMeetingLoading] = useState(false);

  // Time Blindness Corrector
  const [tbcTask, setTbcTask] = useState("");
  const [tbcEstimate, setTbcEstimate] = useState<number | "">("");
  const [tbcTimerActive, setTbcTimerActive] = useState(false);
  const [tbcSeconds, setTbcSeconds] = useState(0);
  const tbcTimerRef = useRef<NodeJS.Timeout | null>(null);
  const [tbcHistory, setTbcHistory] = useState<any[]>(() => {
    const saved = localStorage.getItem("fh_tbc_history");
    return saved ? JSON.parse(saved) : [];
  });

  // Time Blindness Assist Feature States
  const [tbcAssistEnabled, setTbcAssistEnabled] = useState<boolean>(() => {
    return localStorage.getItem("fh_tbc_assist_enabled") === "true";
  });
  const [tbcAssistInterval, setTbcAssistInterval] = useState<number>(() => {
    const saved = localStorage.getItem("fh_tbc_assist_interval");
    return saved ? Number(saved) : 3;
  });
  const [tbcAssistType, setTbcAssistType] = useState<"pulse" | "chime" | "both">(() => {
    return (localStorage.getItem("fh_tbc_assist_type") as any) || "both";
  });
  const [pulseCueActive, setPulseCueActive] = useState(false);
  const [pulseCueMessage, setPulseCueMessage] = useState("");

  // Body Double Timer
  const [bdTask, setBdTask] = useState("");
  const [bdTimerSeconds, setBdTimerSeconds] = useState(25 * 60);
  const [bdTimerActive, setBdTimerActive] = useState(false);
  const bdTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Win Journal State
  const [winsList, setWinsList] = useState<Win[]>(() => {
    const saved = localStorage.getItem("fh_wins_list");
    return saved ? JSON.parse(saved) : [];
  });
  const [newWinText, setNewWinText] = useState("");
  const [newWinCat, setNewWinCat] = useState("Professional");

  // Unmask Space & Grounding Reset
  const [unmaskText, setUnmaskText] = useState("");
  const [somaticStep, setSomaticStep] = useState(0);

  // Masking Debt State
  const [selectedMaskTypes, setSelectedMaskTypes] = useState<string[]>([]);
  const [maskIntensity, setMaskIntensity] = useState<number>(5);
  const [maskNote, setMaskNote] = useState("");
  const [allMaskMoments, setAllMaskMoments] = useState<MaskMoment[]>(() => {
    const saved = localStorage.getItem("fh_mask_moments");
    return saved ? JSON.parse(saved) : [];
  });
  const [showRecoveryAlert, setShowRecoveryAlert] = useState<{
    cost: number;
    types: string[];
    advice: {
      level: string;
      duration: number;
      tip: string;
      activity: string;
      color: string;
    };
  } | null>(null);

  // End of Day Wind Down
  const [windDownStep, setWindDownStep] = useState<"form" | "done">("form");
  const [windDownForm, setWindDownForm] = useState({ did: "", letGo: "", tomorrow: "" });
  const [showWindDown, setShowWindDown] = useState(false);

  // System Overlays & Feedback Toasts
  const [toastMessage, setToastMessage] = useState("");
  const [isSosActive, setIsSosActive] = useState(false);
  const [sosPhase, setSosPhase] = useState("Breathe In");
  const [faqOpenIdx, setFaqOpenIdx] = useState<number | null>(null);
  const [showExitModal, setShowExitModal] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  // Onboarding Quiz Modal State
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardingStep, setOnboardingStep] = useState(1);
  const [onboardingAnswers, setOnboardingAnswers] = useState({
    profile: "",
    primaryGoal: "",
  });

  // Save priorities automatically
  useEffect(() => {
    localStorage.setItem("fh_priorities", JSON.stringify(priorities));
  }, [priorities]);

  // Network listener
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Sync state helpers
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(""), 3000);
  };

  // Profile Upload & Drag Drop handlers
  const [isDraggingFile, setIsDraggingFile] = useState(false);

  const handleFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      triggerToast("Please upload an image file (PNG, JPG, SVG, WEBP).");
      return;
    }
    if (file.size > 1.5 * 1024 * 1024) { // 1.5MB limit
      triggerToast("Please choose an image under 1.5MB to maintain smooth offline rendering.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setProfilePic(result);
        localStorage.setItem("fh_profile_pic", result);
        triggerToast("Profile photo loaded successfully! 📸");
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleSaveProfile = () => {
    if (!editName.trim()) {
      triggerToast("Name cannot be empty!");
      return;
    }
    setProfileBio(editBio);
    localStorage.setItem("fh_profile_bio", editBio);

    if (user) {
      const updatedUser = { ...user, name: editName };
      setUser(updatedUser);
      localStorage.setItem("fh_user", JSON.stringify(updatedUser));
    } else {
      const newUser = { name: editName, email: "user@test.com" };
      setUser(newUser);
      localStorage.setItem("fh_user", JSON.stringify(newUser));
    }

    triggerToast("User Profile updated successfully! ✨");
    setIsEditingProfile(false);
    setShowProfileModal(false);
  };

  // Onboarding triggers on new user creation
  const handleCompleteOnboarding = () => {
    setShowOnboarding(false);
    triggerToast("Your workspace profile has been configured successfully! Enjoy FlowHer Core.");
  };

  // Auth System Functions
  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");

    if (!authForm.email || !authForm.password) {
      setAuthError("All authorization credentials fields are required.");
      return;
    }

    if (authMode === "signup") {
      if (!authForm.name) {
        setAuthError("Please input your name.");
        return;
      }
      // Create user
      const userData = { name: authForm.name, email: authForm.email };
      setUser(userData);
      localStorage.setItem("fh_user", JSON.stringify(userData));

      // Promo validation for Core access
      const normalCode = authForm.promo.trim().toUpperCase();
      const validBetaCodes = ["BETAFLOWHER2026", "FLOWHERBETA", "FLOWHER_AI", "BETA3MONTHS", "FLOWHER3MONTHS", "FLOWHER3M"];
      if (validBetaCodes.includes(normalCode)) {
        setUserPlan("core");
        localStorage.setItem("fh_plan", "core");
        localStorage.setItem("fh_beta_tier", "3_months");
      } else {
        setUserPlan("free");
        localStorage.setItem("fh_plan", "free");
        localStorage.removeItem("fh_beta_tier");
      }

      setShowAuthModal(false);
      setShowOnboarding(true); // show Onboarding onboarding steps
      setCurrentView("app");
      const isBetaMonths = ["BETA3MONTHS", "FLOWHER3MONTHS", "FLOWHER3M"].includes(normalCode);
      if (isBetaMonths) {
        triggerToast("🎉 3-Month Beta Testing Pass Activated! Full Core features unlocked.");
      } else {
        triggerToast(`Account created successfully! Welcome to FlowHer, ${authForm.name}.`);
      }
    } else {
      // Signin simulation
      const savedUser = JSON.parse(localStorage.getItem("fh_user") || '{"name":"Professional User","email":"user@test.com"}');
      setUser(savedUser);
      setUserPlan((localStorage.getItem("fh_plan") as "free" | "core") || "free");
      setShowAuthModal(false);
      setCurrentView("app");
      triggerToast(`Welcome back to FlowHer, ${savedUser.name}!`);
    }
  };

  const handleSignOut = () => {
    setUser(null);
    setUserPlan("free");
    setCurrentView("landing");
    triggerToast("You have been signed out safely.");
  };

  // Guided Interactive Tour Handlers
  const handleNextTourStep = () => {
    if (tourStep < TOUR_STEPS.length - 1) {
      const nextStep = tourStep + 1;
      setTourStep(nextStep);
      const target = TOUR_STEPS[nextStep];
      if (target.targetTab) {
        setAppTab(target.targetTab as any);
      }
      if (target.tool) {
        setSelectedWorkTool(target.tool);
      } else if (target.targetTab !== "work") {
        setSelectedWorkTool(null);
      }
      if (target.subTab) {
        setEmailSubTab(target.subTab as any);
      }
    } else {
      handleDismissTour();
    }
  };

  const handlePrevTourStep = () => {
    if (tourStep > 0) {
      const prevStep = tourStep - 1;
      setTourStep(prevStep);
      const target = TOUR_STEPS[prevStep];
      if (target.targetTab) {
        setAppTab(target.targetTab as any);
      }
      if (target.tool) {
        setSelectedWorkTool(target.tool);
      } else if (target.targetTab !== "work") {
        setSelectedWorkTool(null);
      }
      if (target.subTab) {
        setEmailSubTab(target.subTab as any);
      }
    }
  };

  const handleDismissTour = () => {
    setShowGuidedTour(false);
    localStorage.setItem("fh_guided_tour_completed", "true");
    triggerToast("Onboarding guide completed! Access it anytime from your header. ✨");
  };

  const handleRestartTour = () => {
    setTourStep(0);
    setAppTab("home");
    setSelectedWorkTool(null);
    setShowGuidedTour(true);
    triggerToast("Guided tour restarted! Let's walk through FlowHer. 🌿");
  };

  // Plan guard utility
  const executeCoreAction = (featureName: string, action: () => void) => {
    if (userPlan === "core") {
      action();
    } else {
      setShowGateModal(featureName);
    }
  };

  // Focus Timer Hooks & Handling
  useEffect(() => {
    if (timerActive) {
      timerRef.current = setInterval(() => {
        setTimerSeconds(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setTimerActive(false);
            triggerToast("Focus block complete! Take a relaxing dopamine moment now.");
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timerActive]);

  // Time Blindness Timer
  useEffect(() => {
    if (tbcTimerActive) {
      tbcTimerRef.current = setInterval(() => {
        setTbcSeconds(prev => prev + 1);
      }, 1000);
    } else {
      if (tbcTimerRef.current) clearInterval(tbcTimerRef.current);
    }
    return () => {
      if (tbcTimerRef.current) clearInterval(tbcTimerRef.current);
    };
  }, [tbcTimerActive]);

  // Audio Customizer: Beautiful, tranquilized pure synthesized note chime for neurodivergents
  const playGentleChime = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      osc.type = "sine";
      osc.frequency.setValueAtTime(523.25, ctx.currentTime); // Tranquil sweet C5 chord generator
      
      const overtone = ctx.createOscillator();
      const overtoneGain = ctx.createGain();
      overtone.type = "sine";
      overtone.frequency.setValueAtTime(523.25 * 1.5, ctx.currentTime); // Pure Fifth interval harmonic
      
      gainNode.gain.setValueAtTime(0, ctx.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.12, ctx.currentTime + 0.15); // soft, zero-startle attack
      gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 2.0); // ambient slow release
      
      overtoneGain.gain.setValueAtTime(0, ctx.currentTime);
      overtoneGain.gain.linearRampToValueAtTime(0.04, ctx.currentTime + 0.1);
      overtoneGain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 1.2);

      osc.connect(gainNode);
      overtone.connect(overtoneGain);
      
      gainNode.connect(ctx.destination);
      overtoneGain.connect(ctx.destination);
      
      osc.start(ctx.currentTime);
      overtone.start(ctx.currentTime);
      
      osc.stop(ctx.currentTime + 2.1);
      overtone.stop(ctx.currentTime + 1.3);
    } catch (err) {
      console.warn("AudioContext block initialized: ", err);
    }
  };

  // State synchronization hooks for TBC Assist
  useEffect(() => {
    localStorage.setItem("fh_tbc_assist_enabled", String(tbcAssistEnabled));
  }, [tbcAssistEnabled]);

  useEffect(() => {
    localStorage.setItem("fh_tbc_assist_interval", String(tbcAssistInterval));
  }, [tbcAssistInterval]);

  useEffect(() => {
    localStorage.setItem("fh_tbc_assist_type", tbcAssistType);
  }, [tbcAssistType]);

  // Real-Time Time Blindness Assist interval observer
  useEffect(() => {
    if (tbcTimerActive && tbcSeconds > 0 && tbcAssistEnabled) {
      const intervalSecs = tbcAssistInterval * 60;
      if (tbcSeconds % intervalSecs === 0) {
        const passedMins = tbcSeconds / 60;
        const rawEst = Number(tbcEstimate) || 0;
        const avgMult = getMultiplierAvg();
        const adjustedLimit = Math.round(rawEst * avgMult);
        
        let message = `🌿 Breathing check-in: ${passedMins} minute${passedMins > 1 ? "s" : ""} gently elapsed.`;
        if (adjustedLimit > 0 && passedMins >= adjustedLimit) {
          message = `🌅 Comfort envelope crossed. ${passedMins} mins elapsed. We recommend wrapping up or stepping away with zero guilt!`;
        } else if (adjustedLimit > 0 && passedMins >= adjustedLimit * 0.8) {
          message = `⏳ Running perfectly on schedule: approaching your support-adjusted safety target (${adjustedLimit} mins).`;
        }
        
        setPulseCueMessage(message);
        setPulseCueActive(true);
        triggerToast(message);
        
        if (tbcAssistType === "chime" || tbcAssistType === "both") {
          playGentleChime();
        }
        
        // auto dismiss state cue overlay
        const t = setTimeout(() => {
          setPulseCueActive(false);
        }, 4500);
        return () => clearTimeout(t);
      }
    }
  }, [tbcSeconds, tbcTimerActive, tbcAssistEnabled, tbcAssistInterval, tbcAssistType]);

  // Body Double Timer
  useEffect(() => {
    if (bdTimerActive) {
      bdTimerRef.current = setInterval(() => {
        setBdTimerSeconds(prev => {
          if (prev <= 1) {
            clearInterval(bdTimerRef.current!);
            setBdTimerActive(false);
            triggerToast("Well done! Your body double session is complete!");
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (bdTimerRef.current) clearInterval(bdTimerRef.current);
    }
    return () => {
      if (bdTimerRef.current) clearInterval(bdTimerRef.current);
    };
  }, [bdTimerActive]);

  // Wind down display logic (after 5 PM check)
  useEffect(() => {
    const currentHour = new Date().getHours();
    if (currentHour >= 17) {
      setShowWindDown(true);
    } else {
      setShowWindDown(false);
    }
  }, []);

  // SOS Soma guided breathe
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isSosActive) {
      let stepIdx = 0;
      const steps = ["Breathe In", "Hold...", "Breathe Out", "Pause..."];
      setSosPhase(steps[stepIdx]);
      interval = setInterval(() => {
        stepIdx = (stepIdx + 1) % steps.length;
        setSosPhase(steps[stepIdx]);
      }, 2500);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isSosActive]);

  // Word fadeout effect calculation
  const getFadingWords = () => {
    if (!unmaskText) return [];
    const arr = unmaskText.split(/\s+/).filter(Boolean);
    return arr.slice(-7);
  };

  // AI API Handlers
  const handleFetchSmallestStep = async () => {
    if (!smallestStepInput.trim()) return;
    setSmallestStepLoading(true);
    setSmallestStepResult("");
    try {
      const response = await fetch("/api/ai/smallest-step", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task: smallestStepInput }),
      });
      const data = await response.json();
      if (response.ok) {
        setSmallestStepResult(data.result);
      } else {
        setSmallestStepResult(`Offline Draft Coach suggestion: Let's segment your task of "${smallestStepInput}" into simple items. First: Focus just on opening the document. That's your only goal for 3 minutes!`);
      }
    } catch {
      setSmallestStepResult("Ready Coach suggestion: Open the software workspace first and sit comfortability for 60 seconds.");
    } finally {
      setSmallestStepLoading(false);
    }
  };

  const handleFetchEmailDraft = async () => {
    if (!emailSituation.trim()) return;
    setEmailLoading(true);
    setEmailResult("");
    try {
      const response = await fetch("/api/ai/draft-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          template: emailSelectedTemplate, 
          situation: emailSituation,
          tone: emailSelectedTone 
        }),
      });
      const data = await response.json();
      if (response.ok) {
        setEmailResult(data.result);
      } else {
        setEmailResult("Subject: Project Status and Boundary Alignment\n\nHi Team,\n\nI wanted to share updates on my milestones...");
      }
    } catch {
      setEmailResult("Subject: Capacity Update\n\nHi Team, I am structuring this target to meet standard deadlines safely.");
    } finally {
      setEmailLoading(false);
    }
  };

  const handleFetchScript = async () => {
    if (!scriptSituation.trim()) return;
    setScriptLoading(true);
    setScriptResult("");
    try {
      const response = await fetch("/api/ai/gen-script", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scriptType: scriptSelectedTemplate, situation: scriptSituation }),
      });
      const data = await response.json();
      if (response.ok) {
        setScriptResult(data.result);
      } else {
        setScriptResult("ASSERTIVE SCRIPT: Thanks for thinking of me! I want to give this target my full focus, so I will need to finish Project X first.");
      }
    } catch {
      setScriptResult("ASSERTIVE: Let's lock this timing on Monday so we are structured.");
    } finally {
      setScriptLoading(false);
    }
  };

  const handleFetchRSDCheck = async () => {
    if (!rsdSpiral.trim()) return;
    setRsdLoading(true);
    setRsdResult("");
    try {
      const response = await fetch("/api/ai/rsd-check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ spiral: rsdSpiral }),
      });
      const data = await response.json();
      if (response.ok) {
        setRsdResult(data.result);
      } else {
        setRsdResult("Facts: They delayed a meeting. Interpretation: They might be busy with client obligations, not signaling an issue with your capability. Take a somatic breath.");
      }
    } catch {
      setRsdResult("Objective Check: This feedback is standard operational updates. Your overall trajectory is entirely safe.");
    } finally {
      setRsdLoading(false);
    }
  };

  const handleFetchMeetingPrep = async () => {
    if (!meetingTopic.trim()) return;
    setMeetingLoading(true);
    setMeetingResult("");
    try {
      const response = await fetch("/api/ai/meeting-prep", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic: meetingTopic,
          people: meetingPeople,
          goal: meetingGoal,
          anxietyLevel: meetingAnxiety,
        }),
      });
      const data = await response.json();
      if (response.ok) {
        setMeetingResult(data.result);
      } else {
        setMeetingResult("**WALK IN KNOWING:**\n- Your core metrics are healthy\n- You completed last weeks priority checklist safely");
      }
    } catch {
      setMeetingResult("**WALK IN KNOWING:**\n- You are ready and well capable.");
    } finally {
      setMeetingLoading(false);
    }
  };

  // Time Blindness Logger Functions
  const handleStartTbcTimer = () => {
    if (!tbcTask.trim() || !tbcEstimate) return;
    setTbcSeconds(0);
    setTbcTimerActive(true);
    triggerToast("Time blind timer running! Complete your task organically without watching the minutes.");
  };

  const handleStopTbcTimer = () => {
    setTbcTimerActive(false);
    const measuredMins = Math.max(1, Math.round(tbcSeconds / 60));
    const rawEst = Number(tbcEstimate);
    const multiplier = measuredMins / rawEst;

    const newRecord = {
      id: crypto.randomUUID(),
      task: tbcTask,
      estimated: rawEst,
      actual: measuredMins,
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      ratio: Number(multiplier.toFixed(1))
    };

    const updated = [newRecord, ...tbcHistory].slice(0, 5);
    setTbcHistory(updated);
    localStorage.setItem("fh_tbc_history", JSON.stringify(updated));

    // reset fields
    setTbcTask("");
    setTbcEstimate("");
    triggerToast(`Logged. Real actual time: ${measuredMins} mins vs ${rawEst} mins estimated.`);
  };

  const getMultiplierAvg = () => {
    if (tbcHistory.length === 0) return 1.4;
    const sum = tbcHistory.reduce((acc, h) => acc + h.ratio, 0);
    return Number((sum / tbcHistory.length).toFixed(1));
  };

  // Win Logger Functions
  const handleAddWinObj = () => {
    if (!newWinText.trim()) return;
    const item: Win = {
      id: crypto.randomUUID(),
      text: newWinText,
      category: newWinCat,
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" })
    };
    const updated = [item, ...winsList];
    setWinsList(updated);
    localStorage.setItem("fh_wins_list", JSON.stringify(updated));
    setNewWinText("");
    triggerToast("Excellent work! Win recorded in your archive.");
  };

  const handleDeleteWin = (id: string) => {
    const updated = winsList.filter(w => w.id !== id);
    setWinsList(updated);
    localStorage.setItem("fh_wins_list", JSON.stringify(updated));
    triggerToast("Win removed from archive.");
  };

  const downloadWinJournalTxt = () => {
    if (winsList.length === 0) return;
    const headers = [
      "========================================",
      "          FLOWHER WIN JOURNAL           ",
      "      Your Portable Evidence Log        ",
      "========================================\n",
    ];
    const body = winsList.map((w, idx) => {
      return `${idx + 1}. [${w.category}] - ${w.date}\n   "${w.text}"\n`;
    });
    const blob = new Blob([...headers, ...body], { type: "text/plain;charset=utf-8" });
    const fileUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = fileUrl;
    link.download = "FlowHer_Secret_Win_Receipts.txt";
    link.click();
    URL.revokeObjectURL(fileUrl);
  };

  // Masking Debt Logger
  const handleToggleMaskType = (type: string) => {
    if (selectedMaskTypes.includes(type)) {
      setSelectedMaskTypes(prev => prev.filter(t => t !== type));
    } else {
      setSelectedMaskTypes(prev => [...prev, type]);
    }
  };

  const getRecoveryAdvice = (debt: number) => {
    if (debt === 0) {
      return {
        level: "Excellent Balance",
        duration: 0,
        tip: "You have excellent neuro-energetic balance right now. Maintain these boundaries! Keep sensory inputs regulated.",
        activity: "No active recovery needed yet.",
        color: "text-green-400"
      };
    }
    if (debt >= 40) {
      return {
        level: "Severe Sensory Depletion",
        duration: Math.max(45, Math.round(debt * 2.5)),
        tip: "Nervous system burnout warning. Limit all cognitive incoming signals immediately. Lay down in a dark or dim space with noise-cancelling headphones on (no music or audiobooks) for at least 45 minutes to let your brain's auditory and visual gateways cool down.",
        activity: "Screen-Free Deep Sensory Deprivation & Resting",
        color: "text-rose-400"
      };
    }
    if (debt >= 20) {
      return {
        level: "High Decompression Demand",
        duration: Math.round(debt * 2.5),
        tip: "System fatigue is elevated. Engage in sensory regulation: spend 20 to 30 minutes in dim or warm ambient light, wearing comfy eye masks, away from any screens. Try listening to soft brown noise or slow breathing without typing.",
        activity: "Sensory Calm Decompression & Eyes-Closed Re-centering",
        color: "text-amber-400"
      };
    }
    return {
      level: "Mild Boundary Drift",
      duration: Math.max(10, Math.round(debt * 2.5)),
      tip: "Minor executive fatigue. Step away from your desk for 10-15 minutes, splash ice-cold water on your face to stimulate the vagus nerve, or perform 3 minutes of somatic shaking/stretching to reset neural tone.",
      activity: "Somatic Shaking Reset or Cold Water Vagal Stimulation",
      color: "text-teal"
    };
  };

  const handleLogMaskMoment = () => {
    if (selectedMaskTypes.length === 0) return;
    const costScore = Math.round(selectedMaskTypes.length * (maskIntensity / 5) * 8);

    const moment: MaskMoment = {
      id: crypto.randomUUID(),
      types: selectedMaskTypes,
      intensity: maskIntensity,
      cost: costScore,
      note: maskNote,
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      time: new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })
    };

    const updated = [moment, ...allMaskMoments].slice(0, 10);
    setAllMaskMoments(updated);
    localStorage.setItem("fh_mask_moments", JSON.stringify(updated));

    // Calculate prompt recovery
    const advice = getRecoveryAdvice(costScore);
    setShowRecoveryAlert({
      cost: costScore,
      types: [...selectedMaskTypes],
      advice
    });

    // Clear
    setSelectedMaskTypes([]);
    setMaskIntensity(5);
    setMaskNote("");
    triggerToast(`Logged masking debt of ${costScore} points! Recovery advice available below.`);
  };

  const getCombinedDailyDebt = () => {
    const todayStr = new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" });
    const todayMoments = allMaskMoments.filter(m => m.date === todayStr);
    return todayMoments.reduce((acc, curr) => acc + curr.cost, 0);
  };

  return (
    <div className="min-h-screen bg-warm text-[#1C0A2E] flex flex-col items-center relative">
      
      {/* Offline Status Tracker Bannering */}
      {isOffline && (
        <div className="w-full bg-[#E8845C] text-white text-center text-xs py-1.5 font-medium flex items-center justify-center gap-2 sticky top-0 z-50">
          <AlertTriangle className="h-4 w-4" />
          <span>You are currently operating offline. AI functions are offline, but local tracking works perfectly.</span>
        </div>
      )}

      {/* Global Interactive Notification Toast */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 bg-[#3D1052] text-[#FAF6F0] px-5 py-3 rounded-xl shadow-xl flex items-center gap-2 border border-mag/40 transition-all text-sm animate-bounce">
          <Sparkles className="h-4 w-4 text-mag" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Somatic Safe Space Overlays (SOS Overlay) */}
      {isSosActive && (
        <div className="fixed inset-0 z-50 bg-[#1C0A2E]/95 backdrop-blur-xl flex flex-col items-center justify-center p-6 text-center text-[#FAF6F0]">
          <div className="max-w-md w-full flex flex-col items-center">
            <ShieldAlert className="h-12 w-12 text-[#E8845C] mb-4 animate-pulse" />
            <h2 className="font-serif text-3xl font-light mb-3">Halt. You are entirely safe.</h2>
            <p className="text-sm text-gray-300 mb-8 leading-relaxed font-light">
              Your sensitive nervous system has encountered temporary overload. It's not a performance error. It is useful feedback. Let's restore regulation in exactly 60 seconds.
            </p>

            {/* Guided circle breath animation mock */}
            <div className="w-40 h-40 rounded-full border border-teal/40 flex items-center justify-center relative mb-8">
              <div className="absolute inset-2 rounded-full bg-teal/10 border-2 border-teal animate-ping" />
              <span className="font-serif italic text-teal text-lg z-10">{sosPhase}</span>
            </div>

            {/* Grounding 5-4-3-2-1 Somatic receipt */}
            <div className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 mb-8 text-left text-sm space-y-2">
              <span className="text-xs tracking-wider text-teal block uppercase font-mono mb-2">Somatic Grounding Triage</span>
              <div>👁️ Observe <strong className="text-[#FAF7FF]">5 physical objects</strong> on your desk.</div>
              <div>✋ Touch <strong className="text-[#FAF7FF]">4 physical patterns</strong> near your palm.</div>
              <div>👂 Recognize <strong className="text-[#FAF7FF]">3 surrounding noise frequencies</strong>.</div>
              <div>👃 Breathe in and name <strong className="text-[#FAF7FF]">2 smell profiles</strong>.</div>
              <div>👄 Touch your tongue to notice <strong className="text-[#FAF7FF]">1 focal taste parameter</strong>.</div>
            </div>

            <button 
              onClick={() => setIsSosActive(false)}
              className="w-full py-3.5 bg-gradient-to-r from-plum to-mag text-white rounded-xl text-sm font-medium hover:opacity-90 transition-all font-sans"
            >
              Nervous System Reset: Close Overlay
            </button>
          </div>
        </div>
      )}

      {/* Upgrade Core Plan Gate Modal Overlay */}
      {showGateModal && (
        <div className="fixed inset-0 z-50 bg-[#1C0A2E]/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#FAF6F0] border-2 border-[#C45BAA]/35 text-[#1C0A2E] rounded-3xl p-8 max-w-md w-full shadow-2xl relative">
            <button 
              onClick={() => setShowGateModal(null)} 
              className="absolute top-4 right-4 p-1 rounded-full hover:bg-black/5 text-[#8A7F8D]"
            >
              <X className="h-5 w-5" />
            </button>
            <div className="bg-mag/10 text-mag px-3 py-1 rounded-full text-xs font-mono uppercase tracking-widest inline-block mb-3">
              ✦ Premium Feature Guard
            </div>
            <h3 className="font-serif text-3xl font-light mb-2">This is a <em className="text-mag italic font-serif">Core feature</em></h3>
            <p className="text-sm text-gray-600 mb-6 leading-relaxed">
              Unlock entire custom survival scripts, full time blindness multipliers tracker, RSD Toolkit, and unlimited Wins logging by stepping up to Core.
            </p>

            {/* Spots ticker indicators */}
            <div className="bg-plum/5 border border-[#C45BAA]/20 rounded-2xl p-4 mb-6">
              <div className="flex justify-between text-xs font-mono mb-1 text-plum">
                <span>Core Founding Slots remaining</span>
                <span className="text-mag font-semibold">{spotsRemaining} left</span>
              </div>
              <div className="w-full h-2.5 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-[#E8845C] to-[#C45BAA] rounded-full transition-all duration-1000" 
                  style={{ width: `${((200 - spotsRemaining) / 200) * 100}%` }} 
                />
              </div>
              <p className="text-[11px] text-[#8A7F8D] mt-2">
                Only {spotsRemaining} of our 200 slots remain. Locked pricing ($24.99/month) is secured permanently for those who claim today.
              </p>
            </div>

            <div className="space-y-3">
              <button 
                onClick={() => {
                  setUserPlan("core");
                  setShowGateModal(null);
                  triggerToast("Promo Sim: You are now upgraded to FlowHer Core!");
                }}
                className="w-full py-4 bg-gradient-to-r from-plum to-mag text-white font-sans text-sm font-semibold rounded-xl hover:opacity-90 shadow-md transition-all flex items-center justify-center gap-2"
              >
                <span>Unlock Core (Simulate Beta Promo Code)</span>
                <ArrowRight className="h-4 w-4" />
              </button>
              <button 
                onClick={() => {
                  setShowGateModal(null);
                  setCurrentView("founding");
                }}
                className="w-full py-3 bg-plum/10 text-plum font-sans text-xs font-medium rounded-xl hover:bg-plum/15 transition-all"
              >
                Explore Founding Page Details
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Onboarding Wizard Dialogue */}
      {showOnboarding && (
        <div className="fixed inset-0 z-50 bg-[#1C0A2E]/93 backdrop-blur-lg flex items-center justify-center p-4">
          <div className="bg-[#FAF6F0] text-[#1C0A2E] rounded-3xl p-8 max-w-lg w-full border border-[#C45BAA]/20 shadow-2xl">
            <span className="text-xs font-mono tracking-widest text-[#C45BAA] uppercase block mb-2">Step {onboardingStep} of 2</span>
            
            {onboardingStep === 1 ? (
              <div>
                <h3 className="font-serif text-2xl font-light mb-4">How does your brain operate at work?</h3>
                <p className="text-xs text-[#8A7F8D] mb-6">This configures custom workspace boundary parameters in the home tab tips.</p>
                <div className="grid grid-cols-1 gap-3 mb-8">
                  {[
                    "ADHD / Hyper-divergent focus pattern",
                    "Chronic burn-out / low organic cognitive reserves",
                    "Late-diagnosed Autism / high social masking patterns",
                    "Sensory hypersensitivity & high workplace anxiety"
                  ].map((p, idx) => (
                    <button 
                      key={idx}
                      onClick={() => setOnboardingAnswers(prev => ({ ...prev, profile: p }))}
                      className={`p-4 rounded-xl border-2 text-left text-sm transition-all ${
                        onboardingAnswers.profile === p 
                          ? "border-mag bg-[#C45BAA]/10 text-[#3D1052]" 
                          : "border-gray-200 bg-white hover:border-mag/30"
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
                <button 
                  disabled={!onboardingAnswers.profile}
                  onClick={() => setOnboardingStep(2)}
                  className="w-full py-3.5 bg-[#3D1052] text-white rounded-xl text-sm font-medium hover:opacity-90 disabled:opacity-50 transition-all font-sans"
                >
                  Proportionate Setup: Next Section →
                </button>
              </div>
            ) : (
              <div>
                <h3 className="font-serif text-2xl font-light mb-4">What is your principal goal this quarter?</h3>
                <p className="text-xs text-[#8A7F8D] mb-6">Select your initial functional priority tracker.</p>
                <div className="grid grid-cols-1 gap-3 mb-8">
                  {[
                    "Construct an Imposter Shield with daily proof recipes",
                    "Minimize masking fatigue debt and track rest metrics",
                    "Overcome executive dysfunction via Smallest Steps method",
                    "Advocate safely for custom corporate ADA accommodations"
                  ].map((g, idx) => (
                    <button 
                      key={idx}
                      onClick={() => setOnboardingAnswers(prev => ({ ...prev, primaryGoal: g }))}
                      className={`p-4 rounded-xl border-2 text-left text-sm transition-all ${
                        onboardingAnswers.primaryGoal === g 
                          ? "border-mag bg-[#C45BAA]/10 text-[#3D1052]" 
                          : "border-gray-200 bg-white hover:border-mag/30"
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
                <div className="flex gap-4">
                  <button 
                    onClick={() => setOnboardingStep(1)}
                    className="flex-1 py-3 bg-gray-200 text-gray-700 rounded-xl text-sm font-medium hover:bg-gray-300 transition-all"
                  >
                    Back
                  </button>
                  <button 
                    disabled={!onboardingAnswers.primaryGoal}
                    onClick={handleCompleteOnboarding}
                    className="flex-1 py-3 bg-gradient-to-r from-plum to-mag text-white rounded-xl text-sm font-medium hover:opacity-90 disabled:opacity-50 transition-all"
                  >
                    Finish Profiles Configuration
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Auth Account / Login Modal dialogue */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 bg-[#1C0A2E]/85 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#FAF6F0] rounded-3xl p-8 max-w-md w-full border border-mag/20 shadow-2xl relative">
            <button 
              onClick={() => setShowAuthModal(false)}
              className="absolute top-4 right-4 text-[#8A7F8D] hover:text-[#1C0A2E]"
            >
              <X className="h-5 w-5" />
            </button>
            <div className="flex justify-center mb-6">
              <span className="font-serif italic text-plum text-2xl font-light">Flow<em className="text-mag not-italic font-sans">Her</em>™</span>
            </div>

            <div className="flex gap-4 mb-6 border-b border-gray-200">
              <button 
                onClick={() => setAuthMode("signup")}
                className={`flex-1 pb-3 text-sm font-medium ${authMode === "signup" ? "text-mag border-b-2 border-mag" : "text-gray-400"}`}
              >
                Create Account
              </button>
              <button 
                onClick={() => setAuthMode("signin")}
                className={`flex-1 pb-3 text-sm font-medium ${authMode === "signin" ? "text-mag border-b-2 border-mag" : "text-gray-400"}`}
              >
                Sign In
              </button>
            </div>

            {authError && <div className="text-xs text-[#E8845C] bg-[#E8845C]/10 p-3 rounded-lg mb-4 text-center">{authError}</div>}

            <form onSubmit={handleAuthSubmit} className="space-y-4">
              {authMode === "signup" && (
                <div>
                  <label className="text-xs font-mono text-plum tracking-wider block mb-1">Your First Name</label>
                  <input 
                    type="text"
                    required
                    value={authForm.name}
                    onChange={e => setAuthForm({ ...authForm, name: e.target.value })}
                    className="w-full bg-white border border-[#C45BAA]/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-mag"
                    placeholder="Enter name"
                  />
                </div>
              )}
              <div>
                <label className="text-xs font-mono text-plum tracking-wider block mb-1">Work Email</label>
                <input 
                  type="email"
                  required
                  value={authForm.email}
                  onChange={e => setAuthForm({ ...authForm, email: e.target.value })}
                  className="w-full bg-white border border-[#C45BAA]/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-mag"
                  placeholder="name@company.com"
                />
              </div>
              <div>
                <label className="text-xs font-mono text-plum tracking-wider block mb-1">Pass Key</label>
                <input 
                  type="password"
                  required
                  minLength={4}
                  value={authForm.password}
                  onChange={e => setAuthForm({ ...authForm, password: e.target.value })}
                  className="w-full bg-white border border-[#C45BAA]/20 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-mag"
                  placeholder="••••••••"
                />
              </div>
              {authMode === "signup" && (
                <div>
                  <label className="text-xs font-mono text-plum tracking-wider block mb-1">Optional Beta Code</label>
                  <input 
                    type="text"
                    value={authForm.promo}
                    onChange={e => setAuthForm({ ...authForm, promo: e.target.value })}
                    className="w-full bg-white border border-[#C45BAA]/20 rounded-xl px-4 py-2.5 text-sm uppercase font-mono tracking-widest focus:outline-none focus:border-mag"
                    placeholder="e.g. BETAFLOWHER2026"
                  />
                  <span className="text-[10px] text-[#8A7F8D] mt-1 block leading-relaxed">Entering standard beta promo codes grants immediate local simulated premium Core access.</span>
                </div>
              )}

              <button 
                type="submit"
                className="w-full py-4 bg-gradient-to-r from-plum to-mag text-white text-sm font-semibold rounded-xl hover:opacity-95 shadow-md transition-all font-sans"
              >
                {authMode === "signup" ? "Initiate Free Access" : "Secure System Login"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
           LANDING VIEW SCREEN
         ========================================== */}
      {currentView === "landing" && (
        <div className="w-full max-w-7xl px-4 md:px-8 flex flex-col items-center">
          
          {/* Header navigation */}
          <header className="w-full py-6 flex items-center justify-between border-b border-[#C45BAA]/10 sticky top-0 bg-[#FAF6F0] z-40 transition-all select-none">
            <span className="font-serif italic text-3xl font-light text-[#3D1052] tracking-wider leading-none">
              Flow<em className="text-mag not-italic font-sans font-medium">Her</em>™
            </span>
            <div className="flex items-center gap-2 md:gap-4">
              <button 
                onClick={() => setCurrentView("founding")}
                className="text-xs font-sans text-mag font-semibold py-2 px-4 rounded-full border border-[#C45BAA]/65 hover:bg-mag/5 bg-gradient-to-r from-mag/5 to-transparent hover:shadow-sm transition-all hidden md:flex items-center gap-1.5 animate-pulse"
              >
                ★ Only {spotsRemaining} Spots Left
              </button>
              <button 
                onClick={() => {
                  if (user) {
                    setCurrentView("app");
                  } else {
                    setAuthMode("signup");
                    setShowAuthModal(true);
                  }
                }}
                className="bg-[#3D1052] text-[#FAF6F0] hover:bg-mag hover:shadow-lg transition-all text-xs font-sans font-medium py-2 px-5 rounded-full"
              >
                Open Dashboard ➔
              </button>
            </div>
          </header>

          {/* Hero space */}
          <section className="py-16 md:py-24 grid md:grid-cols-2 gap-12 items-center w-full">
            <div className="flex flex-col items-start space-y-6">
              <span className="text-xs uppercase tracking-widest text-[#C45BAA] font-medium block">
                ✦ Designed for organic, non-linear trajectories
              </span>
              <h1 className="font-serif text-5xl md:text-6xl font-light leading-[1.1] text-plum">
                The workspace wasn't designed for <em className="italic text-mag font-serif">your brain.</em><br />FlowHer was.
              </h1>
              <p className="text-gray-600 text-sm md:text-base leading-relaxed max-w-lg font-light">
                A digital productivity oasis and evidence space constructed specifically for professional women who are <strong>neurodivergent, clinically burned out, or non-linear creators</strong>. Stop performing corporate standard metrics; instead, build dynamic systems tailored entirely to your cognitive energy capacity.
              </p>

              {/* Tag system */}
              <div className="flex flex-wrap gap-2 py-3">
                {["Inattentive ADHD", "Late-diagnosed Autism", "Sensory Exhaustion", "Executive Fatigue", "RSD Saboteurs"].map((t, i) => (
                  <span key={i} className="text-xs font-sans py-1.5 px-3.5 rounded-full border border-mag/20 bg-mag/5 text-[#3D1052] font-semibold">
                    {t}
                  </span>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
                <button 
                  onClick={() => setCurrentView("founding")}
                  className="bg-gradient-to-r from-plum to-mag text-white text-sm font-semibold py-4 px-8 rounded-2xl hover:opacity-95 shadow-md flex items-center justify-center gap-2"
                >
                  <span>Secure Core Founding Spot</span>
                  <ArrowRight className="h-4.5 w-4.5" />
                </button>
                <button 
                  onClick={() => {
                    setAuthMode("signup");
                    setShowAuthModal(true);
                  }}
                  className="bg-plum/10 text-plum border border-plum/15 text-sm font-medium py-4 px-8 rounded-2xl hover:bg-plum/15 transition-all text-center"
                >
                  Initiate Basic Demo Access
                </button>
              </div>

              <span className="text-xs text-[#8A7F8D] font-light italic">
                🔒 Free access includes daily check-ins, focus timer, and basic survival utilities. No card required.
              </span>
            </div>

            {/* Simulated Desktop Preview Card mockup */}
            <div className="bg-[#1C0A2E] rounded-[2.5rem] border-4 border-plum p-6 md:p-8 shadow-2xl space-y-6 text-[#FAF6F0] relative overflow-hidden transition-all duration-300">
              <div className="absolute top-0 right-0 w-48 h-48 bg-mag/10 rounded-full blur-[80px]" />
              
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <div className="flex items-center gap-2 font-serif italic text-lg">
                  <Brain className="text-mag h-5 w-5" />
                  <span>FlowHer Workplace Console</span>
                </div>
                <span className="text-[10px] font-mono tracking-widest text-[#E8845C] bg-[#E8845C]/15 px-2.5 py-1 rounded-full uppercase">
                  SIMULATION TERMINAL
                </span>
              </div>

              <div className="space-y-4">
                <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
                  <span className="text-[10px] tracking-widest text-mag uppercase block mb-1">Reality-Checking Coach</span>
                  <p className="text-xs leading-relaxed text-gray-300 italic font-light">
                    "A delayed response from your manager is standard operational traffic, not indicative of any failure. Drop your shoulders 3 inches and focus purely on your next tiny action template."
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-white/5 rounded-xl p-3 border border-white/5 text-center">
                    <Zap className="h-5 w-5 text-[#E8845C] mx-auto mb-1" />
                    <span className="block font-medium">Momentum Step</span>
                  </div>
                  <div className="bg-white/5 rounded-xl p-3 border border-white/5 text-center">
                    <Clock className="h-5 w-5 text-teal mx-auto mb-1" />
                    <span className="block font-medium">Time Multiplier</span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Social Proof Statistics Row */}
          <section className="w-full bg-[#3D1052] text-[#FAF6F0] rounded-[2rem] py-12 px-6 md:px-12 grid grid-cols-2 md:grid-cols-4 gap-8 justify-between text-center mt-6">
            <div>
              <span className="font-serif text-4xl block font-light text-[#E8845C]">1 in 5</span>
              <span className="text-xs text-white/60 tracking-wider">Neurological diversity ratio</span>
            </div>
            <div>
              <span className="font-serif text-4xl block font-light text-mag">70%</span>
              <span className="text-xs text-white/60 tracking-wider">Late Adulthood Diagnoses</span>
            </div>
            <div>
              <span className="font-serif text-4xl block font-light text-teal">100%</span>
              <span className="text-xs text-white/60 tracking-wider">Evidence-Based Compassion</span>
            </div>
            <div>
              <span className="font-serif text-4xl block font-light text-gold">40+ Tabs</span>
              <span className="text-xs text-white/60 tracking-wider">Managed Calmly Offline</span>
            </div>
          </section>

          {/* Why FlowHer sections */}
          <section className="py-20 w-full">
            <div className="text-center max-w-2xl mx-auto mb-16 space-y-2">
              <span className="text-xs tracking-widest text-mag uppercase font-semibold">Interactive Grid Profiles</span>
              <h2 className="font-serif text-4xl font-light text-plum">You fully belong here if...</h2>
              <p className="text-xs text-[#8A7F8D]">Typical templates have failed your non-linear focus architecture.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  emoji: "⚡",
                  title: "Inattentive Focus Waves",
                  body: "The tasks either vanish entirely or present overwhelming activation barriers, resulting in procrastination cycles and frantic midnight completions."
                },
                {
                  emoji: "🌊",
                  title: "RSD Sensitivities",
                  body: "A neutral piece of Slack feedback triggers massive somatic flight-or-fight signals instantly, completely hijacking focus for hours."
                },
                {
                  emoji: "🎭",
                  title: "Heavy Social Masking",
                  body: "Expending huge reserves performing high competence in meetings, leaving you functionally drained and exhausted before the workday actually completes."
                }
              ].map((c, i) => (
                <div key={i} className="bg-white border border-mag/10 p-6 rounded-2xl hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                  <span className="text-3xl block mb-3">{c.emoji}</span>
                  <h3 className="font-serif text-xl font-medium text-plum mb-2">{c.title}</h3>
                  <p className="text-xs text-gray-600 leading-relaxed font-light">{c.body}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Essential Features of the FlowHer app */}
          <section className="bg-plum text-[#FAF6F0] py-16 px-6 md:px-12 rounded-[2.5rem] w-full relative overflow-hidden">
            <div className="absolute -top-12 -left-12 w-64 h-64 bg-mag/20 rounded-full blur-[100px]" />
            <div className="max-w-3xl mx-auto space-y-12">
              <div className="text-center space-y-3">
                <span className="text-xs text-mag tracking-widest uppercase font-mono block">Complete Toolbox Map</span>
                <h2 className="font-serif text-4xl font-light">Engineered for Your Brain's Operating System</h2>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-1.5">
                  <span className="text-mag text-sm block">⚡ Smallest Step Breakdown</span>
                  <p className="text-xs text-gray-300 font-light leading-relaxed">
                    Overcome initial executive blockages instantly. Give FlowHer any big, daunting project or email, and get immediate, bite-sized items of under 5 minutes work metrics.
                  </p>
                </div>
                <div className="space-y-1.5">
                  <span className="text-teal text-sm block">⏱ Time Blindness Multiplier</span>
                  <p className="text-xs text-gray-300 font-light leading-relaxed">
                    Most trackers expect a linear grid. FlowHer learns your actual operational multiplier over time to support real, anxiety-free timelines planning metrics.
                  </p>
                </div>
                <div className="space-y-1.5">
                  <span className="text-[#E8845C] text-sm block">🛡️ Actionable RSD Toolkit</span>
                  <p className="text-xs text-gray-300 font-light leading-relaxed">
                    Isolate facts from spirals. Get compassionate, clear reality checkpoints instantly to de-escalate sensitive mental feedback loops and soothe adrenaline surges.
                  </p>
                </div>
                <div className="space-y-1.5">
                  <span className="text-[#D4A843] text-sm block">⭐ Win Receipts Journal</span>
                  <p className="text-xs text-gray-300 font-light leading-relaxed">
                    Don't let your manager or imposter narratives dominate your narrative. Log hard proof and download your evidence directory safely anytime.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Pricing Tiers and Limits FAQ accordion list */}
          <section className="py-20 w-full max-w-4xl">
            <div className="text-center mb-12 space-y-2">
              <h2 className="font-serif text-4xl font-light text-plum">Essential Clarifications</h2>
              <p className="text-xs text-[#8A7F8D]">Transparent alignments for sustainable development.</p>
            </div>

            <div className="space-y-4">
              {[
                {
                  q: "Who is the designer behind FlowHer?",
                  a: "FlowHer is designed by Silvella Strain (MBA, ADHD Inattentive) who was tired of typical standard corporate metrics neglecting neurodiverse talent pools. It is constructed entirely to empower brains that work organically."
                },
                {
                  q: "How does the simulated trial operate?",
                  a: "Entering the demo simulation gives you full functional access to home tabs, local dopamine checkins, somatic resets, and Win logs tracking. No financial commitments are required for core testing features."
                },
                {
                  q: "Are the AI functions safe and private?",
                  a: "Yes. All processed items are proxied server-side via Gemini API under strict privacy parameters and never submitted to general indices for training."
                }
              ].map((item, idx) => (
                <div key={idx} className="bg-white border border-mag/10 rounded-2xl p-6 transition-all">
                  <button 
                    onClick={() => setFaqOpenIdx(faqOpenIdx === idx ? null : idx)}
                    className="w-full text-left font-serif text-lg text-plum flex items-center justify-between"
                  >
                    <span>{item.q}</span>
                    <ChevronDown className={`h-5 w-5 text-mag transition-transform ${faqOpenIdx === idx ? "rotate-180" : ""}`} />
                  </button>
                  {faqOpenIdx === idx && (
                    <p className="text-xs text-gray-600 mt-4 leading-relaxed font-light">{item.a}</p>
                  )}
                </div>
              ))}
            </div>
          </section>

          {/* Simple CTA footer */}
          <footer className="w-full py-12 border-t border-mag/10 text-center space-y-4 text-xs text-[#8A7F8D]">
            <p className="font-serif italic text-lg text-[#3D1052]">FlowHer™ © 2026</p>
            <p className="font-light">Engineered with rigorous respect and structural agency for professional neurodivergent women.</p>
          </footer>
        </div>
      )}

      {/* ==========================================
           FOUNDING SPOTS PAGE VIEW
         ========================================== */}
      {currentView === "founding" && (
        <div className="w-full max-w-4xl px-4 py-12 space-y-12">
          
          <button 
            onClick={() => setCurrentView("landing")}
            className="text-xs text-[#8A7F8D] hover:text-[#3D1052] font-semibold flex items-center gap-2"
          >
            ← Back to main lobby
          </button>

          <div className="text-center space-y-4">
            <span className="text-xs px-3 py-1 bg-[#C45BAA]/15 text-mag uppercase rounded-full tracking-widest font-mono">
              ✦ Exclusive Core Beta Rate
            </span>
            <h1 className="font-serif text-5xl font-light text-plum">
              Secure Your Lifetime Rate. <em className="italic text-mag font-serif">Forever.</em>
            </h1>
            <p className="text-gray-600 font-light max-w-md mx-auto text-sm leading-relaxed">
              We are reserving exactly 200 Core Founding spots at $24.99/month (locked indefinitely and guaranteed never to increase). Let us structure standard corporate progress together.
            </p>
          </div>

          <div className="bg-white border-2 border-[#C45BAA]/35 rounded-[2rem] p-8 md:p-12 shadow-xl space-y-8">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="space-y-6">
                <span className="text-xs tracking-wider text-teal font-mono uppercase block">What is unlocked instantly</span>
                <ul className="space-y-3.5 text-xs text-gray-700 font-light">
                  <li className="flex items-start gap-2.5">
                    <CheckCircle className="h-4 w-4 text-teal shrink-0 mt-0.5" />
                    <span>Unlimited Smallest Step Breakdown queries (AI-driven)</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle className="h-4 w-4 text-teal shrink-0 mt-0.5" />
                    <span>RSD reality tracker metrics de-escalator</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle className="h-4 w-4 text-teal shrink-0 mt-0.5" />
                    <span>All automated survival scripts drafting models</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle className="h-4 w-4 text-teal shrink-0 mt-0.5" />
                    <span>Private, device-encrypted Win Logs repository exports</span>
                  </li>
                </ul>
              </div>

              {/* Pricing breakdown box */}
              <div className="bg-[#1C0A2E] text-white p-6 rounded-2xl flex flex-col items-center justify-center text-center space-y-4 relative overflow-hidden">
                {/* Subtle top light flare */}
                <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-teal via-[#E8845C] to-[#C45BAA]" />
                
                <span className="text-xs uppercase tracking-widest text-[#E8845C] font-mono">Lifetime Core Founding Rate</span>
                <div className="font-serif text-6xl block text-white font-light">
                  $24<span className="text-2xl">.99</span>
                </div>
                <span className="text-xs text-white/50 tracking-wider">Per Month / Cancel Safely Anytime</span>

                {/* Urgency Counter indicator */}
                <div className="w-full bg-[#270E40] border border-[#C45BAA]/40 rounded-xl p-3.5 space-y-2 text-left">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#E8845C] animate-pulse" />
                      <span className="text-[10px] font-mono tracking-wider text-orange-300 uppercase font-bold">Urgent Intake Notice</span>
                    </div>
                    <span className="text-[10px] font-mono text-gray-300 font-semibold">{200 - spotsRemaining} / 200 Claimed</span>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="flex justify-between items-center text-xs">
                      <strong className="text-white font-medium text-[11px]">Only {spotsRemaining} founding spots left!</strong>
                      <span className="text-[9px] text-[#E8845C] font-mono">Intake closing soon</span>
                    </div>
                    <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                      <div 
                        className="bg-gradient-to-r from-[#E8845C] to-[#C45BAA] h-full transition-all duration-1000" 
                        style={{ width: `${((200 - spotsRemaining) / 200) * 100}%` }}
                      />
                    </div>
                  </div>
                  
                  <p className="text-[9px] text-gray-400 font-sans leading-normal">
                    Due to local device caching resources and private vector memory sandboxes, we cap physical beta groups to maintain sub-100ms response timelines. Secure your place now.
                  </p>
                </div>
                
                <button 
                  onClick={() => {
                    setUserPlan("core");
                    setCurrentView("app");
                    triggerToast("Account configured as CORE premium automatically.");
                  }}
                  className="w-full py-4 bg-gradient-to-r from-[#E8845C] to-[#C45BAA] text-white font-sans text-sm font-semibold rounded-xl hover:opacity-90 shadow-md transition-all cursor-pointer"
                >
                  Confirm simulated beta check-in ➔
                </button>
              </div>
            </div>
          </div>

          <p className="text-center text-xs text-[#8A7F8D] italic font-light">
            Silvella Strain · Founder, FlowHer LLC · Neurodivergent advocate
          </p>
        </div>
      )}

      {/* ==========================================
           MAIN APP VIEW (Dashboard space)
         ========================================== */}
      {currentView === "app" && (
        <div className="w-full min-h-screen bg-[#130620] text-[#FAF6F0] flex flex-col justify-between items-center relative overflow-x-hidden">
          
          {/* Header toolbar */}
          <header className="w-full max-w-lg px-5 py-4 flex items-center justify-between border-b border-white/5 sticky top-0 bg-[#130620]/90 backdrop-blur-md z-35 font-sans">
            <div className="flex flex-col items-start select-none">
              <span className="font-serif text-xl font-light">Flow<em className="text-mag not-italic font-sans">Her</em>™</span>
              <span className="text-[9px] tracking-widest text-mag uppercase font-mono">
                {userPlan === "core" ? "Premium Active Profile" : "Trial Profile Session"}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button 
                onClick={() => {
                  setEditName(user?.name || "Professional User");
                  setEditBio(profileBio);
                  setIsEditingProfile(false);
                  setShowProfileModal(true);
                }}
                className="h-8 w-8 rounded-full border border-[#C45BAA]/40 bg-white/5 text-[#C45BAA] overflow-hidden flex items-center justify-center hover:bg-[#C45BAA]/10 hover:border-mag transition-all cursor-pointer relative group"
                title="View & Edit User Profile"
              >
                {profilePic ? (
                  <img src={profilePic} alt="Profile" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <div className="h-full w-full bg-gradient-to-tr from-plum to-[#E085C9] text-white flex items-center justify-center text-xs font-mono font-bold select-none uppercase">
                    {(user?.name || "U")[0]}
                  </div>
                )}
              </button>
              <button 
                onClick={handleRestartTour}
                className="bg-[#C45BAA]/15 border border-[#C45BAA]/45 text-[#E085C9] text-[10px] tracking-wider font-mono uppercase px-2.5 py-1 rounded-full hover:bg-[#C45BAA]/25 transition-all font-semibold cursor-pointer select-none shrink-0"
                title="Launch Onboarding tour"
              >
                ✨ Tour
              </button>
              <button 
                onClick={() => setIsSosActive(true)}
                className="bg-[#E8845C]/15 border border-[#E8845C]/45 text-[#E8845C] text-[10px] tracking-wider font-mono uppercase px-3 py-1 rounded-full hover:bg-[#E8845C]/25 transition-all text-sm font-semibold"
              >
                🚨 SOS Help
              </button>
              <button 
                onClick={handleSignOut}
                className="p-1.5 rounded-full hover:bg-white/5 text-[#8A7F8D]"
                title="Sign out of workspace"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </header>

          {/* MAIN DYNAMIC TAB CONTENT DISPLAY CONTAINER */}
          <main className="w-full max-w-lg px-5 py-6 space-y-6 flex-grow pb-24">
            
            {/* SIMULATED WORKSPACE TOP NOTIFICATIONS */}
            <div className="bg-plum/20 border border-mag/20 rounded-2xl p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-2xl select-none">🔥</span>
                <div className="text-xs">
                  <div className="font-medium text-[#FAF7FF] font-sans">Strategic Streak Checkin</div>
                  <div className="text-[#8A7F8D]">{streakCount} sequential days recorded</div>
                </div>
              </div>
              <button 
                onClick={() => {
                  setStreakCount(prev => prev + 1);
                  triggerToast("Organic checkin logged. Day preservation saved! 🌱");
                }}
                className="text-[10px] uppercase font-mono bg-teal/15 border border-teal/30 text-teal py-1 px-3 rounded-full hover:bg-teal/20"
              >
                Check In
              </button>
            </div>

            {/* NOT TODAY INTERACTIVES */}
            {isNotTodayActive ? (
              <div className="bg-teal/10 border-2 border-teal/30 rounded-2xl p-5 text-center space-y-3">
                <span className="text-2xl block">🌿</span>
                <h4 className="font-serif text-lg font-light text-[#FAF7FF]">Day alignment accepted.</h4>
                <p className="text-xs text-gray-300 font-light leading-relaxed">
                  "You are not behind. You are working with the real physiological battery reserves you possess. Rest is not the opposite of productivity; it is the source."
                </p>
                <div className="text-[10px] text-teal font-mono tracking-widest uppercase">STREAK PROTECTED ⚡</div>
              </div>
            ) : (
              <div className="bg-white/5 border border-white/5 rounded-2xl p-4 flex items-center justify-between text-xs font-sans">
                <div className="space-y-1">
                  <span className="font-medium block text-gray-200">Experiencing extreme dysregulation?</span>
                  <span className="text-[10px] text-[#8A7F8D] block leading-relaxed max-w-xs">Lock in simple recovery status and declare zero demand safely.</span>
                </div>
                <button 
                  onClick={() => setIsNotTodayActive(true)}
                  className="bg-teal/10 hover:bg-teal/15 border border-teal/25 text-teal text-[10px] uppercase px-3 py-1.5 rounded-xl transition-all"
                >
                  Not Today 🌿
                </button>
              </div>
            )}

            {/* TAB RENDERS */}
            
            {/* 1. HOME TAB SCREEN */}
            {appTab === "home" && (
              <div className="space-y-6">
                
                {/* Integrated user bio / profile quick-view card */}
                <div className="bg-gradient-to-br from-[#3D1052]/20 via-[#130620] to-[#C45BAA]/5 border border-[#C45BAA]/15 rounded-2xl p-5 space-y-4">
                  <div className="flex items-start gap-4">
                    <div className="h-16 w-16 rounded-2xl border-2 border-[#C45BAA]/40 bg-[#130620] flex-shrink-0 overflow-hidden relative group">
                      {profilePic ? (
                        <img src={profilePic} alt="Profile" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="h-full w-full bg-gradient-to-tr from-[#3D1052] to-[#C45BAA] text-white flex items-center justify-center text-2xl font-mono font-black select-none uppercase">
                          {(user?.name || "U")[0]}
                        </div>
                      )}
                      <button
                        onClick={() => {
                          setEditName(user?.name || "Professional User");
                          setEditBio(profileBio);
                          setIsEditingProfile(true);
                          setShowProfileModal(true);
                        }}
                        className="absolute inset-0 bg-black/75 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center text-[10px] text-white font-mono cursor-pointer"
                      >
                        Edit
                      </button>
                    </div>

                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="font-serif text-lg text-[#FAF7FF] truncate leading-none">
                          {user?.name || "Professional User"}
                        </h3>
                        <button
                          onClick={() => {
                            setEditName(user?.name || "Professional User");
                            setEditBio(profileBio);
                            setIsEditingProfile(true);
                            setShowProfileModal(true);
                          }}
                          className="text-[9px] font-mono tracking-widest text-[#C45BAA] hover:text-[#FAF7FF] uppercase transition-all cursor-pointer"
                        >
                          Edit Profile
                        </button>
                      </div>
                      
                      <p className="text-xs text-gray-300 leading-relaxed font-sans font-light italic">
                        "{profileBio}"
                      </p>

                      <div className="flex items-center gap-1.5 pt-1.5">
                        <span className="inline-block h-1.5 w-1.5 rounded-full bg-teal animate-pulse"></span>
                        <span className="text-[9px] font-mono tracking-wider text-teal uppercase">
                          Bio Signature Saved Offline
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Mood picker check-in */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                  <span className="text-[10px] tracking-widest text-[#C45BAA] font-mono block uppercase">How is your neuro-chemistry walking in?</span>
                  <div className="grid grid-cols-3 gap-2">
                    {MOODS.map((m, idx) => (
                      <button 
                        key={idx}
                        onClick={() => {
                          setSelectedMoodIndex(idx);
                          localStorage.setItem("fh_selected_mood", String(idx));
                          triggerToast(`Mood checked in as ${m.name} ✓`);
                        }}
                        className={`p-3 rounded-xl border text-center transition-all ${
                          selectedMoodIndex === idx 
                            ? "border-mag bg-[#C45BAA]/10 text-white" 
                            : "border-white/5 bg-white/2"
                        }`}
                      >
                        <span className="text-xl block">{m.emoji}</span>
                        <span className="text-[10px] text-gray-300 block mt-1">{m.name}</span>
                      </button>
                    ))}
                  </div>

                  {/* Emotional state optional descriptive note */}
                  <div className="space-y-1.5 pt-1">
                    <label className="text-[10px] tracking-wider text-gray-400 block font-mono uppercase">
                      Current Emotional State Note (Optional)
                    </label>
                    <textarea
                      value={moodNote}
                      onChange={(e) => {
                        const val = e.target.value;
                        setMoodNote(val);
                        localStorage.setItem("fh_mood_note", val);
                      }}
                      className="w-full bg-[#1C0A2E]/50 border border-[#C45BAA]/20 rounded-xl px-4 py-2.5 text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-mag"
                      placeholder="Type a brief snapshot, e.g., low energy from early meetings, but feeling determined..."
                      rows={2}
                    />
                  </div>

                  {selectedMoodIndex !== null && (
                    <div className="bg-plum/20 rounded-xl p-3 border border-mag/20 text-xs text-gray-200 leading-relaxed font-light italic">
                      {MOODS[selectedMoodIndex].tips}
                    </div>
                  )}
                </div>

                {/* Affirmation slider card */}
                <div className="bg-gradient-to-r from-plum/20 to-[#130620] border border-mag/20 rounded-2xl p-5 space-y-3 relative overflow-hidden text-center">
                  <span className="text-[10px] tracking-widest text-mag uppercase block font-mono">Dynamic Alignment Truth</span>
                  <p className="font-serif italic text-lg text-gray-200 select-none min-h-[50px] flex items-center justify-center">
                    "{AFFIRMATIONS[affirmationIdx]}"
                  </p>
                  <button 
                    onClick={() => setAffirmationIdx(prev => (prev + 1) % AFFIRMATIONS.length)}
                    className="text-xs text-mag hover:text-[#FAF7FF] font-semibold"
                  >
                    Next Alignment →
                  </button>
                </div>

                {/* Simple pomodoro block */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-5 flex items-center gap-5">
                  <div className="relative w-24 h-24 shrink-0 flex items-center justify-center">
                    <svg className="w-full h-full transform -rotate-90">
                      <circle cx="48" cy="48" r="40" stroke="rgba(255,255,255,0.06)" strokeWidth="4" fill="none" />
                      <circle 
                        cx="48" 
                        cy="48" 
                        r="40" 
                        stroke="var(--color-teal)" 
                        strokeWidth="4" 
                        fill="none" 
                        strokeDasharray="251.2"
                        strokeDashoffset={251.2 * (1 - timerSeconds / (25 * 60))}
                        className="transition-all duration-300"
                      />
                    </svg>
                    <span className="absolute text-sm font-mono tracking-widest">{Math.floor(timerSeconds / 60)}:00</span>
                  </div>

                  <div className="space-y-3 flex-1">
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-widest text-teal block">Single Focus Frame</span>
                      <span className="text-xs text-[#8A7F8D] block mt-0.5">Commit to exactly one tab block safely.</span>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setTimerActive(!timerActive)}
                        className="bg-teal py-1.5 px-4 rounded-xl text-xs font-sans text-plum hover:opacity-90 transition-all font-semibold"
                      >
                        {timerActive ? "Pause" : "Start"}
                      </button>
                      <button 
                        onClick={() => {
                          setTimerActive(false);
                          setTimerSeconds(25 * 60);
                        }}
                        className="bg-white/5 py-1.5 px-4 rounded-xl text-xs font-sans text-gray-300 hover:bg-white/10 transition-all"
                      >
                        Reset
                      </button>
                    </div>
                  </div>
                </div>

                {/* Dopamine Menu list */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                  <span className="text-[10px] tracking-widest text-gold text-mag block uppercase font-mono">Interactive Dopamine Menu</span>
                  <p className="text-[11px] text-[#8A7F8D] leading-relaxed">Need quick stimulus reset? Click with zero corporate guilt.</p>
                  
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {DOPAMINE_ITEMS.map((item, idx) => (
                      <button 
                        key={idx}
                        onClick={() => triggerToast(`Dopamine Reset: ${item.detail}`)}
                        className="bg-white/2 border border-white/5 p-3 rounded-xl hover:bg-white/5 transition-all text-left flex items-start gap-2"
                      >
                        <span>{item.emoji}</span>
                        <div>
                          <strong className="block text-gray-200">{item.label}</strong>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* End Of Day Wind Down Routine Panel */}
                {showWindDown && (
                  <div className="bg-[#1C0A2E] border-2 border-[#C45BAA]/30 rounded-2xl p-5 space-y-4">
                    <span className="text-[10px] tracking-widest text-mag uppercase block font-mono">End of Day Wind Down Triage</span>
                    
                    {windDownStep === "form" ? (
                      <div className="space-y-3">
                        <p className="text-xs text-gray-300 font-light leading-relaxed">
                          Close your tabs. Ground your energy before leaving the corporate mental loop.
                        </p>
                        <div>
                          <label className="text-[10px] font-mono tracking-wider text-mag block mb-1 uppercase">What small wins actually happened today?</label>
                          <textarea 
                            value={windDownForm.did}
                            onChange={e => setWindDownForm({ ...windDownForm, did: e.target.value })}
                            className="w-full bg-white/5 border border-white/10 text-xs rounded-xl p-2 focus:outline-none focus:border-mag"
                            rows={2}
                            placeholder="I made it to lunch, I resolved that draft..."
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-mono tracking-wider text-mag block mb-1 uppercase">What can you release accountability for tonight?</label>
                          <input 
                            value={windDownForm.letGo}
                            onChange={e => setWindDownForm({ ...windDownForm, letGo: e.target.value })}
                            className="w-full bg-white/5 border border-white/10 text-xs rounded-xl p-2 focus:outline-none focus:border-mag animate-none"
                            placeholder="The unanswered email from Sarah..."
                          />
                        </div>
                        <button 
                          onClick={() => {
                            setWindDownStep("done");
                            if (windDownForm.did) {
                              // Log as simple win automatically
                              const item: Win = {
                                id: crypto.randomUUID(),
                                text: `Day Wind Down Win: ${windDownForm.did}`,
                                category: "Daily Win",
                                date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" })
                              };
                              setWinsList(prev => [item, ...prev]);
                            }
                          }}
                          className="w-full py-2.5 bg-[#3D1052] border border-mag text-[#FAF6F0] rounded-xl text-xs font-semibold hover:bg-[#C45BAA]/20"
                        >
                          Safely Close Day 🌙
                        </button>
                      </div>
                    ) : (
                      <div className="text-center py-4 space-y-3">
                        <span className="text-3xl block">🌙</span>
                        <h5 className="font-serif">Day completed safely.</h5>
                        <p className="text-xs text-gray-300 leading-relaxed font-light">
                          You contributed what you could. Rest is fully deserved now. Shut down your workstation safely.
                        </p>
                        <button 
                          onClick={() => {
                            setWindDownStep("form");
                            setWindDownForm({ did: "", letGo: "", tomorrow: "" });
                            setShowWindDown(false);
                          }}
                          className="text-[11px] font-mono uppercase text-mag underline tracking-widest block"
                        >
                          Modify logging draft
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* FlowHer System Guide & ND Help Section */}
                <div className="bg-[#1C0A2E]/50 border border-[#C45BAA]/15 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[9px] tracking-widest text-[#C45BAA] font-mono block uppercase">Interactive System Manual</span>
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider mt-0.5">FlowHer ND Help Section</h4>
                    </div>
                    <span className="text-sm">💡</span>
                  </div>
                  
                  <p className="text-[11px] text-gray-300 leading-relaxed font-light">
                    Learn how FlowHer's cognitive-support modules work to reduce ADHD executive friction, manage sensory masking debt, and validate your career achievements.
                  </p>

                  {/* Guided Tour Promotional Launch Card */}
                  <div className="bg-gradient-to-r from-[#3D1052]/40 to-[#C45BAA]/10 border border-[#C45BAA]/30 rounded-xl p-3.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div className="space-y-1">
                      <strong className="text-xs text-white block">✨ Onboarding Guided Tour</strong>
                      <span className="text-[10px] text-gray-300 block">Let us walk you through our core neurodivergent-support engines interactively!</span>
                    </div>
                    <button
                      onClick={handleRestartTour}
                      className="whitespace-nowrap px-3.5 py-1.5 bg-[#C45BAA] hover:bg-[#C45BAA]/90 text-white font-mono rounded-lg text-[10px] font-bold transition-all cursor-pointer shadow-md select-none"
                    >
                      🚀 Start Tour
                    </button>
                  </div>

                  <div className="space-y-2">
                    {[
                      {
                        title: "🎭 Social Masking & Sensory Debt",
                        body: "Social masking is the energy-intensive process of copying standard behavioral cues. FlowHer's Masking Logger scores the energetic drag of meetings and workflows, offering physical sensory-decompression instructions (such as cold-water vagal stimulation or auditory silence) scaled to your current burnout risk."
                      },
                      {
                        title: "⚡ Smallest Step Breakdown (ADHD Focus)",
                        body: "When experiencing executive dysfunction or ADHD paralysis, starting is the hardest part. The 'Smallest Step Engine' on the Focus tab uses server-side AI to break massive, scary projects into demand-free, ultra-low-energy entry points requiring 2 minutes of starting effort."
                      },
                      {
                        title: "🛡️ Imposter Shield & Win Receipts",
                        body: "Neurodivergent women are highly susceptible to RSD and imposter feelings. The Win tab lets you lock in concrete evidence of professional competency, allowing you to easily export standard TXT 'Win Receipts' to use in performance reviews or during confidence dips."
                      },
                      {
                        title: "🚨 SOS Soma Breathing",
                        body: "If you feel a panic loop or cognitive sensory overwhelm starting, clicking the floating '🚨 SOS Help' button in the toolbar launches a physical sensory grounding box-breathing cycle designed to steady heart rate and vagal tone."
                      },
                      {
                        title: "⚙️ Customizing Profile & Offline Security",
                        body: "Clicking 'Edit Profile' on your top identity card lets you name your profile and formulate a Bio Signature stating current communication parameters. All profile files, pictures, and notes remain fully secure inside your browser's private offline storage arrays."
                      }
                    ].map((faq, idx) => {
                      const isOpen = appHelpOpenIdx === idx;
                      return (
                        <div key={idx} className="border-b border-white/5 pb-2 last:border-none last:pb-0">
                          <button
                            onClick={() => setAppHelpOpenIdx(isOpen ? null : idx)}
                            className="w-full text-left py-1.5 flex items-center justify-between text-xs font-semibold text-gray-200 hover:text-white transition-all cursor-pointer"
                          >
                            <span>{faq.title}</span>
                            <ChevronDown className={`h-3 w-3 text-[#C45BAA] transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`} />
                          </button>
                          {isOpen && (
                            <p className="text-[11px] text-gray-400 leading-relaxed font-light pt-1.5 pb-2 px-1 animate-fadeIn">
                              {faq.body}
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  <div className="pt-2 border-t border-white/5 flex gap-2">
                    <button
                      onClick={() => {
                        setEditName(user?.name || "Professional User");
                        setEditBio(profileBio);
                        setIsEditingProfile(true);
                        setShowProfileModal(true);
                      }}
                      className="flex-1 py-1.8 text-center bg-[#C45BAA]/10 hover:bg-[#C45BAA]/20 border border-[#C45BAA]/30 text-[#E085C9] rounded-xl text-[10px] font-mono uppercase tracking-wider transition-all cursor-pointer"
                    >
                      ✏️ Edit Biography & Name
                    </button>
                    <button
                      onClick={() => {
                        triggerToast("To save your workspace settings permanently, just bookmark this browser session. ✓");
                      }}
                      className="flex-1 py-1.8 text-center bg-white/5 hover:bg-white/10 border border-white/5 text-gray-400 rounded-xl text-[10px] font-mono uppercase tracking-wider transition-all cursor-pointer"
                    >
                      🛡️ Safe Offline Lock Info
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 2. FOCUS TAB SCREEN */}
            {appTab === "focus" && (
              <div className="space-y-6">
                
                {/* Priorities Setup */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                  <span className="text-[10px] tracking-widest text-[#C45BAA] font-mono block uppercase">Strategic Priorities — Limit 3</span>
                  <p className="text-[11px] text-[#8A7F8D]">What strictly demands your reserves today? Everything else is auxiliary noise.</p>
                  
                  <div className="space-y-3">
                    {priorities.map((p, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-[#C45BAA]/15 text-mag flex items-center justify-center font-mono text-xs font-bold leading-none shrink-0">{idx + 1}</span>
                        <input 
                          type="text"
                          value={p}
                          onChange={e => {
                            const copy = [...priorities];
                            copy[idx] = e.target.value;
                            setPriorities(copy);
                          }}
                          className="flex-1 bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-mag text-gray-200"
                          placeholder={`Enter Priority ${idx + 1}`}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Smallest Step Engine breakdown tool */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-teal shrink-0" />
                    <span className="text-[10px] tracking-widest text-teal font-mono block uppercase">Smallest Step AI Breakdown</span>
                  </div>
                  <p className="text-[11px] text-[#8A7F8D]">Paralyzed by a complex corporate task? Give FlowHer the context, we will carve out the tiniest item.</p>

                  <textarea 
                    value={smallestStepInput}
                    onChange={e => setSmallestStepInput(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 text-xs rounded-xl p-3 focus:outline-none focus:border-teal text-gray-200"
                    rows={3}
                    placeholder="Enter daunting task (e.g., complete performance review layout, file Q3 reports...)"
                  />

                  <button 
                    disabled={smallestStepLoading || !smallestStepInput.trim()}
                    onClick={() => executeCoreAction("Smallest Step AI Engine", handleFetchSmallestStep)}
                    className="w-full py-2.5 bg-[#3D1052] hover:bg-teal/20 text-[#FAF6F0] rounded-xl text-xs font-semibold font-sans flex items-center justify-center gap-2 border border-teal/40 disabled:opacity-50 transition-all cursor-pointer"
                  >
                    {smallestStepLoading ? "Processing safe steps..." : "Break Down into Micro-Steps →"}
                  </button>

                  {smallestStepResult && (
                    <div className="bg-white/5 rounded-xl p-4 border border-teal/20 text-xs leading-relaxed space-y-2 text-gray-300 font-light whitespace-pre-line">
                      {smallestStepResult}
                    </div>
                  )}
                </div>

                {/* Time Blindness Corrector Panel */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                  <span className="text-[10px] tracking-widest text-[#D4A843] font-mono block uppercase">⏱ Time Blindness Multiplier Triage</span>
                  <p className="text-[11px] text-[#8A7F8D]">Your brain lies about planning duration rates. Compare estimates with real actual timings to locate your precise organizational multiplier.</p>

                  {tbcTimerActive ? (
                    <div className="bg-plum/20 rounded-xl p-4 border border-[#D4A843]/35 text-center space-y-4">
                      <span className="text-xs font-mono uppercase text-[#D4A843]">Operational Duration Running</span>
                      <div className="font-mono text-4xl block text-white tracking-widest animate-pulse">
                        {Math.floor(tbcSeconds / 60)}:{(tbcSeconds % 60).toString().padStart(2, "0")}
                      </div>
                      <span className="text-xs font-light text-gray-300 block">Current Task: "{tbcTask}"</span>

                      {/* TBC Real-Time Assist Active Indicators */}
                      {tbcAssistEnabled && (
                        <div className="space-y-3 pt-3 border-t border-white/5">
                          {/* Active pulsing check-in box */}
                          {pulseCueActive && (
                            <div className="bg-gradient-to-r from-[#D4A843]/10 to-[#E8845C]/10 border border-[#D4A843]/30 rounded-xl p-3 text-left animate-pulse space-y-1">
                              <span className="text-[10px] uppercase font-mono tracking-wider text-[#D4A843] block">🌿 Time Blindness Check-in</span>
                              <p className="text-xs text-white leading-relaxed font-light">{pulseCueMessage}</p>
                            </div>
                          )}

                          {/* Dynamic Adjusted Progress Track */}
                          {tbcEstimate && (
                            <div className="space-y-1 mr-0 text-left">
                              <div className="flex justify-between text-[10px] font-mono text-gray-400">
                                <span>Support-Adjusted Cushion Target: {Math.round(Number(tbcEstimate) * getMultiplierAvg())} mins ({getMultiplierAvg()}x safety)</span>
                                <span>{Math.min(100, Math.round((tbcSeconds / (Math.round(Number(tbcEstimate) * getMultiplierAvg()) * 60)) * 100))}%</span>
                              </div>
                              <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden border border-white/5">
                                <div 
                                  className="bg-gradient-to-r from-[#D4A843] to-[#E8845C] h-full transition-all duration-300" 
                                  style={{ width: `${Math.min(100, (tbcSeconds / (Math.round(Number(tbcEstimate) * getMultiplierAvg()) * 60)) * 100)}%` }} 
                                />
                              </div>
                              <span className="text-[9px] text-[#8A7F8D] block leading-normal">
                                Next gentle checking prompt waves every {tbcAssistInterval} minutes.
                              </span>
                            </div>
                          )}
                        </div>
                      )}

                      <button 
                        onClick={handleStopTbcTimer}
                        className="py-2.5 px-5 bg-[#E8845C] hover:opacity-90 rounded-xl text-xs font-sans text-white font-medium shadow-md cursor-pointer w-full"
                      >
                        Complete Task & Generate Multiplier Metrics ✓
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4 text-xs">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1 text-left">
                          <label className="text-[9px] font-mono text-gray-400 uppercase tracking-wide block">Task Name:</label>
                          <input 
                            type="text"
                            value={tbcTask}
                            onChange={e => setTbcTask(e.target.value)}
                            className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 focus:outline-none focus:border-[#D4A843]/50 text-gray-200"
                            placeholder="e.g. Code Review"
                          />
                        </div>
                        <div className="space-y-1 text-left">
                          <label className="text-[9px] font-mono text-gray-400 uppercase tracking-wide block">Initial Estimate (mins):</label>
                          <input 
                            type="number"
                            value={tbcEstimate}
                            onChange={e => setTbcEstimate(e.target.value ? Number(e.target.value) : "")}
                            className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 focus:outline-none focus:border-[#D4A843]/50 text-gray-200 font-mono"
                            placeholder="e.g. 15"
                          />
                        </div>
                      </div>

                      {/* Time Blindness Assist Config Division */}
                      <div className="bg-black/25 border border-[#D4A843]/20 rounded-xl p-4.5 space-y-3.5 text-left">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Volume2 className="h-4 w-4 text-[#D4A843]" />
                            <div>
                              <strong className="text-xs text-white block">🌸 Time Blindness Assist</strong>
                              <span className="text-[9px] text-gray-400 block font-light">Real-time sensory awareness prompts & planning projection</span>
                            </div>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer select-none">
                            <input 
                              type="checkbox" 
                              checked={tbcAssistEnabled} 
                              onChange={e => setTbcAssistEnabled(e.target.checked)} 
                              className="sr-only peer" 
                            />
                            <div className="w-9 h-5 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#D4A843]/80"></div>
                          </label>
                        </div>

                        {tbcAssistEnabled && (
                          <div className="space-y-3 pt-2.5 border-t border-white/5 text-xs">
                            {/* Adjusted Forecast Projection Banner */}
                            {tbcEstimate ? (
                              <div className="bg-emerald-950/20 border border-emerald-500/20 rounded-lg p-2.5 space-y-1">
                                <span className="text-[8px] font-mono uppercase text-emerald-400 block tracking-wider font-semibold">📈 Multiplier forecast projection</span>
                                <p className="text-[11px] text-gray-200 leading-normal">
                                  Your brain expects <span className="font-mono text-emerald-300">{tbcEstimate}m</span>. Based on your personal <span className="font-mono text-emerald-400 font-bold">{getMultiplierAvg()}x</span> multiplier, you actually need a safe, stress-free window of <span className="font-mono text-emerald-300 font-bold">{Math.round(Number(tbcEstimate) * getMultiplierAvg())} mins</span> to work organically.
                                </p>
                              </div>
                            ) : (
                              <div className="bg-[#D4A843]/5 border border-[#D4A843]/10 rounded-lg p-2 text-[10px] text-gray-400 leading-normal font-sans">
                                💡 Enter an estimate above to see your customized multiplier safety forecast in real-time.
                              </div>
                            )}

                            <div className="grid grid-cols-2 gap-3 pt-1">
                              {/* Interval selection */}
                              <div className="space-y-1">
                                <label className="text-[9px] font-mono text-gray-400 uppercase tracking-wide block">Gentle Cue Every:</label>
                                <select
                                  value={tbcAssistInterval}
                                  onChange={e => setTbcAssistInterval(Number(e.target.value))}
                                  className="w-full bg-white/5 border border-white/10 text-xs text-gray-300 rounded-lg px-2 py-1.5 focus:outline-none focus:border-[#D4A843]"
                                >
                                  <option value={1} className="bg-[#1C0A2E]">1 Minute</option>
                                  <option value={2} className="bg-[#1C0A2E]">2 Minutes</option>
                                  <option value={3} className="bg-[#1C0A2E]">3 Minutes</option>
                                  <option value={5} className="bg-[#1C0A2E]">5 Minutes</option>
                                  <option value={10} className="bg-[#1C0A2E]">10 Minutes</option>
                                </select>
                              </div>

                              {/* Cue style */}
                              <div className="space-y-1">
                                <label className="text-[9px] font-mono text-gray-400 uppercase tracking-wide block">Sensory Feedback:</label>
                                <select
                                  value={tbcAssistType}
                                  onChange={e => setTbcAssistType(e.target.value as any)}
                                  className="w-full bg-white/5 border border-white/10 text-xs text-gray-300 rounded-lg px-2 py-1.5 focus:outline-none focus:border-[#D4A843]"
                                >
                                  <option value="both" className="bg-[#1C0A2E]">Visual & Sound (Both)</option>
                                  <option value="pulse" className="bg-[#1C0A2E]">Visual Pulse Only</option>
                                  <option value="chime" className="bg-[#1C0A2E]">Ambient Note Chime</option>
                                </select>
                              </div>
                            </div>

                            {/* Manual Sound test button */}
                            <div className="flex justify-end pt-1">
                              <button
                                type="button"
                                onClick={() => {
                                  playGentleChime();
                                  triggerToast("Test chime played! Peaceful, transient C5 note with high overtones. 🌱");
                                }}
                                className="text-[9px] font-mono text-[#D4A843] hover:text-[#FAF6F0] hover:underline transition-all cursor-pointer flex items-center gap-1 select-none"
                              >
                                🔊 Tap to test calming sound
                              </button>
                            </div>
                          </div>
                        )}
                      </div>

                      <button 
                        disabled={!tbcTask.trim() || !tbcEstimate}
                        onClick={() => executeCoreAction("Time Blindness Regulator", handleStartTbcTimer)}
                        className="w-full py-2.5 bg-[#3D1052] hover:bg-[#D4A843]/10 text-[#FAF6F0] rounded-xl text-xs font-semibold font-sans border border-[#D4A843]/35 disabled:opacity-50 cursor-pointer"
                      >
                        Begin timed task session
                      </button>
                    </div>
                  )}

                  {tbcHistory.length > 0 && (
                    <div className="space-y-2 border-t border-white/5 pt-3">
                      <div className="flex justify-between text-xs font-mono text-[#E8845C]">
                        <span>Tipping multiplier factor average</span>
                        <span>{getMultiplierAvg()}x</span>
                      </div>
                      <p className="text-[10px] text-gray-400 leading-relaxed font-light font-sans">
                        When you plan any task you assume takes <strong className="text-[#D4A843]">30 mins</strong>, schedule your outlook calendar for <strong className="text-[#D4A843]">{Math.round(30 * getMultiplierAvg())} mins</strong> instead.
                      </p>
                    </div>
                  )}
                </div>

                {/* Body Double Timer setup module */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                  <span className="text-[10px] tracking-widest text-[#E8845C] font-mono block uppercase">👥 Interactive Body Double Co-Focus</span>
                  <p className="text-[11px] text-[#8A7F8D]">You are never isolated in your workspace. Define your task and focus securely alongside our simple simulated co-worker.</p>

                  {bdTimerActive ? (
                    <div className="bg-white/2 rounded-2xl p-4 text-center border border-teal/30 space-y-2">
                      <span className="text-xs font-mono uppercase text-teal">Co-Working Workspace Active</span>
                      <p className="text-xs text-gray-300 italic font-mono font-light">"I've got my head down and is tracking my spreadsheet blocks. Let us stay focused together."</p>
                      <div className="font-mono text-3xl font-light text-white tracking-widest py-2">
                        {Math.floor(bdTimerSeconds / 60)}:{(bdTimerSeconds % 60).toString().padStart(2, "0")}
                      </div>
                      <div className="flex gap-2 justify-center">
                        <button 
                          onClick={() => setBdTimerActive(false)}
                          className="bg-white/10 text-xs px-4 py-1.5 rounded-xl hover:bg-white/20"
                        >
                          Pause Co-Focus
                        </button>
                        <button 
                          onClick={() => {
                            setBdTimerActive(false);
                            setBdTimerSeconds(25 * 60);
                            setBdTask("");
                          }}
                          className="bg-[#E8845C] text-xs px-4 py-1.5 rounded-xl hover:opacity-90"
                        >
                          Cancel focus session
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <input 
                        type="text"
                        value={bdTask}
                        onChange={e => setBdTask(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 text-xs rounded-xl px-3 py-2.5 focus:outline-none focus:border-teal text-gray-200"
                        placeholder="What are we aligning on together right now?"
                      />
                      <button 
                        disabled={!bdTask.trim()}
                        onClick={() => {
                          setBdTimerSeconds(25 * 60);
                          setBdTimerActive(true);
                          triggerToast("Let's focus together! I'm structured.");
                        }}
                        className="w-full py-2.5 bg-[#3D1052] border border-teal/40 text-teal text-xs font-semibold rounded-xl hover:bg-teal/5 disabled:opacity-50 cursor-pointer"
                      >
                        Activate body double block
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 3. WORK TAB SCREEN */}
            {appTab === "work" && (
              <div className="space-y-6">
                
                {/* Survival picker widget list */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <button 
                    onClick={() => setSelectedWorkTool("email")}
                    className={`p-4 rounded-xl border flex flex-col items-start text-left space-y-2 ${selectedWorkTool === "email" ? "border-mag bg-[#C45BAA]/10" : "border-white/5 bg-white/5"}`}
                  >
                    <Sparkles className="h-5 w-5 text-mag" />
                    <span className="font-serif text-sm font-medium">Drafting Assistant</span>
                  </button>
                  <button 
                    onClick={() => setSelectedWorkTool("script")}
                    className={`p-4 rounded-xl border flex flex-col items-start text-left space-y-2 ${selectedWorkTool === "script" ? "border-teal bg-teal/10" : "border-white/5 bg-white/5"}`}
                  >
                    <Heart className="h-5 w-5 text-teal" />
                    <span className="font-serif text-sm font-medium">Conversation Scripts</span>
                  </button>
                  <button 
                    onClick={() => setSelectedWorkTool("rsd")}
                    className={`p-4 rounded-xl border flex flex-col items-start text-left space-y-2 ${selectedWorkTool === "rsd" ? "border-[#E8845C] bg-[#E8845C]/10" : "border-white/5 bg-white/5"}`}
                  >
                    <ShieldCheck className="h-5 w-5 text-[#E8845C]" />
                    <span className="font-serif text-sm font-medium">RSD Reality Checker</span>
                  </button>
                  <button 
                    onClick={() => setSelectedWorkTool("ada")}
                    className={`p-4 rounded-xl border flex flex-col items-start text-left space-y-2 ${selectedWorkTool === "ada" ? "border-[#D4A843] bg-[#D4A843]/10" : "border-white/5 bg-white/5"}`}
                  >
                    <FileText className="h-5 w-5 text-[#D4A843]" />
                    <span className="font-serif text-sm font-medium">ADA Protections Log</span>
                  </button>
                  <button 
                    onClick={() => setSelectedWorkTool("meeting")}
                    className={`p-4 rounded-xl border flex flex-col items-start text-left space-y-2 col-span-2 ${selectedWorkTool === "meeting" ? "border-mag bg-[#C45BAA]/10" : "border-white/5 bg-white/5"}`}
                  >
                    <Calendar className="h-4 w-4 text-[#FAF7FF]" />
                    <span className="font-serif text-sm font-medium">Meeting Mode Prep Helper</span>
                  </button>
                </div>

                {/* Sub features display panels based on tool selection */}
                
                {/* 3a. Email drafting helper */}
                {selectedWorkTool === "email" && (
                  <div className="bg-white/5 border border-white/5 rounded-2xl p-6 space-y-6">
                    {/* Header */}
                    <div className="flex items-center justify-between border-b border-white/5 pb-4">
                      <div>
                        <span className="text-[10px] tracking-widest text-[#C45BAA] font-mono block uppercase">Interactive Boundary Station</span>
                        <h3 className="text-sm font-bold text-white uppercase tracking-wider mt-1">Confident Email Drafting Assistant</h3>
                      </div>
                      <span className="p-2 bg-[#C45BAA]/10 rounded-xl border border-[#C45BAA]/25">
                        <Sparkles className="h-4 w-4 text-[#E8845C]" />
                      </span>
                    </div>

                    <p className="text-[11px] text-[#8A7F8D] leading-relaxed">
                      Neurodivergent professionals — especially women — often struggle with workplace directness and over-apologizing to maintain social comfort. This workspace supports building completely unapologetic, polite, yet firm boundary-setting professional emails.
                    </p>

                     {/* Sub Tab selection */}
                     <div className="flex bg-[#110122] rounded-xl p-1 border border-white/5 gap-1">
                       <button
                         onClick={() => setEmailSubTab("ai")}
                         className={`flex-1 py-1.5 text-center text-xs font-mono rounded-lg transition-all cursor-pointer ${emailSubTab === "ai" ? "bg-[#3D1052] text-[#FAF6F0] font-semibold border border-[#C45BAA]/45 shadow-sm" : "text-gray-400 hover:text-white"}`}
                       >
                         🤖 AI Boundary Coach
                       </button>
                       <button
                         onClick={() => {
                           setEmailSubTab("scan");
                           // Sync initial scanner state if there is already an AI result
                           if (emailResult && !scannerInput) {
                             setScannerInput(emailResult);
                           }
                         }}
                         className={`flex-1 py-1.5 text-center text-xs font-mono rounded-lg transition-all cursor-pointer ${emailSubTab === "scan" ? "bg-[#3D1052] text-[#FAF6F0] font-semibold border border-[#C45BAA]/45 shadow-sm" : "text-gray-400 hover:text-white"}`}
                       >
                         🛡️ Self-Scan & Refine
                       </button>
                       <button
                         onClick={() => setEmailSubTab("signatures")}
                         className={`flex-1 py-1.5 text-center text-xs font-mono rounded-lg transition-all cursor-pointer ${emailSubTab === "signatures" ? "bg-[#3D1052] text-[#FAF6F0] font-semibold border border-[#C45BAA]/45 shadow-sm" : "text-gray-400 hover:text-white"}`}
                       >
                         ✍️ Custom Signatures
                       </button>
                     </div>

                    {/* Sub Tab: AI DRAFTING WITH TONE MODULATION */}
                    {emailSubTab === "ai" && (
                      <div className="space-y-5 animate-fadeIn">
                        
                        {/* 1. Situation presets */}
                        <div className="space-y-2">
                          <label className="text-[10px] uppercase font-mono tracking-wider font-semibold text-[#E8845C]">
                            Quick Boundary Scenario Presets (Click to pre-fill):
                          </label>
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                            {EMAIL_PRESETS.map((p, idx) => (
                              <button
                                key={idx}
                                onClick={() => {
                                  setEmailSelectedTemplate(p.template);
                                  setEmailSituation(p.situation);
                                  triggerToast(`Pre-filled scenario: ${p.label}`);
                                }}
                                className="p-2 border border-white/5 hover:border-[#C45BAA]/30 bg-white/2 hover:bg-[#C45BAA]/5 text-left rounded-xl transition-all cursor-pointer"
                              >
                                <span className="text-[11px] text-gray-200 block font-semibold">{p.label}</span>
                                <span className="text-[9px] text-[#8A7F8D] block font-light truncate mt-0.5">{p.situation}</span>
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* 2. Tone selection */}
                        <div className="space-y-2">
                          <label className="text-[10px] uppercase font-mono tracking-wider font-semibold text-[#E8845C]">
                            Draft Tone Modulator:
                          </label>
                          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
                            {EMAIL_TONES.map((tone) => (
                              <button
                                key={tone.key}
                                onClick={() => setEmailSelectedTone(tone.key)}
                                className={`p-2 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${emailSelectedTone === tone.key ? "border-[#C45BAA] bg-[#C45BAA]/10 text-white" : "border-white/5 bg-white/2 text-gray-400"}`}
                              >
                                <span className="text-[10px] font-mono font-bold block">{tone.label}</span>
                                <span className="text-[8px] text-[#8A7F8D] font-light mt-0.5 block leading-normal">{tone.tag}</span>
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* 3. Text Area detail details */}
                        <div className="space-y-2">
                          <div className="flex justify-between items-center text-[10px] font-mono">
                            <span className="uppercase text-[#E8845C]">Custom Situation Context & Goals:</span>
                            <span className="text-gray-500">{emailSituation.length} chars</span>
                          </div>
                          <textarea
                            value={emailSituation}
                            onChange={(e) => setEmailSituation(e.target.value)}
                            className="w-full bg-[#110122]/70 border border-white/10 text-xs rounded-xl p-3 focus:outline-none focus:border-[#C45BAA] text-gray-200 transition-all placeholder:text-gray-600 font-sans"
                            rows={4}
                            placeholder="Type details in your own words (e.g., 'My manager wants me to work over the weekend to finish reports before a board meeting, but I have sensory burnout.')"
                          />
                        </div>

                        {/* Submit Button */}
                        <button
                          disabled={emailLoading || !emailSituation.trim()}
                          onClick={() => executeCoreAction("Boundary-Setting AI Coach", handleFetchEmailDraft)}
                          className="w-full py-2.5 bg-[#3D1052] hover:bg-[#C45BAA]/20 border border-[#C45BAA]/40 text-[#FAF6F0] rounded-xl text-xs font-semibold font-sans flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {emailLoading ? "Sculpting confident phrasing..." : "Assemble Completely Unapologetic Draft →"}
                        </button>

                        {/* Result Output Card with Mailto & Copy */}
                        {emailResult && (
                          <div className="bg-[#1C0A2E]/50 border border-[#C45BAA]/20 rounded-2xl p-5 space-y-4 animate-scaleUp">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-2">
                              <span className="text-[10px] font-mono text-[#FAF6F0] flex items-center gap-1.5">
                                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                                High-Confidence Output Drafted
                              </span>
                              <div className="flex gap-1.5 self-end">
                                <button
                                  onClick={() => {
                                    navigator.clipboard.writeText(emailResult);
                                    triggerToast("Copied email draft to clipboard! 📋");
                                  }}
                                  className="px-2.5 py-1 text-[9px] font-mono uppercase bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white rounded border border-white/10 transition-all cursor-pointer"
                                >
                                  Copy To Clipboard
                                </button>
                                <button
                                  onClick={() => {
                                    let subject = "Status update / project alignment";
                                    let body = emailResult;
                                    const match = emailResult.match(/Subject:\s*(.*)/i);
                                    if (match) {
                                      subject = match[1].trim();
                                      body = emailResult.replace(/Subject:\s*(.*)/i, "").trim();
                                    }
                                    const mailtoUrl = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
                                    window.open(mailtoUrl, "_blank");
                                  }}
                                  className="px-2.5 py-1 text-[9px] font-mono uppercase bg-[#C45BAA]/20 hover:bg-[#C45BAA]/30 text-[#FAF6F0] rounded border border-[#C45BAA]/40 transition-all cursor-pointer"
                                >
                                  📨 Open In Mail Client
                                </button>
                              </div>
                            </div>

                            <div className="bg-[#110122]/80 rounded-xl p-4 border border-white/5 font-sans text-xs text-gray-200 leading-relaxed max-h-72 overflow-y-auto whitespace-pre-wrap select-text">
                              {emailResult}
                            </div>

                            {/* Verification Badge */}
                            <div className="bg-[#1E112E] p-3 rounded-xl border border-[#C45BAA]/10 flex items-start gap-2 text-[10px] text-gray-400 leading-normal">
                              <span className="text-sm">🛡️</span>
                              <div>
                                <strong className="text-gray-300">Apology-Free Assertiveness Audit:</strong>
                                <p className="mt-0.5 font-light">
                                  Checked for "just checking", "sorry to bother", and over-explanations. Verified clean, resilient communication borders.
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Sub Tab: TEXT MINIMIZER SCANNER */}
                    {emailSubTab === "scan" && (
                      <div className="space-y-6 animate-fadeIn">
                        <div className="bg-[#1E112E] border border-[#E8845C]/15 rounded-2xl p-4 space-y-2">
                          <span className="text-[10px] font-mono uppercase tracking-widest text-[#E8845C] block">Executive Self-Scan & Tone Audit</span>
                          <p className="text-[11px] text-[#A697AA] leading-relaxed">
                            Paste or type your draft email below. Our Real-Time Self-Scan Engine scans for minimizing words, evaluates overall tone consistency, identifies emotional resonance overloads, and provides direct replacements.
                          </p>
                        </div>

                        {/* Scanner Input Textarea */}
                        <div className="space-y-2">
                          <div className="flex justify-between items-center text-[10px] font-mono">
                            <span className="uppercase text-[#FAF6F0]">Own Draft Sandbox:</span>
                            <div className="flex gap-2.5">
                              {scannerInput.length > 0 && (
                                <button
                                  onClick={() => {
                                    navigator.clipboard.writeText(scannerInput);
                                    triggerToast("Copied draft to clipboard! 📋");
                                  }}
                                  className="text-gray-400 hover:text-white transition-all cursor-pointer"
                                >
                                  Copy All
                                </button>
                              )}
                              <button
                                onClick={() => setScannerInput("")}
                                className="text-gray-500 hover:text-white transition-all cursor-pointer"
                              >
                                Clear Text
                              </button>
                            </div>
                          </div>
                          <textarea
                            value={scannerInput}
                            onChange={(e) => setScannerInput(e.target.value)}
                            className="w-full bg-[#110122]/70 border border-white/10 text-xs rounded-xl p-3 focus:outline-none focus:border-[#E8845C] text-gray-200 transition-all placeholder:text-gray-600 font-sans"
                            rows={5}
                            placeholder="Paste your drafted email here (e.g., 'Hi there, I was just checking if you had time to look. Sorry to bother you, I know you are super busy! I feel very stressed because this is hard for me...')"
                          />
                        </div>

                        {/* Real-time Scanner Report */}
                        {scannerInput.length > 0 && (
                          <div className="space-y-6">
                            
                            {/* Heuristic Tone & Consistency Assessment Panel */}
                            {(() => {
                              const report = analyzeEmailResonance(scannerInput);
                              const found = MINIMIZERS.filter(m => m.regex.test(scannerInput));
                              const numMatches = found.length;
                              return (
                                <div className="space-y-5">
                                  
                                  {/* Tone Class Block */}
                                  <div className={`border rounded-2xl p-4 space-y-3 relative overflow-hidden transition-all ${report.toneColor}`}>
                                    <div className="absolute top-0 right-0 w-24 h-24 bg-white/2 rounded-full translate-x-8 -translate-y-8 blur-lg pointer-events-none"></div>
                                    <div className="flex items-start justify-between">
                                      <div>
                                        <span className="text-[9px] font-mono tracking-widest uppercase text-gray-400">Detected Tone Profile & Resonance</span>
                                        <h4 className="text-xs font-bold text-white mt-0.5 flex items-center gap-1.5">
                                          <span>{report.toneEmoji}</span>
                                          {report.toneType}
                                        </h4>
                                      </div>
                                      <span className="text-[9px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 bg-black/45 rounded-md border border-white/5">
                                        {report.resonanceRating}
                                      </span>
                                    </div>
                                    <p className="text-[11px] text-gray-200 leading-relaxed font-light">
                                      {report.description}
                                    </p>
                                  </div>

                                  {/* Score Bars Bento Grid */}
                                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                    {/* Score 1: Assertiveness Index */}
                                    <div className="bg-[#130620]/60 border border-white/5 rounded-xl p-3 space-y-2">
                                      <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                                        <span>Assertiveness:</span>
                                        <span className={`font-bold ${report.scores.assertiveness > 75 ? "text-emerald-400" : "text-[#FF9E7D]"}`}>
                                          {report.scores.assertiveness}%
                                        </span>
                                      </div>
                                      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                                        <div 
                                          className="h-full bg-gradient-to-r from-[#C45BAA] to-emerald-400 transition-all duration-300"
                                          style={{ width: `${report.scores.assertiveness}%` }}
                                        ></div>
                                      </div>
                                      <span className="text-[8px] font-mono text-gray-500 block leading-tight">
                                        Presence of boundary boundaries & declarative statements.
                                      </span>
                                    </div>

                                    {/* Score 2: Clarity & Sparing */}
                                    <div className="bg-[#130620]/60 border border-white/5 rounded-xl p-3 space-y-2">
                                      <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                                        <span>Cognitive Clarity:</span>
                                        <span className={`font-bold ${report.scores.clarity > 75 ? "text-emerald-400" : "text-[#FF9E7D]"}`}>
                                          {report.scores.clarity}%
                                        </span>
                                      </div>
                                      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                                        <div 
                                          className="h-full bg-gradient-to-r from-teal to-[#C45BAA] transition-all duration-300"
                                          style={{ width: `${report.scores.clarity}%` }}
                                        ></div>
                                      </div>
                                      <span className="text-[8px] font-mono text-gray-500 block leading-tight">
                                        Measures short phrasing and lack of over-explaining fatigue.
                                      </span>
                                    </div>

                                    {/* Score 3: Emotional Load */}
                                    <div className="bg-[#130620]/60 border border-white/5 rounded-xl p-3 space-y-2">
                                      <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                                        <span>Emotional Load:</span>
                                        <span className={`font-bold ${report.scores.emotionalLoad > 45 ? "text-[#FF9E7D]" : "text-emerald-400"}`}>
                                          {report.scores.emotionalLoad}%
                                        </span>
                                      </div>
                                      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                                        <div 
                                          className="h-full bg-gradient-to-r from-emerald-400 to-[#FF9E7D] transition-all duration-300"
                                          style={{ width: `${report.scores.emotionalLoad}%` }}
                                        ></div>
                                      </div>
                                      <span className="text-[8px] font-mono text-gray-500 block leading-tight">
                                        Expressed exhaustion, anxiety or high stress indicators.
                                      </span>
                                    </div>
                                  </div>

                                  {/* Flagged Visual Highlight Section */}
                                  <div className="bg-[#110122] border border-white/5 rounded-xl p-4 space-y-1.5">
                                    <span className="text-[9px] font-mono text-[#897E8C] uppercase block">Real-time Boundary Scan:</span>
                                    <div className="bg-white/2 border border-white/5 p-3 rounded-lg text-xs font-sans text-gray-300 leading-relaxed font-light select-text">
                                      {renderHighlightedText(scannerInput)}
                                    </div>
                                  </div>

                                  {/* Strategic Tone Insights Feed */}
                                  <div className="space-y-2 border-t border-white/5 pt-4">
                                    <span className="text-[10px] font-mono uppercase tracking-widest text-[#E8845C] block">Cognitive Resonance Recommendations:</span>
                                    
                                    <div className="space-y-2.5">
                                      {report.insights.map((insight, idx) => (
                                        <div 
                                          key={idx} 
                                          className={`rounded-xl p-3.5 border text-xs leading-relaxed font-light ${
                                            insight.type === "alert" 
                                              ? "bg-[#E8845C]/5 border-[#E8845C]/20 text-gray-300" 
                                              : insight.type === "success"
                                              ? "bg-emerald-950/20 border-emerald-500/20 text-gray-300"
                                              : "bg-[#1E112E] border-white/5 text-gray-300"
                                          }`}
                                        >
                                          <div className="flex items-center gap-1.5 font-semibold text-gray-200 mb-1">
                                            <span>
                                              {insight.type === "alert" ? "⚠️" : insight.type === "success" ? "✓" : "💡"}
                                            </span>
                                            <span className="text-[11px] font-mono tracking-wide uppercase">{insight.title}</span>
                                          </div>
                                          <p className="text-[11px] text-gray-400">{insight.body}</p>
                                        </div>
                                      ))}
                                    </div>
                                  </div>

                                  {/* Weasel Term Replacements List */}
                                  {numMatches > 0 && (
                                    <div className="space-y-2.5">
                                      <span className="text-[10px] font-mono uppercase tracking-widest text-[#C45BAA] block">Weasel Word Dilution Replacements:</span>
                                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                        {found.map((item, idx) => (
                                          <div key={idx} className="bg-[#E8845C]/5 border border-[#E8845C]/15 rounded-xl p-3 space-y-1">
                                            <div className="flex justify-between items-center">
                                              <span className="text-xs font-mono text-[#FF9E7D] font-bold">" {item.word} "</span>
                                              <span className="text-[9px] font-mono text-emerald-300 bg-emerald-950/40 border border-emerald-500/20 px-1.5 rounded-md">Try: {item.replacement}</span>
                                            </div>
                                            <p className="text-[10px] text-gray-400 leading-normal font-light">
                                              <strong>Reason:</strong> {item.reason}
                                            </p>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}

                                  {numMatches === 0 && (
                                    <div className="bg-emerald-955/25 border border-emerald-500/25 rounded-2xl p-4 flex gap-3 text-xs leading-relaxed text-emerald-300">
                                      <span>🎉</span>
                                      <div className="font-light">
                                        <strong>Absolute Boundary Guard!</strong>
                                        <p className="mt-0.5 text-[11px] text-[#A6DCAE]">
                                          None of the standard corporate apologies, softeners, or passive minimizing terms were discovered. This is robust, secure, and confident executive presence! Feel fully comfortable copy-pasting this directly.
                                        </p>
                                      </div>
                                    </div>
                                  )}

                                  {/* Signature Selector Section embedded within Self-Scan tab */}
                                  <div className="space-y-3 bg-[#130620]/60 rounded-xl p-4 border border-white/5 mt-4">
                                    <div className="flex justify-between items-center border-b border-white/5 pb-2">
                                      <div>
                                        <span className="text-[9px] tracking-widest text-[#E085C9] font-mono block uppercase">Confidence Anchors</span>
                                        <h4 className="text-xs font-bold text-white">Neurodivergent Signatures & Closing Blocks</h4>
                                      </div>
                                      <span className="text-xs">✉️</span>
                                    </div>
                                    <p className="text-[10px] text-[#8A7F8D] leading-normal font-light">
                                      Append a protective corporate closing block to your email. These signatures normalize processing buffers and written boundaries, guarding against rejection-sensitive loop cycles.
                                    </p>
                                    
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                                      {signaturePresets.map((preset) => (
                                        <div key={preset.id} className="bg-[#110122] border border-white/5 rounded-xl p-3 flex flex-col justify-between">
                                          {editingPresetId === preset.id ? (
                                            <div className="space-y-3 w-full text-left">
                                              <div className="text-[10px] font-mono font-bold text-white uppercase tracking-wider border-b border-white/5 pb-1 flex justify-between items-center">
                                                <span>✏️ Tweak Preset Context</span>
                                                <span className="text-[8px] text-[#C45BAA]">Inline Editing</span>
                                              </div>
                                              
                                              <div className="space-y-2 text-left">
                                                <div>
                                                  <label className="text-[8px] font-mono text-gray-400 uppercase block">Label:</label>
                                                  <input
                                                    type="text"
                                                    value={presetEditLabel}
                                                    onChange={(e) => setPresetEditLabel(e.target.value)}
                                                    className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs text-white focus:outline-none focus:border-[#C45BAA]"
                                                  />
                                                </div>

                                                <div>
                                                  <label className="text-[8px] font-mono text-gray-400 uppercase block">Short Tag Line:</label>
                                                  <input
                                                    type="text"
                                                    value={presetEditTag}
                                                    onChange={(e) => setPresetEditTag(e.target.value)}
                                                    className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs text-white focus:outline-none focus:border-[#C45BAA]"
                                                  />
                                                </div>

                                                <div>
                                                  <label className="text-[8px] font-mono text-gray-400 uppercase block">Strategic Benefit (Neurodivergent Context):</label>
                                                  <textarea
                                                    value={presetEditBenefit}
                                                    onChange={(e) => setPresetEditBenefit(e.target.value)}
                                                    rows={2}
                                                    className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-[#C45BAA] resize-none leading-normal"
                                                  />
                                                </div>

                                                <div>
                                                  <label className="text-[8px] font-mono text-gray-400 uppercase block">Body [Supports '[Your Name]']:</label>
                                                  <textarea
                                                    value={presetEditText}
                                                    onChange={(e) => setPresetEditText(e.target.value)}
                                                    rows={4}
                                                    className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-[10px] font-mono text-white focus:outline-none focus:border-[#C45BAA] leading-normal"
                                                  />
                                                </div>
                                              </div>

                                              <div className="flex gap-2 justify-end pt-1">
                                                <button
                                                  onClick={() => setEditingPresetId(null)}
                                                  className="px-2 py-1 text-[8px] font-mono uppercase bg-gray-750 hover:bg-gray-700 text-white rounded transition-all cursor-pointer"
                                                >
                                                  Cancel
                                                </button>
                                                <button
                                                  onClick={() => {
                                                    if (!presetEditLabel.trim() || !presetEditText.trim() || !presetEditBenefit.trim()) {
                                                      triggerToast("Label, Benefit, and Signature body are required! ⚠️");
                                                      return;
                                                    }
                                                    const updated = signaturePresets.map(p => 
                                                      p.id === preset.id 
                                                        ? { ...p, label: presetEditLabel, tag: presetEditTag, benefit: presetEditBenefit, text: presetEditText }
                                                        : p
                                                    );
                                                    setSignaturePresets(updated);
                                                    localStorage.setItem("fh_signature_presets", JSON.stringify(updated));
                                                    setEditingPresetId(null);
                                                    triggerToast("Preset signature updated successfully! ✍️");
                                                  }}
                                                  className="px-2 py-1 text-[8px] font-mono uppercase bg-emerald-600 hover:bg-emerald-500 text-white rounded transition-all cursor-pointer"
                                                >
                                                  Save Preset ✓
                                                </button>
                                              </div>
                                            </div>
                                          ) : (
                                            <div className="flex flex-col h-full justify-between space-y-2">
                                              <div>
                                                <div className="flex justify-between items-center">
                                                  <span className="text-[10px] font-mono font-bold text-gray-200 block">{preset.label}</span>
                                                  <button
                                                    onClick={() => {
                                                      setEditingPresetId(preset.id);
                                                      setPresetEditLabel(preset.label);
                                                      setPresetEditTag(preset.tag);
                                                      setPresetEditBenefit(preset.benefit);
                                                      setPresetEditText(preset.text);
                                                    }}
                                                    className="text-[9px] text-[#C45BAA] hover:text-white hover:underline transition-all cursor-pointer"
                                                    title="Edit configuration of this preset"
                                                  >
                                                    ✏️ Edit Preset
                                                  </button>
                                                </div>
                                                <span className="text-[9px] text-[#817786] block font-light leading-normal mt-0.5">{preset.tag}</span>
                                                
                                                {/* Strategic ND Benefit Highlight and description */}
                                                <div className="text-[9px] bg-purple-950/40 text-[#E085C9] border border-[#C45BAA]/15 rounded-lg p-2 mt-2 leading-relaxed">
                                                  <strong className="font-mono text-[8px] uppercase tracking-wider block text-teal-400">💡 ND Strategic Benefit:</strong>
                                                  {preset.benefit}
                                                </div>

                                                <pre className="text-[8px] font-mono text-gray-400 bg-white/2 p-2 rounded-lg border border-white/5 mt-2 overflow-x-auto whitespace-pre-wrap leading-tight select-all">
                                                  {preset.text.replace("[Your Name]", user?.name || "Professional User")}
                                                </pre>
                                              </div>
                                              <div className="flex gap-1.5 justify-end pt-1">
                                                <button
                                                  onClick={() => {
                                                    navigator.clipboard.writeText(preset.text.replace("[Your Name]", user?.name || "Professional User"));
                                                    triggerToast("Copied signature block to clipboard! 📋");
                                                  }}
                                                  className="px-2 py-1 text-[8px] font-mono uppercase bg-white/5 hover:bg-white/10 text-gray-300 rounded border border-white/10 transition-all cursor-pointer"
                                                >
                                                  Copy Block
                                                </button>
                                                <button
                                                  onClick={() => {
                                                    const textToAppend = preset.text.replace("[Your Name]", user?.name || "Professional User");
                                                    setScannerInput(prev => {
                                                      const cleaned = prev.trim();
                                                      return cleaned + textToAppend;
                                                    });
                                                    triggerToast("Appended signature tag successfully! ✓");
                                                  }}
                                                  className="px-2 py-1 text-[8px] font-mono uppercase bg-[#C45BAA]/20 hover:bg-[#C45BAA]/30 text-[#FAF6F0] rounded border border-[#C45BAA]/40 transition-all cursor-pointer"
                                                >
                                                  ➕ Append To Draft
                                                </button>
                                              </div>
                                            </div>
                                          )}
                                        </div>
                                      ))}
                                    </div>
                                  </div>

                                </div>
                              );
                            })()}
                          </div>
                        )}

                        {scannerInput.length === 0 && (
                          <div className="space-y-4">
                            <div className="bg-white/2 border border-dashed border-white/5 rounded-2xl p-8 text-center space-y-2">
                              <span className="text-2xl block text-gray-600">🛡️</span>
                              <span className="text-xs font-mono font-semibold text-gray-400 uppercase block">Audit Canvas Empty</span>
                              <p className="text-[11px] text-gray-500 leading-relaxed max-w-sm mx-auto">
                                Pasting your draft automatically runs the real-time analyzer, assessing tone profiles, high cognitive explanations, and emotional load indexes instantly.
                              </p>
                            </div>

                            {/* Signatures still accessible even when sandbox is empty */}
                            <div className="space-y-3 bg-[#130620]/60 rounded-xl p-4 border border-white/5">
                              <div className="flex justify-between items-center border-b border-white/5 pb-2">
                                <div>
                                  <span className="text-[9px] tracking-widest text-[#E085C9] font-mono block uppercase">Confidence Anchors</span>
                                  <h4 className="text-xs font-bold text-white">Prefabs Signatures & Closing Blocks</h4>
                                </div>
                                <span className="text-xs">✉️</span>
                              </div>
                              <p className="text-[10px] text-[#8A7F8D] leading-normal font-light">
                                Copy standalone high-boundary signatures to place at the bottom of standard email chains:
                              </p>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                                {signaturePresets.map((preset) => (
                                  <div key={preset.id} className="bg-[#110122] border border-white/5 rounded-xl p-3 flex flex-col justify-between">
                                    {editingPresetId === preset.id ? (
                                      <div className="space-y-3 w-full text-left">
                                        <div className="text-[10px] font-mono font-bold text-white uppercase tracking-wider border-b border-white/5 pb-1 flex justify-between items-center">
                                          <span>✏️ Tweak Preset Context</span>
                                          <span className="text-[8px] text-[#C45BAA]">Inline Editing</span>
                                        </div>
                                        
                                        <div className="space-y-2 text-left">
                                          <div>
                                            <label className="text-[8px] font-mono text-gray-400 uppercase block">Label:</label>
                                            <input
                                              type="text"
                                              value={presetEditLabel}
                                              onChange={(e) => setPresetEditLabel(e.target.value)}
                                              className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs text-white focus:outline-none focus:border-[#C45BAA]"
                                            />
                                          </div>

                                          <div>
                                            <label className="text-[8px] font-mono text-gray-400 uppercase block">Short Tag Line:</label>
                                            <input
                                              type="text"
                                              value={presetEditTag}
                                              onChange={(e) => setPresetEditTag(e.target.value)}
                                              className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs text-white focus:outline-none focus:border-[#C45BAA]"
                                            />
                                          </div>

                                          <div>
                                            <label className="text-[8px] font-mono text-gray-400 uppercase block">Strategic Benefit (Neurodivergent Context):</label>
                                            <textarea
                                              value={presetEditBenefit}
                                              onChange={(e) => setPresetEditBenefit(e.target.value)}
                                              rows={2}
                                              className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-[#C45BAA] resize-none leading-normal"
                                            />
                                          </div>

                                          <div>
                                            <label className="text-[8px] font-mono text-gray-400 uppercase block">Body [Supports '[Your Name]']:</label>
                                            <textarea
                                              value={presetEditText}
                                              onChange={(e) => setPresetEditText(e.target.value)}
                                              rows={4}
                                              className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-[10px] font-mono text-white focus:outline-none focus:border-[#C45BAA] leading-normal"
                                            />
                                          </div>
                                        </div>

                                        <div className="flex gap-2 justify-end pt-1">
                                          <button
                                            onClick={() => setEditingPresetId(null)}
                                            className="px-2 py-1 text-[8px] font-mono uppercase bg-gray-750 hover:bg-gray-700 text-white rounded transition-all cursor-pointer"
                                          >
                                            Cancel
                                          </button>
                                          <button
                                            onClick={() => {
                                              if (!presetEditLabel.trim() || !presetEditText.trim() || !presetEditBenefit.trim()) {
                                                triggerToast("Label, Benefit, and Signature body are required! ⚠️");
                                                return;
                                              }
                                              const updated = signaturePresets.map(p => 
                                                p.id === preset.id 
                                                  ? { ...p, label: presetEditLabel, tag: presetEditTag, benefit: presetEditBenefit, text: presetEditText }
                                                  : p
                                              );
                                              setSignaturePresets(updated);
                                              localStorage.setItem("fh_signature_presets", JSON.stringify(updated));
                                              setEditingPresetId(null);
                                              triggerToast("Preset signature updated successfully! ✍️");
                                            }}
                                            className="px-2 py-1 text-[8px] font-mono uppercase bg-emerald-600 hover:bg-emerald-500 text-white rounded transition-all cursor-pointer"
                                          >
                                            Save Preset ✓
                                          </button>
                                        </div>
                                      </div>
                                    ) : (
                                      <div className="flex flex-col h-full justify-between space-y-2">
                                        <div>
                                          <div className="flex justify-between items-center">
                                            <span className="text-[10px] font-mono font-bold text-gray-200 block">{preset.label}</span>
                                            <button
                                              onClick={() => {
                                                setEditingPresetId(preset.id);
                                                setPresetEditLabel(preset.label);
                                                setPresetEditTag(preset.tag);
                                                setPresetEditBenefit(preset.benefit);
                                                setPresetEditText(preset.text);
                                              }}
                                              className="text-[9px] text-[#C45BAA] hover:text-white hover:underline transition-all cursor-pointer"
                                              title="Edit configuration of this preset"
                                            >
                                              ✏️ Edit Preset
                                            </button>
                                          </div>
                                          <span className="text-[9px] text-[#817786] block font-light leading-normal mt-0.5">{preset.tag}</span>
                                          
                                          {/* Strategic ND Benefit Highlight and description */}
                                          <div className="text-[9px] bg-purple-950/40 text-[#E085C9] border border-[#C45BAA]/15 rounded-lg p-2 mt-2 leading-relaxed">
                                            <strong className="font-mono text-[8px] uppercase tracking-wider block text-teal-400">💡 ND Strategic Benefit:</strong>
                                            {preset.benefit}
                                          </div>

                                          <pre className="text-[8px] font-mono text-gray-400 bg-white/2 p-2 rounded-lg border border-white/5 mt-2 overflow-x-auto whitespace-pre-wrap leading-tight select-all">
                                            {preset.text.replace("[Your Name]", user?.name || "Professional User")}
                                          </pre>
                                        </div>
                                        <div className="flex gap-1.5 justify-end pt-1">
                                          <button
                                            onClick={() => {
                                              navigator.clipboard.writeText(preset.text.replace("[Your Name]", user?.name || "Professional User"));
                                              triggerToast("Copied signature block to clipboard! 📋");
                                            }}
                                            className="w-full py-1 text-[8px] font-mono uppercase bg-white/5 hover:bg-white/10 text-gray-300 rounded border border-white/10 transition-all cursor-pointer text-center"
                                          >
                                            Copy Closing Block
                                          </button>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Sub Tab: CUSTOM EMAIL SIGNATURES LIBRARY */}
                    {emailSubTab === "signatures" && (
                      <div className="space-y-6 animate-fadeIn text-gray-200">
                        {/* Shorthand Context Summary */}
                        <div className="bg-[#1E112E] border border-[#C45BAA]/15 rounded-2xl p-4 space-y-2">
                          <span className="text-[10px] font-mono uppercase tracking-widest text-[#E085C9] block">Personalized Clarity Libraries</span>
                          <p className="text-[11px] text-[#A697AA] leading-relaxed">
                            Create, customize, and save multiple professional email signatures. Each signature asserts standard Neurodivergent boundary contexts—like batch-processing windows or evening digital recovery blocks—anchoring your confidence across different corporate relationships.
                          </p>
                        </div>

                        {/* Interactive Create / Edit Form Card */}
                        <div className="bg-white/2 border border-[#C45BAA]/10 rounded-2xl p-4.5 space-y-4">
                          <div className="flex justify-between items-center border-b border-white/5 pb-2">
                            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                              <span>{sigEditId ? "✏️ Edit Signature Context" : "⚙️ Create Personalized Signature"}</span>
                            </h4>
                            {sigEditId && (
                              <button
                                onClick={() => {
                                  setSigFormLabel("");
                                  setSigFormTag("");
                                  setSigFormText("");
                                  setSigEditId(null);
                                  triggerToast("Form reset to creation. ✓");
                                }}
                                className="text-[10px] text-[#E8845C] hover:underline cursor-pointer"
                              >
                                Cancel Edit ↺
                              </button>
                            )}
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {/* Input: Context Label */}
                            <div className="space-y-1">
                              <label className="text-[9px] font-mono text-[#8A7F8D] uppercase block">Context Label (e.g., Client Work, Inner Team):</label>
                              <input 
                                type="text"
                                value={sigFormLabel}
                                onChange={(e) => setSigFormLabel(e.target.value)}
                                className="w-full bg-[#110122]/80 border border-white/10 text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-[#C45BAA] transition-all placeholder:text-gray-650"
                                placeholder="e.g., Development Rest Lockout"
                              />
                            </div>

                            {/* Input: Tag Description Context */}
                            <div className="space-y-1">
                              <label className="text-[9px] font-mono text-[#8A7F8D] uppercase block">Subtag / Limit description:</label>
                              <input 
                                type="text"
                                value={sigFormTag}
                                onChange={(e) => setSigFormTag(e.target.value)}
                                className="w-full bg-[#110122]/80 border border-white/10 text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-[#C45BAA] transition-all placeholder:text-gray-655"
                                placeholder="e.g., Minimizes expectation ambiguity"
                              />
                            </div>
                          </div>

                          {/* Input: Text block */}
                          <div className="space-y-1">
                            <div className="flex justify-between items-center">
                              <label className="text-[9px] font-mono text-[#8A7F8D] uppercase block">Signature Body Text (Supports '[Your Name]'):</label>
                              <span className="text-[8px] font-mono text-gray-500 italic">Prepend '\n\n' for nice vertical spacing</span>
                            </div>
                            <textarea 
                              value={sigFormText}
                              onChange={(e) => setSigFormText(e.target.value)}
                              rows={4}
                              className="w-full bg-[#110122]/80 border border-white/10 text-xs rounded-xl p-3 focus:outline-none focus:border-[#C45BAA] transition-all placeholder:text-gray-660 font-mono leading-relaxed"
                              placeholder={`\n\nKind regards,\n[Your Name]\n\n---\n*Note: To limit digital communication noise...*`}
                            />
                          </div>

                          {/* Action Button to Save */}
                          <button
                            onClick={() => {
                              if (!sigFormLabel.trim() || !sigFormText.trim()) {
                                triggerToast("Context Label and Signature Text are required to compile! ⚠️");
                                return;
                              }
                              let updatedSignatures;
                              if (sigEditId) {
                                updatedSignatures = customSignatures.map(sig => 
                                  sig.id === sigEditId 
                                    ? { ...sig, label: sigFormLabel, tag: sigFormTag || "Personalized context block", text: sigFormText }
                                    : sig
                                );
                                triggerToast("Signature context updated successfully! ✍️");
                              } else {
                                const newId = "sig-" + Date.now();
                                const newSig = {
                                  id: newId,
                                  label: sigFormLabel,
                                  tag: sigFormTag || "Personalized context block",
                                  text: sigFormText
                                };
                                updatedSignatures = [...customSignatures, newSig];
                                triggerToast("New personalized context signature added to library! ✨");
                              }
                              setCustomSignatures(updatedSignatures);
                              localStorage.setItem("fh_custom_signatures", JSON.stringify(updatedSignatures));
                              setSigFormLabel("");
                              setSigFormTag("");
                              setSigFormText("");
                              setSigEditId(null);
                            }}
                            className="w-full py-2 bg-gradient-to-r from-[#3D1052] to-[#C45BAA]/60 hover:opacity-95 text-white font-mono rounded-xl text-xs font-bold transition-all cursor-pointer border border-[#C45BAA]/20"
                          >
                            {sigEditId ? "Save Changes Context ✓" : "➕ Compile and Save Signature to Library"}
                          </button>
                        </div>

                        {/* Existing Personalized Signatures Grid */}
                        <div className="space-y-3.5">
                          <div className="flex justify-between items-center text-[10px] font-mono text-[#897E8C] uppercase tracking-wider">
                            <span>Your Personalized Library ({customSignatures.length} saved):</span>
                            <span>Supports Direct Action Integration</span>
                          </div>

                          {customSignatures.length === 0 ? (
                            <div className="bg-white/2 border border-dashed border-white/5 rounded-2xl p-6 text-center select-none text-gray-500">
                              No personalized signatures declared. Create one above to tailor your limits!
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                              {customSignatures.map((sig) => {
                                const renderedName = user?.name || "Professional User";
                                const resolvedText = sig.text.replace("[Your Name]", renderedName);
                                return (
                                  <div key={sig.id} className="bg-[#110122]/90 border border-white/5 rounded-xl p-4.5 flex flex-col justify-between space-y-4">
                                    <div className="space-y-2">
                                      <div className="flex justify-between items-start">
                                        <div>
                                          <span className="text-[10px] font-mono font-bold text-gray-200 block">{sig.label}</span>
                                          <span className="text-[9px] text-[#C45BAA] block font-light mt-0.5">{sig.tag}</span>
                                        </div>
                                        <div className="flex gap-1">
                                          <button
                                            onClick={() => {
                                              setSigFormLabel(sig.label);
                                              setSigFormTag(sig.tag);
                                              setSigFormText(sig.text);
                                              setSigEditId(sig.id);
                                              triggerToast("Ready to tweak context. Tweak parameters above! ✓");
                                            }}
                                            className="p-1.5 hover:bg-white/10 text-[#C45BAA] hover:text-white rounded transition-all cursor-pointer"
                                            title="Edit Context"
                                          >
                                            ✏️
                                          </button>
                                          <button
                                            onClick={() => {
                                              const updated = customSignatures.filter(s => s.id !== sig.id);
                                              setCustomSignatures(updated);
                                              localStorage.setItem("fh_custom_signatures", JSON.stringify(updated));
                                              triggerToast("Removed signature block. ✓");
                                              if (sigEditId === sig.id) {
                                                setSigFormLabel("");
                                                setSigFormTag("");
                                                setSigFormText("");
                                                setSigEditId(null);
                                              }
                                            }}
                                            className="p-1.5 hover:bg-[#FF9E7D]/20 text-[#FF9E7D] rounded transition-all cursor-pointer"
                                            title="Delete Signature"
                                          >
                                            🗑️
                                          </button>
                                        </div>
                                      </div>

                                      <pre className="text-[9px] font-mono text-gray-400 bg-white/2 p-2.5 rounded-lg border border-white/5 overflow-x-auto whitespace-pre-wrap leading-tight select-all">
                                        {resolvedText}
                                      </pre>
                                    </div>

                                    {/* Action Integrations */}
                                    <div className="flex flex-col sm:flex-row gap-1.5 pt-1.5 border-t border-white/5 justify-between items-center">
                                      <button
                                        onClick={() => {
                                          navigator.clipboard.writeText(resolvedText);
                                          triggerToast("Copied signature closing to clipboard! 📋");
                                        }}
                                        className="w-full sm:w-auto px-2 py-1 text-[8px] font-mono uppercase bg-white/5 hover:bg-white/10 text-gray-300 rounded border border-white/10 transition-all cursor-pointer text-center"
                                      >
                                        📋 Copy Block
                                      </button>
                                      
                                      <div className="flex gap-1.5 w-full sm:w-auto justify-end">
                                        <button
                                          onClick={() => {
                                            if (!emailResult) {
                                              triggerToast("No generated AI email draft found! Draft an email first. 🤖");
                                              return;
                                            }
                                            setEmailResult(prev => {
                                              const clean = prev.trim();
                                              return clean + resolvedText;
                                            });
                                            triggerToast("Appended to active AI Draft! ✓");
                                          }}
                                          className="flex-1 sm:flex-none px-2 py-1 text-[8px] font-mono uppercase bg-[#C45BAA]/10 hover:bg-[#C45BAA]/20 text-[#E085C9] rounded border border-[#C45BAA]/25 transition-all cursor-pointer text-center"
                                          title="Append this ending to the generated AI draft"
                                        >
                                          🤖 Append AI Close
                                        </button>

                                        <button
                                          onClick={() => {
                                            setScannerInput(prev => {
                                              const clean = prev.trim();
                                              return clean + resolvedText;
                                            });
                                            triggerToast("Appended signature to Sandbox draft! ✓");
                                          }}
                                          className="flex-1 sm:flex-none px-2 py-1 text-[8px] font-mono uppercase bg-emerald-950/40 hover:bg-emerald-950/60 text-emerald-300 rounded border border-emerald-500/25 transition-all cursor-pointer text-center"
                                          title="Append this ending to the active Sandbox Draft"
                                        >
                                          🛡️ Append Sandbox
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 3b. Script Generator */}
                {selectedWorkTool === "script" && (
                  <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                    <span className="text-[10px] tracking-widest text-teal font-mono block uppercase">Vocal Boundary Generators</span>
                    <p className="text-[11px] text-[#8A7F8D]">Construct clean verbatim dialogue loops for high pressure verbal checkpoints safely.</p>

                    <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                      {[
                        "Explain delay confidently",
                        "Reject last-minute demand",
                        "Ask for written briefing summary",
                        "Decline structural meeting overloads"
                      ].map((t, idx) => (
                        <button 
                          key={idx}
                          onClick={() => setScriptSelectedTemplate(t)}
                          className={`p-2 rounded-lg border text-left ${scriptSelectedTemplate === t ? "border-teal text-white bg-teal/10" : "border-white/5 text-gray-400"}`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>

                    <textarea 
                      value={scriptSituation}
                      onChange={e => setScriptSituation(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 text-xs rounded-xl p-3 focus:outline-none focus:border-teal text-gray-200"
                      rows={3}
                      placeholder="Input communication checkpoint context..."
                    />

                    <button 
                      disabled={scriptLoading || !scriptSituation.trim()}
                      onClick={() => executeCoreAction("Adaptive Advisor AI", handleFetchScript)}
                      className="w-full py-2.5 bg-[#3D1052] hover:bg-teal/20 border border-teal/40 text-[#FAF6F0] rounded-xl text-xs font-semibold font-sans flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {scriptLoading ? "Formulating dialogue models..." : "Synthesize Dialogue Scripts (2 versions) →"}
                    </button>

                    {scriptResult && (
                      <div className="bg-white/5 rounded-xl p-4 border border-teal/20 text-xs leading-relaxed font-light whitespace-pre-line text-gray-300">
                        {scriptResult}
                      </div>
                    )}
                  </div>
                )}

                {/* 3c. RSD Reality de-escalator */}
                {selectedWorkTool === "rsd" && (
                  <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                    <span className="text-[10px] tracking-widest text-[#E8845C] font-mono block uppercase">RSD Toolkit Reality Check</span>
                    <p className="text-[11px] text-[#8A7F8D]">Input facts, get de-escalations. De-conflict catastrophic mental scenarios automatically.</p>

                    <textarea 
                      value={rsdSpiral}
                      onChange={e => setRsdSpiral(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 text-xs rounded-xl p-3 focus:outline-none focus:border-[#E8845C] text-gray-200"
                      rows={3}
                      placeholder="What is the internal catastrophic worry?"
                    />

                    <button 
                      disabled={rsdLoading || !rsdSpiral.trim()}
                      onClick={() => executeCoreAction("Reframing Advisor AI", handleFetchRSDCheck)}
                      className="w-full py-2.5 bg-[#3D1052] hover:bg-[#E8845C]/20 border border-[#E8845C]/40 text-[#FAF6F0] rounded-xl text-xs font-semibold font-sans flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {rsdLoading ? "Reframing objective facts..." : "Reality Check This Spiral →"}
                    </button>

                    {rsdResult && (
                      <div className="bg-[#E8845C]/10 rounded-xl p-4 border border-[#E8845C]/35 text-xs leading-relaxed text-gray-300 font-light font-sans">
                        {rsdResult}
                      </div>
                    )}
                  </div>
                )}

                {/* 3d. ADA list section */}
                {selectedWorkTool === "ada" && (
                  <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                    <span className="text-[10px] tracking-widest text-[#D4A843] font-mono block uppercase">Legal Protections plain language</span>
                    
                    <div className="space-y-3">
                      {ADA_RIGHTS.map((item, idx) => (
                        <div key={idx} className="border-b border-white/5 pb-3">
                          <h4 className="text-sm font-serif font-semibold text-gray-200 flex items-center gap-2">
                            <span>✦</span> {item.title}
                          </h4>
                          <p className="text-xs text-[#8A7F8D] leading-relaxed mt-1 font-sans font-light">
                            {item.body}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 3e. Meeting Mode Prep Builder */}
                {selectedWorkTool === "meeting" && (
                  <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                    <span className="text-[10px] tracking-widest text-mag font-mono block uppercase">Meeting Mode Prep Guide</span>
                    <p className="text-[11px] text-[#8A7F8D]">Prepare efficiently. Generate structured walk-in alignments to retain steady workspace composure.</p>

                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="text-[10px] font-mono tracking-wider gray-400 block mb-1">Topic / Agenda Target</label>
                        <input 
                          type="text"
                          value={meetingTopic}
                          onChange={e => setMeetingTopic(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-gray-200 focus:outline-none"
                          placeholder="Performance review, weekly followups..."
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono tracking-wider gray-400 block mb-1">Key Attendee Profiles</label>
                        <input 
                          type="text"
                          value={meetingPeople}
                          onChange={e => setMeetingPeople(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-gray-200 focus:outline-none"
                          placeholder="e.g., Team lead and product manager"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono tracking-wider gray-400 block mb-1">Ideal Output Target</label>
                        <input 
                          type="text"
                          value={meetingGoal}
                          onChange={e => setMeetingGoal(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-gray-200 focus:outline-none"
                          placeholder="Establish resource priorities alignments..."
                        />
                      </div>

                      {/* Anxiety levels check */}
                      <div>
                        <label className="text-[10px] font-mono tracking-wider block mb-1 uppercase">Anxiety Levels Assessed</label>
                        <div className="grid grid-cols-3 gap-2">
                          {["Calm / Ready", "Nervous / Alert", "Significant Anxiety"].map((v, i) => (
                            <button 
                              key={i}
                              type="button"
                              onClick={() => setMeetingAnxiety(i + 1)}
                              className={`p-2.5 rounded-xl border-2 text-center text-[10px] font-medium transition-all ${
                                meetingAnxiety === i + 1 
                                  ? "border-mag bg-[#C45BAA]/10 text-white" 
                                  : "border-gray-200 bg-white hover:border-mag/30"
                              }`}
                            >
                              {v}
                            </button>
                          ))}
                        </div>
                      </div>

                      <button 
                        disabled={meetingLoading || !meetingTopic.trim()}
                        onClick={() => executeCoreAction("Tactical Meeting Coach", handleFetchMeetingPrep)}
                        className="w-full py-2.5 bg-[#3D1052] hover:bg-mag/20 text-[#FAF6F0] rounded-xl text-xs font-semibold font-sans border border-mag/40 disabled:opacity-50 transition-all cursor-pointer"
                      >
                        {meetingLoading ? "Building alignments documentation..." : "Formulate Pre-Meeting Checklist →"}
                      </button>

                      {meetingResult && (
                        <div className="bg-white/5 rounded-xl p-4 border border-mag/20 text-xs leading-relaxed font-light whitespace-pre-line text-gray-300">
                          {meetingResult}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 4. WINS JOURNAL TAB SCREEN */}
            {appTab === "wins" && (
              <div className="space-y-6">
                
                {/* Wins statistics trackers */}
                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className="bg-white/5 border border-white/5 rounded-xl p-3">
                    <span className="text-2xl text-mag block font-mono font-bold">{winsList.length}</span>
                    <span className="text-[10px] text-gray-400 uppercase tracking-widest font-mono">Evidence Logged</span>
                  </div>
                  <div className="bg-white/5 border border-white/5 rounded-xl p-3">
                    <span className="text-2xl text-teal block font-mono font-bold">
                      {winsList.filter(w => w.category === "Professional").length}
                    </span>
                    <span className="text-[10px] text-gray-400 uppercase tracking-widest font-mono">Professional Wins</span>
                  </div>
                </div>

                {/* Create win card */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                  <span className="text-[10px] tracking-widest text-[#C45BAA] font-mono block uppercase">Secure New Win Receipt</span>
                  <p className="text-[11px] text-[#8A7F8D]">Wins protect against clinical imposter spirals. Record even small items safely.</p>
                  
                  <div className="flex gap-2 text-[10px] font-mono">
                    {["Professional", "Personal", "Brave Moment"].map((c, i) => (
                      <button 
                        key={i}
                        type="button"
                        onClick={() => setNewWinCat(c)}
                        className={`px-3 py-1 rounded-full border ${newWinCat === c ? "border-mag text-white bg-mag/10" : "border-white/5 text-gray-400"}`}
                      >
                        {c}
                      </button>
                    ))}
                  </div>

                  <textarea 
                    value={newWinText}
                    onChange={e => setNewWinText(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 text-xs rounded-xl p-3 focus:outline-none focus:border-mag text-gray-200"
                    rows={2}
                    placeholder="Describe exactly what happened (e.g., cleared that inbox, aligned client priorities safely...)"
                  />

                  <button 
                    disabled={!newWinText.trim()}
                    onClick={() => executeCoreAction("Evidence Log", handleAddWinObj)}
                    className="w-full py-2.5 bg-gradient-to-r from-plum to-mag text-white rounded-xl text-xs font-semibold cursor-pointer disabled:opacity-50"
                  >
                    Lock Wins in Receipts List ★
                  </button>
                </div>

                {/* Wins Log listings */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-xs font-sans text-gray-200 px-1">
                    <span>Evidence Receipts Registered</span>
                    {winsList.length > 0 && (
                      <button 
                        onClick={downloadWinJournalTxt}
                        className="text-mag hover:underline flex items-center gap-1.5 font-sans"
                      >
                        <Download className="h-3 w-3" />
                        <span>Download Receipts Archive (.txt)</span>
                      </button>
                    )}
                  </div>

                  {winsList.length === 0 ? (
                    <div className="bg-white/2 border border-white/5 rounded-2xl p-8 text-center text-xs text-gray-400 italic">
                      Zero entries mapped today. Take courage, any small checkpoint counts.
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {winsList.map((w, idx) => (
                        <div key={w.id || idx} className="bg-white/5 border border-white/5 rounded-xl p-4 flex items-start justify-between gap-4">
                          <div className="space-y-1 pr-2">
                            <span className="text-[9px] font-mono uppercase tracking-widest text-mag bg-mag/10 px-2 py-0.5 rounded-full block w-fit mb-1">
                              {w.category}
                            </span>
                            <p className="text-xs text-gray-200 leading-relaxed font-sans">{w.text}</p>
                            <span className="text-[9px] text-[#8A7F8D] block">{w.date}</span>
                          </div>
                          <button 
                            onClick={() => handleDeleteWin(w.id)}
                            className="p-1 text-gray-500 hover:text-white"
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 5. UNMASK SPACE TAB SCREEN */}
            {appTab === "unmask" && (
              <div className="space-y-6">
                
                {/* Writing decomp area */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                  <span className="text-[10px] tracking-widest text-[#C45BAA] font-mono block uppercase">Private Unmasking Log (Dynamic Fading)</span>
                  <p className="text-[11px] text-[#8A7F8D]">Write without performance anxiety. Your text dynamically fades in real-time, functioning solely for direct emotional de-escalation extraction safely.</p>

                  <div className="relative bg-white/2 border border-[#C45BAA]/15 rounded-xl p-3 min-h-[160px] cursor-text">
                    <textarea 
                      value={unmaskText}
                      onChange={e => {
                        setUnmaskText(e.target.value);
                      }}
                      className="w-full bg-transparent border-none text-xs text-gray-200 leading-relaxed focus:outline-none focus:ring-0 select-none pb-12 resize-none"
                      rows={6}
                      placeholder="Say what is completely raw or unfiltered inside your mind loop today. Stays strictly local here."
                    />

                    {/* Fading overlay list */}
                    <div className="absolute bottom-2 left-3 right-3 flex flex-wrap gap-1 pointer-events-none select-none text-[10px] opacity-75">
                      {getFadingWords().map((w, i) => (
                        <span key={i} className="text-[#C45BAA] transition-all px-1 bg-[#C45BAA]/10 rounded font-sans italic" style={{ opacity: 0.15 + (i / 7) * 0.45 }}>
                          {w}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-[10px] text-teal block font-mono tracking-widest">ENCRYPTED LOCALLY ENTIRELY</span>
                    <button 
                      onClick={() => setUnmaskText("")}
                      className="text-xs font-mono text-mag underline hover:text-[#FAF7FF]"
                    >
                      Purge Decompression Draft
                    </button>
                  </div>
                </div>

                {/* Somatic de-escalation carousel */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                  <span className="text-[10px] tracking-widest text-teal font-mono block uppercase">Interactive Guided Somatic Recovery</span>
                  
                  <div className="bg-[#1C0A2E]/50 rounded-xl p-4 border border-teal/20 space-y-2">
                    <span className="text-xs font-mono uppercase tracking-wider text-teal block">{BREATH_STAGES[somaticStep].title}</span>
                    <p className="text-xs text-gray-300 leading-relaxed font-light">{BREATH_STAGES[somaticStep].instruction}</p>
                    
                    <div className="flex gap-2 pt-2 justify-between items-center">
                      <div className="flex gap-1.5">
                        {BREATH_STAGES.map((_, i) => (
                          <span key={i} className={`w-1.5 h-1.5 rounded-full ${somaticStep === i ? "bg-teal" : "bg-white/10"}`} />
                        ))}
                      </div>
                      <button 
                        onClick={() => setSomaticStep(prev => (prev + 1) % BREATH_STAGES.length)}
                        className="py-1 px-3 bg-teal hover:opacity-90 rounded-lg text-[10px] uppercase font-mono text-plum font-semibold"
                      >
                        Next Step
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 6. MASKING DEBT TAB SCREEN */}
            {appTab === "mask" && (
              <div className="space-y-6">
                
                {/* Mask indicators */}
                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className="bg-white/5 border border-white/5 rounded-xl p-3">
                    <span className="text-2xl text-[#E8845C] block font-mono font-bold">
                      {getCombinedDailyDebt()}
                    </span>
                    <span className="text-[10px] text-gray-400 uppercase tracking-widest font-mono">Today's accumulated Mask Debt</span>
                  </div>
                  <div className="bg-white/5 border border-white/5 rounded-xl p-3">
                    <span className="text-2xl text-teal block font-mono font-bold">
                      {Math.round(getCombinedDailyDebt() * 2.5)} min
                    </span>
                    <span className="text-[10px] text-gray-400 uppercase tracking-widest font-mono">Recovery Decompression required</span>
                  </div>
                </div>

                {/* Immediate Recovery Advice after Log */}
                {showRecoveryAlert && (
                  <div className="bg-[#E8845C]/10 border border-[#E8845C]/40 rounded-2xl p-5 space-y-3 relative overflow-hidden animate-fadeIn">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[9px] tracking-widest text-[#E8845C] font-mono block uppercase">🎯 Recovery Strategy Activated</span>
                        <h4 className="text-xs font-bold text-white mt-1">Recommended Decompression protocol</h4>
                      </div>
                      <button 
                        onClick={() => setShowRecoveryAlert(null)}
                        className="text-[9px] font-mono bg-white/10 hover:bg-white/20 text-gray-200 px-2 py-1 rounded transition-all"
                      >
                        Dismiss ✓
                      </button>
                    </div>

                    <div className="bg-[#130620]/75 rounded-xl p-3 border border-white/5 space-y-2">
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="font-mono text-[#8A7F8D]">Logged Stress Factor:</span>
                        <span className="font-mono font-bold text-[#E8845C]">{showRecoveryAlert.cost} pts</span>
                      </div>
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="font-mono text-[#8A7F8D]">Target Session Duration:</span>
                        <span className="font-mono font-bold text-teal">{showRecoveryAlert.advice.duration} minutes</span>
                      </div>
                      <div className="flex flex-col text-[11px] pt-1 border-t border-white/5 gap-1">
                        <span className="font-mono text-[#8A7F8D]">Recommended Sensory Action:</span>
                        <span className={`font-semibold ${showRecoveryAlert.advice.color}`}>{showRecoveryAlert.advice.activity}</span>
                      </div>
                    </div>

                    <p className="text-xs text-gray-200 leading-relaxed font-light italic bg-white/2 p-3 rounded-xl border border-white/5">
                      "{showRecoveryAlert.advice.tip}"
                    </p>

                    <div className="text-[9px] text-[#8A7F8D] font-mono leading-tight pt-1">
                      Based on masked elements: {showRecoveryAlert.types.join(", ")}.
                    </div>
                  </div>
                )}

                {/* Moment logging setup widget */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-5 space-y-4">
                  <span className="text-[10px] tracking-widest text-[#E8845C] font-mono block uppercase">Record mask exhaustion fatigue block</span>
                  
                  <div className="grid grid-cols-2 gap-1.5 text-[9px] font-mono">
                    {[
                      "Code-switching style blocks",
                      "Suppressed reactions parameters",
                      "Pretended to be linear",
                      "Over-compensated timing estimates",
                      "Absorbed heavy open-space office noise",
                      "Minimized physiological fatigue margins"
                    ].map((m, idx) => (
                      <button 
                        key={idx}
                        type="button"
                        onClick={() => handleToggleMaskType(m)}
                        className={`p-2 rounded-lg border text-left leading-relaxed ${
                          selectedMaskTypes.includes(m) ? "border-[#E8845C] text-white bg-[#E8845C]/15" : "border-white/5 text-gray-400"
                        }`}
                      >
                        {m}
                      </button>
                    ))}
                  </div>

                  <div>
                    <label className="text-[10px] font-mono tracking-wider text-gray-300 block mb-1">Fatigue Extraction Intensity Checked (1-10)</label>
                    <input 
                      type="range"
                      min="1"
                      max="10"
                      value={maskIntensity}
                      onChange={e => setMaskIntensity(Number(e.target.value))}
                      className="w-full accent-[#E8845C] cursor-pointer"
                    />
                    <div className="flex justify-between text-[9px] font-mono text-[#8A7F8D] mt-0.5">
                      <span>Low drainage factor</span>
                      <span>Severe central fatigue</span>
                    </div>
                  </div>

                  <input 
                    type="text"
                    value={maskNote}
                    onChange={e => setMaskNote(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 text-xs rounded-xl px-3 py-2 text-gray-200 focus:outline-none focus:border-[#E8845C]"
                    placeholder="Context notes (e.g. Q3 alignments sync)"
                  />

                  <button 
                    disabled={selectedMaskTypes.length === 0}
                    onClick={() => executeCoreAction("Social Masking Analyst", handleLogMaskMoment)}
                    className="w-full py-2.5 bg-gradient-to-r from-plum to-[#E8845C] text-white rounded-xl text-xs font-semibold cursor-pointer disabled:opacity-50"
                  >
                    Log Masking Exhaustion Metric
                  </button>
                </div>

                {/* Recover aligns logic */}
                {allMaskMoments.length > 0 && (
                  (() => {
                    const cumulativeDebt = getCombinedDailyDebt();
                    const dailyAdvice = getRecoveryAdvice(cumulativeDebt);
                    return (
                      <div className="bg-[#1C0A2E] border border-[#E8845C]/20 rounded-2xl p-5 space-y-3">
                        <span className="text-[10px] tracking-widest text-[#E8845C] uppercase block font-mono">Strategic Daily Recovery Recommendations</span>
                        <div className="flex justify-between items-baseline">
                          <span className="text-[11px] font-semibold text-gray-300">Daily Fatigue Status:</span>
                          <span className={`text-xs font-mono font-black uppercase ${dailyAdvice.color}`}>{dailyAdvice.level}</span>
                        </div>
                        <p className="text-xs text-gray-300 font-light leading-relaxed font-sans">
                          Your accumulated daily mask debt is <strong className="text-[#E8845C]">{cumulativeDebt} points</strong>. We suggest prioritizing at least <strong className="text-teal">{dailyAdvice.duration} minutes</strong> of cumulative sensory quietude.
                        </p>
                        <div className="p-3 bg-white/2 border border-white/5 rounded-xl space-y-1.5">
                          <span className="text-[10px] font-mono text-teal block uppercase">Recommended Decompression Route:</span>
                          <p className="text-xs text-gray-200 leading-relaxed font-light font-sans">{dailyAdvice.tip}</p>
                        </div>
                      </div>
                    );
                  })()
                )}
              </div>
            )}
          </main>

          {/* DYNAMIC NAVIGATION CONTROL BAR TAB BUTTONSROW */}
          <nav className="w-full max-w-lg bg-[#130620]/95 backdrop-blur-md rounded-t-3xl border-t border-white/5 fixed bottom-0 left-1/2 -translate-x-1/2 px-2 py-3 flex items-center justify-around z-30 select-none">
            <button 
              onClick={() => {
                setAppTab("home");
                setSelectedWorkTool(null);
              }}
              className={`flex flex-col items-center gap-1 shrink-0 ${appTab === "home" ? "text-mag" : "text-gray-550 text-gray-400"}`}
            >
              <Smile className="h-5 w-5" />
              <span className="text-[9px] font-mono">Home</span>
            </button>
            <button 
              onClick={() => {
                setAppTab("focus");
                setSelectedWorkTool(null);
              }}
              className={`flex flex-col items-center gap-1 shrink-0 ${appTab === "focus" ? "text-mag" : "text-gray-550 text-gray-400"}`}
            >
              <Zap className="h-5 w-5" />
              <span className="text-[9px] font-mono">Focus</span>
            </button>
            <button 
              onClick={() => {
                setAppTab("work");
              }}
              className={`flex flex-col items-center gap-1 shrink-0 ${appTab === "work" ? "text-mag" : "text-gray-550 text-gray-400"}`}
            >
              <ShieldCheck className="h-5 w-5" />
              <span className="text-[9px] font-mono">Survival</span>
            </button>
            <button 
              onClick={() => {
                executeCoreAction("Evidence receipts Journal", () => {
                  setAppTab("wins");
                  setSelectedWorkTool(null);
                });
              }}
              className={`flex flex-col items-center gap-1 shrink-0 ${appTab === "wins" ? "text-mag" : "text-gray-550 text-gray-400"}`}
            >
              <Award className="h-5 w-5" />
              <span className="text-[9px] font-mono">Wins</span>
            </button>
            <button 
              onClick={() => {
                executeCoreAction("Faded Decompression Space", () => {
                  setAppTab("unmask");
                  setSelectedWorkTool(null);
                });
              }}
              className={`flex flex-col items-center gap-1 shrink-0 ${appTab === "unmask" ? "text-mag" : "text-gray-550 text-gray-400"}`}
            >
              <Moon className="h-5 w-5" />
              <span className="text-[9px] font-mono">Unmask</span>
            </button>
            <button 
              onClick={() => {
                setAppTab("mask");
                setSelectedWorkTool(null);
              }}
              className={`flex flex-col items-center gap-1 shrink-0 ${appTab === "mask" ? "text-mag" : "text-gray-550 text-gray-400"}`}
            >
              <Lock className="h-5 w-5" />
              <span className="text-[9px] font-mono">Mask Debt</span>
            </button>
          </nav>

          {/* GUIDED INTERACTIVE TOUR MODAL OVERLAY */}
          {showGuidedTour && (
            <div className="fixed inset-0 z-40 bg-[#1C0A2E]/65 backdrop-blur-sm flex flex-col justify-end items-center p-4">
              <div className="w-full max-w-sm bg-[#130620] border-2 border-[#C45BAA]/60 rounded-3xl p-5 shadow-[0_0_30px_rgba(196,91,170,0.35)] space-y-4 mb-20 text-[#FAF6F0] text-left transition-all duration-300">
                
                {/* Top Info Header */}
                <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded-lg bg-[#C45BAA]/15 shrink-0">
                      {renderTourIcon(TOUR_STEPS[tourStep].iconName)}
                    </span>
                    <div>
                      <span className="text-[9px] font-mono tracking-widest text-[#C45BAA] block uppercase">Guided Workspace Tour</span>
                      <span className="text-[10px] font-mono text-gray-400">Step {tourStep + 1} of {TOUR_STEPS.length}</span>
                    </div>
                  </div>
                  
                  <button 
                    onClick={handleDismissTour}
                    className="text-[10px] font-mono text-gray-400 hover:text-white uppercase transition-all tracking-wider px-2 py-1 hover:bg-white/5 rounded-lg cursor-pointer select-none"
                    title="Dismiss and exit guide"
                  >
                    Skip ✕
                  </button>
                </div>

                {/* Tour Text Content */}
                <div className="space-y-1 text-left">
                  <h4 className="font-serif text-lg font-light leading-tight text-[#FAF7FF]">
                    {TOUR_STEPS[tourStep].title}
                  </h4>
                  <p className="text-xs text-gray-300 leading-relaxed font-light font-sans">
                    {TOUR_STEPS[tourStep].text}
                  </p>
                </div>

                {/* Visual Highlight indicator box to help guide attention */}
                <div className="bg-purple-950/30 border border-[#C45BAA]/20 rounded-xl p-3 flex items-center justify-between gap-3 text-left">
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="w-1.5 h-1.5 rounded-full bg-teal animate-ping" />
                    <span className="text-[9px] font-mono text-teal uppercase tracking-wider">Highlight Target:</span>
                  </div>
                  <span className="text-[10px] font-mono text-white font-semibold uppercase bg-[#FAF6F0]/5 border border-white/10 px-2.5 py-0.5 rounded-md truncate max-w-[180px]">
                    {TOUR_STEPS[tourStep].highlightIndicator}
                  </span>
                </div>

                {/* Pagination Controls */}
                <div className="flex items-center justify-between pt-1 border-t border-white/5">
                  <button
                    disabled={tourStep === 0}
                    onClick={handlePrevTourStep}
                    className="flex items-center gap-1 px-2.5 py-1.5 text-[10px] font-mono uppercase bg-white/5 disabled:opacity-30 hover:bg-white/10 text-gray-300 rounded-xl transition-all cursor-pointer disabled:cursor-not-allowed select-none"
                  >
                    <ChevronLeft className="h-3.5 w-3.5" /> Back
                  </button>

                  {/* Step dots */}
                  <div className="flex items-center gap-1.5 select-none">
                    {TOUR_STEPS.map((_, idx) => (
                      <span 
                        key={idx} 
                        className={`h-1.5 rounded-full transition-all duration-300 ${tourStep === idx ? "w-4 bg-[#C45BAA]" : "w-1.5 bg-white/20"}`}
                      />
                    ))}
                  </div>

                  <button
                    onClick={handleNextTourStep}
                    className="flex items-center gap-1 px-3 py-1.8 text-[10px] font-mono uppercase bg-gradient-to-r from-[#C45BAA] to-[#D4A843] text-white font-bold rounded-xl shadow-md hover:opacity-95 transform active:scale-95 transition-all cursor-pointer select-none"
                  >
                    {tourStep === TOUR_STEPS.length - 1 ? "Finish Tour ✓" : <>Next <ChevronRight className="h-3.5 w-3.5" /></>}
                  </button>
                </div>

              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. USER PROFILE MODAL */}
      {showProfileModal && (
        <div className="fixed inset-0 z-50 bg-[#1C0A2E]/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn text-[#1C0A2E]">
          <div className="bg-[#FAF6F0] border-2 border-[#C45BAA]/30 rounded-3xl p-6 max-w-sm w-full shadow-2xl relative overflow-y-auto max-h-[92vh]">
            <button 
              onClick={() => {
                setShowProfileModal(false);
                setIsEditingProfile(false);
              }}
              className="absolute top-4 right-4 p-1 rounded-full hover:bg-black/5 text-[#8A7F8D] cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="bg-[#C45BAA]/10 text-mag px-2.5 py-1 rounded-full text-[10px] font-mono uppercase tracking-widest inline-block mb-3 select-none">
              ✦ Personal Identity Hub
            </div>
            
            <h3 className="font-serif text-2xl font-light leading-tight mb-1">
              {isEditingProfile ? "Edit Spatial Identity" : "Your Cosmic Profile"}
            </h3>
            <p className="text-[11px] text-gray-500 mb-5 leading-relaxed">
              Create a safe, authentic workspace signature. All profile data is saved entirely offline in your secure client local storage arrays.
            </p>

            {/* Profile Content View / Edit */}
            <div className="space-y-4">
              
              {!isEditingProfile ? (
                /* View Mode */
                <div className="space-y-5 py-2 animate-fadeIn text-[#1C0A2E]">
                  {/* Styled Avatar Display */}
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="h-20 w-20 rounded-full border-4 border-[#C45BAA]/30 bg-[#130620] overflow-hidden flex items-center justify-center shadow-md">
                      {profilePic ? (
                        <img src={profilePic} alt="Profile" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="h-full w-full bg-gradient-to-tr from-[#3D1052] to-[#C45BAA] text-white flex items-center justify-center text-2xl font-mono font-black uppercase select-none">
                          {(user?.name || "U")[0]}
                        </div>
                      )}
                    </div>
                    
                    <div>
                      <h4 className="font-serif text-xl font-bold text-gray-900 leading-tight">
                        {user?.name || "Professional User"}
                      </h4>
                      <p className="text-[10px] font-mono text-[#C45BAA] uppercase tracking-wider mt-0.5">
                        Core Identity
                      </p>
                    </div>
                  </div>

                  {/* Alignment / Bio Detail Display */}
                  <div className="bg-[#1C0A2E]/5 border border-[#C45BAA]/15 rounded-2xl p-4 space-y-2">
                    <span className="text-[9px] font-mono text-[#C45BAA] uppercase tracking-widest font-semibold block">Alignment Bio & Intention:</span>
                    <p className="text-xs text-gray-750 italic leading-relaxed font-light">
                      {profileBio ? `"${profileBio}"` : '"No alignment bio declared yet. Set a bio to protect your executive capacity bounds."'}
                    </p>
                  </div>

                  {/* Security/Storage Indicator */}
                  <div className="flex items-center gap-2 px-1 text-[10px] text-gray-550 font-mono">
                    <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span>Saved Securely Offline</span>
                  </div>

                  {/* Action Operations for View Mode */}
                  <div className="flex gap-2.5 pt-2 border-t border-black/5">
                    <button 
                      onClick={() => {
                        setShowProfileModal(false);
                      }}
                      className="flex-1 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-xl text-xs font-semibold tracking-wider transition-all cursor-pointer text-center"
                    >
                      Close Window
                    </button>
                    <button 
                      onClick={() => {
                        setEditName(user?.name || "Professional User");
                        setEditBio(profileBio || "");
                        setIsEditingProfile(true);
                      }}
                      className="flex-1 py-2 bg-gradient-to-r from-plum to-mag hover:opacity-95 text-white rounded-xl text-xs font-semibold tracking-wider shadow-sm transition-all cursor-pointer text-center"
                    >
                      Edit Profile ✏️
                    </button>
                  </div>
                </div>
              ) : (
                /* Edit Mode */
                <div className="space-y-4 animate-fadeIn">
                  
                  {/* Profile Pic Upload & Preset Selection */}
                  <div className="space-y-2">
                    <label className="text-[10px] font-mono text-plum tracking-wider block uppercase font-medium">
                      Profile Picture
                    </label>
                    
                    <div className="flex gap-4 items-center">
                      {/* Current Preview */}
                      <div className="h-16 w-16 rounded-2xl border-2 border-[#C45BAA]/45 bg-[#130620] overflow-hidden flex-shrink-0 relative group flex items-center justify-center">
                        {profilePic ? (
                          <img src={profilePic} alt="Profile" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="h-full w-full bg-gradient-to-tr from-[#3D1052] to-[#C45BAA] text-white flex items-center justify-center text-xl font-mono font-black uppercase select-none">
                            {(editName || user?.name || "U")[0]}
                          </div>
                        )}
                        {profilePic && (
                          <button
                            onClick={() => {
                              setProfilePic("");
                              localStorage.removeItem("fh_profile_pic");
                              triggerToast("Profile photo cleared. Preset activated. ✓");
                            }}
                            className="absolute inset-0 bg-red-600/80 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center text-[9px] text-white font-mono cursor-pointer"
                          >
                            Remove
                          </button>
                        )}
                      </div>

                      {/* Drag and Drop Zone / Manual Upload Trigger */}
                      <div 
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                        onClick={() => {
                          const fileInput = document.getElementById("profile-pic-file-input");
                          if (fileInput) fileInput.click();
                        }}
                        className={`flex-1 h-16 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center p-2 text-center cursor-pointer transition-all ${
                          isDraggingFile 
                            ? "border-mag bg-[#C45BAA]/10 text-mag" 
                            : "border-[#C45BAA]/20 bg-black/2 text-[#8A7F8D] hover:border-mag/50 hover:bg-[#C45BAA]/5"
                        }`}
                      >
                        <Upload className="h-4 w-4 mb-0.5 text-[#C45BAA]" />
                        <span className="text-[9px] font-semibold leading-none text-plum">
                          {isDraggingFile ? "Drop image" : "Drop photo / Click"}
                        </span>
                        <span className="text-[8px] text-gray-400 mt-0.5 font-mono">
                          Square file (Max 1.5MB)
                        </span>
                        
                        <input 
                          id="profile-pic-file-input"
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            if (e.target.files && e.target.files[0]) {
                              handleFile(e.target.files[0]);
                            }
                          }}
                          className="hidden"
                        />
                      </div>
                    </div>

                    {/* Preset Geometric Avatar Selectors */}
                    <div className="pt-1 space-y-1">
                      <span className="text-[8px] font-mono text-gray-400 uppercase">Or Choose Space Gradient presets:</span>
                      <div className="grid grid-cols-4 gap-1.5">
                        {[
                          { name: "Orchid", colors: ["#3D1052", "#C45BAA"] },
                          { name: "Sunset", colors: ["#E8845C", "#C45BAA"] },
                          { name: "Aurora", colors: ["#0F4C43", "#60BCB6"] },
                          { name: "Cosmo", colors: ["#130620", "#E085C9"] },
                          { name: "Solar", colors: ["#B43A12", "#F6AD55"] },
                          { name: "Boreal", colors: ["#0D4F8B", "#4FD1C5"] },
                          { name: "Lavender", colors: ["#44337A", "#B794F4"] },
                          { name: "Hologram", colors: ["#701A75", "#FBBF24"] }
                        ].map((preset, idx) => (
                          <button
                            key={idx}
                            onClick={() => {
                              const canvas = document.createElement("canvas");
                              canvas.width = 200;
                              canvas.height = 200;
                              const ctx = canvas.getContext("2d");
                              if (ctx) {
                                const grad = ctx.createLinearGradient(0, 0, 200, 200);
                                grad.addColorStop(0, preset.colors[0]);
                                grad.addColorStop(1, preset.colors[1]);
                                ctx.fillStyle = grad;
                                ctx.fillRect(0, 0, 200, 200);
                                
                                // Draw Initial of user Name
                                ctx.fillStyle = "#ffffff";
                                ctx.font = "bold 90px sans-serif";
                                ctx.textAlign = "center";
                                ctx.textBaseline = "middle";
                                ctx.fillText((editName || user?.name || "U")[0].toUpperCase(), 100, 100);

                                const dataUrl = canvas.toDataURL("image/png");
                                setProfilePic(dataUrl);
                                localStorage.setItem("fh_profile_pic", dataUrl);
                                triggerToast(`Activated preset: ${preset.name} Gradient ✨`);
                              }
                            }}
                            className="h-6 rounded-md overflow-hidden border border-black/10 text-[8px] text-white font-mono font-bold flex items-center justify-center hover:opacity-90 cursor-pointer shadow-xs"
                            style={{ background: `linear-gradient(135deg, ${preset.colors[0]}, ${preset.colors[1]})` }}
                          >
                            {preset.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Editable Name & Bio Inputs */}
                  <div className="space-y-3 pt-1">
                    <div>
                      <label className="text-[10px] font-mono text-plum tracking-wider block mb-0.5 uppercase font-medium">Your Name</label>
                      <input 
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="w-full bg-white border border-[#C45BAA]/20 text-[#1C0A2E] rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-mag"
                        placeholder="Enter your profile name"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-mono text-plum tracking-wider block mb-0.5 uppercase font-medium">Alignment Bio / Bio Intention</label>
                      <textarea 
                        value={editBio}
                        onChange={(e) => setEditBio(e.target.value.slice(0, 160))}
                        rows={3}
                        className="w-full bg-white border border-[#C45BAA]/20 text-[#1C0A2E] text-xs rounded-xl px-3 py-2 leading-relaxed focus:outline-none focus:border-mag resize-none"
                        placeholder="Describe your current communication limits or focus structure..."
                      />
                      <div className="flex justify-between items-center text-[8px] text-[#8A7F8D] mt-0.5 font-mono">
                        <span>Describe focus limits.</span>
                        <span>{editBio.length}/160</span>
                      </div>
                    </div>
                  </div>

                  {/* Action Operations for Edit Mode */}
                  <div className="flex gap-2.5 pt-2">
                    <button 
                      onClick={() => {
                        // Revert inputs to original saved state
                        setEditName(user?.name || "Professional User");
                        setEditBio(profileBio || "");
                        setIsEditingProfile(false);
                        triggerToast("Changes reverted. ✓");
                      }}
                      className="flex-1 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-xl text-xs font-semibold tracking-wider transition-all cursor-pointer text-center"
                    >
                      Cancel / Revert ↺
                    </button>
                    <button 
                      onClick={handleSaveProfile}
                      className="flex-1 py-2 bg-gradient-to-r from-plum to-mag hover:opacity-95 text-white rounded-xl text-xs font-semibold tracking-wider shadow-sm transition-all cursor-pointer text-center"
                    >
                      Save Profile ✓
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>
        </div>
      )}
    </div>
  );
}
