export const AFFIRMATIONS = [
  "Your brain isn't broken. It's built differently — and that is your superpower.",
  "You walked into work today. That choice already took a lot of courage.",
  "A skipped task or late email does not take away from how exceptional you are.",
  "You are not your to-do list. You are the person who keeps showing up despite the noise.",
  "Rough days do not reset your progress. They are just a natural part of a non-linear journey.",
  "You belong in every single room you walk into. No explanation needed.",
  "Your ideas have immense value. Let's capture them whenever they flow.",
  "Resting is not a failure. It is the essential recharge that fuels your brilliant mind.",
  "You are not behind. You are working on your own beautiful timeline.",
  "Other people's uniform pacing is not the rule for your unique, creative brain.",
  "You have successfully made it through 100% of your hardest days so far. Today is no different.",
  "Asking clearly for what you need is not a weakness. It is elite self-advocacy.",
  "The brain fog is just temporary weather. Your underlying talent is your anchor.",
  "One tiny action at a time. That is always, completely, enough.",
  "You bring a unique perspective to this workspace that no conventional thinker could match."
];

export const MOODS = [
  { emoji: "⚡", name: "Focused", tips: "Riding a wave of focus? Start a 30-minute visual timer right now so you don't forget to eat or run out of steam, and put a single favorite song on loop to keep your momentum." },
  { emoji: "😶", name: "Foggy", tips: "Brain block is here, and that's okay! Drop all big plans. Try the 'micro-start': just open a single browser tab, write exactly one line of text, or read one item. Keep it tiny and stress-free." },
  { emoji: "😤", name: "Frustrated", tips: "Feeling tense or irritated? Don't try to force your way through. Step away from your desk for 3 minutes, splash cool water on your hands, or gently shake out your arms to let go of physical stress." },
  { emoji: "😰", name: "Overwhelmed", tips: "Too many things at once! Close your eyes, drop your shoulders, and write a quick 'Brain Dump' list of only 3 items. Focus purely on the single easiest next step." },
  { emoji: "💪", name: "Confident", tips: "Energy is optimal! Save a quick win in your My Win Journal right now to remind yourself of this feeling later, and use this great energy to send that boundary-setting note." },
  { emoji: "😴", name: "Drained", tips: "Battery low. Dim your screen, put on comfy headphones, and drop the pressure to look busy. Do only what is absolutely necessary to get through the day." }
];

export const ADA_RIGHTS = [
  {
    title: "Your Workspace Rights are Protected",
    body: "Focus challenges, autistic traits, high anxiety, and burnout are covered by workplace protection laws (like the ADA). Your employer is legally required to work with you to make helpful daily adjustments."
  },
  {
    title: "No Need to Share Your Private Diagnosis",
    body: "You do not have to share clinical terms or doctor diagnoses. You can request helpful changes by simply saying: 'I work best when I have structured quiet hours' or 'written guides help me focus better' to customize your workspace."
  },
  {
    title: "What Kind of Adjustments Can I Ask For?",
    body: "You can ask for extra buffer time on heavy tasks, written summaries after verbal meetings, a quiet desk corner, clear written briefs, flexible start times, or permission to wear noise-cancelling headphones."
  },
  {
    title: "How to Ask Your Manager",
    body: "Draft a simple, friendly request: 'To make sure I can deliver my absolute best work, I am respectfully requesting to receive meeting agendas in writing beforehand to help me organize my thoughts.'"
  },
  {
    title: "It is Illegal for Them to Treat You Differently",
    body: "Your employer cannot penalize you, cut your hours, or isolate you just because you asked for helpful workspace adjustments. Standard workplace laws protect you completely from unfair pushback."
  }
];

export const DOPAMINE_ITEMS = [
  { emoji: "💧", label: "Quick Sip of Water", detail: "Drinking water is literally immediate fuel for your brain. You just did something deeply kind for your body." },
  { emoji: "🚶", label: "2-Minute Walk", detail: "Standing up and taking a short walk triggers an instant brain refresh. Walk to the nearest window and back." },
  { emoji: "🎵", label: "One Good Song", detail: "Play one favorite song that reminds you of who you are. Let the music wash away the task pressure." },
  { emoji: "🌬️", label: "Calming Breath", detail: "Inhale slowly, hold, then breathe out. Your nervous system just took a much-needed sigh of relief." },
  { emoji: "☀️", label: "Look out the Window", detail: "Look at the farthest point outside. Your screen-strained eyes will immediately thank you." },
  { emoji: "🧊", label: "Cool Water Splash", detail: "Splashing cool water on your face or wrists gently alerts your body to release tension and refresh." },
  { emoji: "📝", label: "Log a Tiny Win", detail: "Write down any small win — even just opening this app or checking your email. Remembering wins provides a nice motivation boost." },
  { emoji: "✅", label: "Look at Completed Tasks", detail: "Write down three things you did today, like getting out of bed or taking a shower. Visual lists help trigger feeling proud of yourself." },
  { emoji: "🤸", label: "Simple Shoulder Shake", detail: "Stand up and shake your hands and shoulders for 30 seconds. This is an awesome way to shake off accumulated workday stress." }
];

export const BREATH_STAGES = [
  { title: "Feel Your Space", instruction: "Shut your eyes if you can. Feel the solid weight of your feet pressing onto the floor. Feel gravity holding you safely." },
  { title: "Unwind Body", instruction: "Roll your shoulders back gently. Let them drop. Relax your jaw, separate your teeth, and let your hands rest loosely." },
  { title: "Deep Breath", instruction: "Take a slow, deep breath in for 4 seconds... hold for 2 seconds... and breathe out slowly and fully for 6 seconds." },
  { title: "Drop Demands", instruction: "You do not have to solve, figure out, or fix anything in this immediate 2-minute break. You are completely off-call." },
  { title: "Be Kind to Yourself", instruction: "Say to yourself: 'I am doing the absolute best I can with the energy and focus I have today. That is more than enough.'" },
  { title: "Gently Return", instruction: "Slowly reopen your eyes. Wiggle your toes. You just honored your brain and body. Step back in whenever you feel ready." }
];

export interface GlossaryTerm {
  word: string;
  pronunciation?: string;
  category: "Focus" | "Energy" | "Emotion" | "Work & Study";
  simpleDef: string;
  funFact: string;
  superpower: string;
  strategy: string;
}

export const ADHD_GLOSSARY: GlossaryTerm[] = [
  {
    word: "Hyperfocus",
    pronunciation: "/haɪ.pɚˈfoʊ.kəs/",
    category: "Focus",
    simpleDef: "A legendary flow-state where your brain gets 500% absorbed in an exciting topic or problem, completely tuning out the rest of the world (including meals, texts, and bedtime).",
    funFact: "You do not lack attention; you actually have an abundance of it! You just don't always get to select which channel it locks onto.",
    superpower: "Incredible productivity surges, deep problem-solving skills, and rapid self-directed skill learning.",
    strategy: "Set a colorful mechanical visual timer *before* starting. Keep physical water and quick snacks in your immediate line of sight so your body doesn't run on empty."
  },
  {
    word: "Executive Dysfunction",
    pronunciation: "/ɪɡˈzek.jə.tɪv dɪsˈfʌŋk.ʃən/",
    category: "Focus",
    simpleDef: "When your brain's 'internal project manager' decides to take an unannounced coffee break, making it feel physically impossible to start or switch between simple tasks.",
    funFact: "It has absolutely nothing to do with laziness! Your brain is temporarily struggling with a chemical transfer delay.",
    superpower: "Since you can't rely on boring routine, you are a world-class expert at creating highly unique, engaging, and dynamic systems to bypass resistance.",
    strategy: "Use the 'Micro-Start' method. Tell yourself: 'I'll only open the document and type one single word, then I can stop.' The momentum usually wins!"
  },
  {
    word: "Rejection Sensitive Dysphoria (RSD)",
    pronunciation: "/rɪˈdʒek.ʃən ˈsen.sə.tɪv dɪsˈfɔː.ri.ə/",
    category: "Emotion",
    simpleDef: "An intense, physical wave of emotional vulnerability triggered by real or perceived criticism, negative feedback, or minor disconnects with friends or professors.",
    funFact: "Your nervous system processes social feedback using the same pathways it uses for physical injury. The feeling is real, but temporary!",
    superpower: "Incredible empathy, deep loyalty to friends, and high sensitivity to other people's emotional comfort.",
    strategy: "Use our RSD Reality Check tool. Write down the hard facts separately from your anxious interpretations, drop your shoulders, and give yourself a 24-hour buffer before replying to emails."
  },
  {
    word: "Time Blindness",
    pronunciation: "/taɪm ˈblaɪnd.nəs/",
    category: "Focus",
    simpleDef: "The natural difficulty perceiving or measuring the passage of time. Your brain essentially recognizes only two times: 'NOW' and 'NOT NOW'.",
    funFact: "Linear clock time is a human social construct, but your brain works in qualitative states of interest. You can feel an hour fly by like 2 minutes, or 5 minutes drag like an hour.",
    superpower: "When you operate in the 'Now' with high interest, you can execute complex creative sprints that leave others amazed.",
    strategy: "Place analogue clocks or visual hourglasses on your desk. Replace abstract digital numbers with visual colors that shrink so your brain can see time moving physically."
  },
  {
    word: "Body Doubling",
    pronunciation: "/ˈbɑː.di ˈdʌb.lɪŋ/",
    category: "Work & Study",
    simpleDef: "A magical productivity cheat-code where you do your tasks in the physical or digital presence of another person who is also quietly working.",
    funFact: "Having another human near you acts like a visual 'focus anchor', silently assuring your brain that it is safe, grounded, and expected to focus.",
    superpower: "Highly active social motivation! You thrive when you feel connected, supported, and part of a shared creative workspace.",
    strategy: "Join a virtual study room, work at a quiet coffee house, or ask a partner/college peer to sit in the same room while you fold laundry or write a paper. No active conversation required!"
  },
  {
    word: "Masking",
    pronunciation: "/ˈmæs.kɪŋ/",
    category: "Energy",
    simpleDef: "The exhausting process of hiding your natural ADHD traits, suppressing fidgets, or mimicking traditional work styles to fit into neurotypical environments.",
    funFact: "Masking is a very smart survival skill, but running it continuously is the single highest contributor to workplace and college burnout.",
    superpower: "Exceptional observational skills, high adaptability, and deep intellectual versatility.",
    strategy: "Schedule dedicated 'Unmasking Windows' after high-stakes meetings or exams. Head over to our Unburden sanctuary tab, shake your wrists, dim your screen, and let your brain flow completely unfiltered."
  },
  {
    word: "Dopamine Mining",
    pronunciation: "/ˈdoʊ.pə.miːn ˈmaɪ.nɪŋ/",
    category: "Energy",
    simpleDef: "The persistent, playful hunt for the raw brain chemicals needed for focus and drive. Usually looks like opening 15 browser tabs, arranging desk items, or eating a crunchy snack.",
    funFact: "Your brain naturally has fewer active dopamine transporters than a typical brain. You aren't distracted; your brain is simply thirsty for its natural fuel!",
    superpower: "A relentless sense of curiosity, adventure, and the ability to find surprise and joy in small daily details.",
    strategy: "Keep high-accessibility sensory items on your desk: fidget toys, noise-cancelling headphones playing ambient lofi, a icy class of water, or crunchy snacks like carrot sticks or nuts."
  },
  {
    word: "Neuro-Crash",
    pronunciation: "/ˈnʊr.oʊ kræʃ/",
    category: "Energy",
    simpleDef: "The sudden, heavy biological exhaustion state that hits when your energy supplies drain after a massive sprint of hyperfocus or prolonged masking.",
    funFact: "An ADHD crash is a physical protective mechanism. Your nervous system is forced to reboot to restore neurochemical balance.",
    superpower: "A highly resilient nervous system that can rebuild quickly once genuine, pressure-free rest is given.",
    strategy: "Respect the crash. It is not personal failure. Declare a 'Not Today 🌿' status in our home tab, dim your lights, and allow your brain to lie fallow without feeling guilty."
  },
  {
    word: "Double Attention",
    pronunciation: "/ˈdʌb.əl əˈten.ʃən/",
    category: "Focus",
    simpleDef: "The need to feed your brain's 'secondary scanner' with minor ambient stimulation (like music or foot tapping) so the 'primary driver' can focus on complex work.",
    funFact: "While standard advice says 'eliminate all noise', research shows background brown noise or repetitive rhythms actually helps steady ADHD neural pathways!",
    superpower: "Brilliant multi-threaded thinking. Perfect for complex design, music, coding, or high-coordination projects.",
    strategy: "Put a single familiar instrumental track on infinite loop, play low-frequency hums/brown noise, or use a silent foot-pedal/fidget underneath your desk during online lectures."
  },
  {
    word: "Intrusive Sleep",
    pronunciation: "/ɪnˈtruː.sɪv sliːp/",
    category: "Energy",
    simpleDef: "A sudden, intense, almost anesthetic wave of drowsiness that attacks when you are forced to sit through extremely boring, repetitive, or unengaging content.",
    funFact: "This is a real nervous-system response! When your brain registers zero stimulation, dopamine levels drop so low that your brain literally slips into Stage 1 sleep.",
    superpower: "An incredible biological truth bar. Your brain cannot fake interest. You are built to work on things that truly matter and inspire you.",
    strategy: "During boring meetings or lectures, actively take notes with colorful pens, stand up at the back of the room if allowed, or sketch visual doodles. Fidgeting is literally sleep-prevention medicine!"
  }
];
