import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini client server-side only
let ai: GoogleGenAI | null = null;
try {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
    console.log("Gemini Client initialized successfully on server.");
  } else {
    console.warn("WARNING: GEMINI_API_KEY is not defined in environment variables.");
  }
} catch (error) {
  console.error("Error initializing Gemini Client:", error);
}

// Utility to verify AI availability
const getAIClient = (): GoogleGenAI => {
  if (!ai) {
    throw new Error("Gemini API key is not configured. Please supply a valid GEMINI_API_KEY in the Secrets panel.");
  }
  return ai;
};

// ==========================================
// AI ENDPOINTS
// ==========================================

// 1. Smallest Step Breakdown
app.post("/api/ai/smallest-step", async (req, res) => {
  try {
    const { task } = req.body;
    if (!task) {
      return res.status(400).json({ error: "No task description supplied." });
    }

    const client = getAIClient();
    const prompt = `You are an ADHD coach for professional women. A woman with ADHD is paralyzed by this task: "${task}". 
Give the one absolute tiniest first action — under 5 minutes, minimum activation energy. 
Then provide 3 more tiny subsequent sequential steps to construct positive momentum.

Format the output precisely with headers:
FIRST MINI-STEP: [action]

THEN:
1. [Step 2]
2. [Step 3]
3. [Step 4]

End with one short, empowering sentence of support. Do not add conversational conversational preamble or conversational filler words.`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error("Error in Smallest Step AI:", error);
    res.status(500).json({ error: error.message || "An error occurred with the Gemini model." });
  }
});

// 2. Email Drafting Assistant
app.post("/api/ai/draft-email", async (req, res) => {
  try {
    const { template, situation, tone } = req.body;
    if (!situation) {
      return res.status(400).json({ error: "No situation context supplied." });
    }

    const client = getAIClient();
    
    // Determine tone guidelines and subject style expectations
    let toneGuideline = "";
    let subjectStyle = "";
    if (tone === "bold") {
      toneGuideline = "Tone: COMPLETELY UNAPOLOGETIC & BOLD. Zero defensive filler, start directly with the statement or boundary. Keep it incredibly crisp and strong.";
      subjectStyle = "A direct, high-impact, actionable subject line (e.g., 'Action Required: Timeline Status', 'Update: Project Delivery Rescheduling'). No decorative fluff.";
    } else if (tone === "formal") {
      toneGuideline = "Tone: POLISHED & DIPLOMATIC CORPORATE. Professional, highly structured, suitable for senior executives or enterprise clients.";
      subjectStyle = "A highly polished, traditional, and diplomatic corporate subject line (e.g., 'Proposal for Project Phase Adjustments', 'Scope Review & Next Steps').";
    } else if (tone === "accommodating") {
      toneGuideline = "Tone: PROTECTED CONFIDENCE. Expresses a request for structure or accommodations (e.g. written notes, specific directions, timeline) in a highly professional, self-assured tone.";
      subjectStyle = "A clear, structure-oriented subject line emphasizing documentation and process transparency (e.g., 'Agenda Request & Documentation Sync', 'Written Tracking: Project Action Items').";
    } else {
      toneGuideline = "Tone: FRIENDLY & FIRM. Balanced, warm but has solid, immovable professional boundaries. No over-explaining.";
      subjectStyle = "A balanced, warm but clear-cut subject line (e.g., 'Project Timeline & Delivery Update', 'Meeting Recap & Proposed Action Items').";
    }

    const prompt = `You are a professional writing corporate coach for neurodivergent women.
Draft a corporate email for the following situation: "${situation}".
The underlying template intention is: "${template || 'Professional relationship interaction'}".

${toneGuideline}

In your draft:
1. You MUST automatically place a relevant, professional email subject line prefixed with "Subject: " at the very first line of the draft.
2. The subject line must be contextually tailored to the situation and tone. Specifically, match these visual guidelines: ${subjectStyle}
3. Create a written representation that is highly capable and values their own time and energetic capacity.
4. Under no circumstances should you use minimizing words like "just", "sorry to bother", "actually", "I believe", "I think", "I was wondering", or over-apologize.
5. Keep it concise, polished, and ready to send.`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error("Error in Email Draft AI:", error);
    res.status(500).json({ error: error.message || "An error occurred with the Gemini model." });
  }
});

// 3. Conversation Script Generator
app.post("/api/ai/gen-script", async (req, res) => {
  try {
    const { scriptType, situation } = req.body;
    if (!situation) {
      return res.status(400).json({ error: "No situation context supplied." });
    }

    const client = getAIClient();
    const prompt = `You are a workplace assertiveness advocate for neurodivergent professional women.
Write a conversation script for a meeting or conversation.
Goal: "${scriptType || 'General boundary setting / self-advocacy'}".
Context: "${situation}".

Provide EXACTLY 2 distinct word-for-word spoken response scripts:
1. ASSERTIVE VERSION: (Firm, highly direct, respectful of capacity, no over-explaining).
2. DIPLOMATIC VERSION: (Supportive, collaborative, establishes steady pacing/boundaries but offers friendly buffers).

Do not over-apologize. Label both options clearly with short helpful scenario-cues. Keep the scripts highly natural and easy to say out loud.`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error("Error in Script General AI:", error);
    res.status(500).json({ error: error.message || "An error occurred with the Gemini model." });
  }
});

// 4. RSD Toolkit Reality Checker
app.post("/api/ai/rsd-check", async (req, res) => {
  try {
    const { spiral } = req.body;
    if (!spiral) {
      return res.status(400).json({ error: "No spiral feedback context supplied." });
    }

    const client = getAIClient();
    const prompt = `You are a supportive clinical neurodivergent life coach specializing in Rejection Sensitive Dysphoria (RSD).
A professional woman is experiencing an RSD spiral: "${spiral}".

Gently and with immense warmth:
1. Validate her emotional pain without validating the catastrophic story.
2. Separate the Objective Facts of the situation from the subjective catastrophic representations her brain is spinning.
3. Suggest 2 realistic alternative, non-hostile interpretations (e.g. the other person was busy, inattentive, or dealing with their own stress).
4. End with a short somatic grounding checklist (e.g. cold splash, wrist touch, slow breath) to calm her amygdala.

Keep the entire response supportive, concise, and under 160 words. Speak to her with quiet strength.`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error("Error in RSD AI Reality Check:", error);
    res.status(500).json({ error: error.message || "An error occurred with the Gemini model." });
  }
});

// 5. Meeting Prep Card Builder
app.post("/api/ai/meeting-prep", async (req, res) => {
  try {
    const { topic, people, goal, anxietyLevel } = req.body;
    if (!topic) {
      return res.status(400).json({ error: "Meeting topic is required." });
    }

    const client = getAIClient();
    const anxietyLabels = ["Minimal", "Calm", "Nervous / Anxious", "Severe Dread / Flight-or-Fight"];
    const currentAnxietyLevel = anxietyLevel ? (anxietyLabels[anxietyLevel] || anxietyLabels[2]) : anxietyLabels[2];

    const prompt = `You are FlowHer, a compassionate advisor and executive coach for professional women.
A user needs a direct prep guide for an upcoming meeting:
- Topic/Agenda: "${topic}"
- Attendees: "${people || 'My team / manager'}"
- Desired Output: "${goal || 'General alignments and next plans'}"
- Cognitive State/Anxiety: "Self-assessed level: ${currentAnxietyLevel}"

Generate a highly structured meeting prep card with EXACTLY these headers (bold them with **):

**WALK IN KNOWING:**
Generate 3 bullet points max. Crucial facts or key reference boundaries she should keep in mind.

**YOUR MAIN FOCUS:**
A single direct focus sentence to prevent mind-wandering or overworking during the conversation.

**IF YOU FREEZE:**
A natural, professional 1-sentence vocal bail-out script (e.g., "Let me review my logs on that for a second to be absolutely accurate...") that she can read or say directly.

**IF YOU GET INTERRUPTED:**
A firm 1-sentence recovery line to reclaim her speaking block with professional composure.

**NEXT DEED:**
A simple, single operational followup step to perform within 24 hours of completion.

Ensure a calm, grounding, and supportive tone. Do not use corporate double-speak. Keep items concise for easy visual reference on a phone.`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error("Error in Meeting Prep AI:", error);
    res.status(500).json({ error: error.message || "An error occurred with the Gemini model." });
  }
});

// ==========================================
// VITE OR STATIC SERVING MIDDLEWARE
// ==========================================

async function start() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[FlowHer Server] Running on http://localhost:${PORT}`);
  });
}

start();
const _ = express;
